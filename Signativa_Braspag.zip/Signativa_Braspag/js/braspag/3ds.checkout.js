var BraspagCheckout = Class.create();

BraspagCheckout.prototype = {
    initialize: function (config) {
        this.config = config;
        this.log('Checkout handler initialize');
        this.applied_changes = false;
        var self = this;
        this.checkoutInstance = new BraspagCheckoutInstance(this, function(callback) { self.updateBlocks (callback) } ) ;
    },

    log: function (message) {
        console.log('[Braspag]' + JSON.stringify(message))
    },

    updateBlocks: function (callback) {
        if (!this.config.is_threeds_active || !this.config.allowed_methods.includes(this.checkoutInstance.getPaymentMethod())) {
            if (typeof callback !== 'undefined') {
                callback(false);
            }
            return;
        }
        var self = this;
        this.checkoutInstance.blockPlaceOrder();
        new Ajax.Request(this.config.fetch_url, {
            method: 'get',
            parameters: this.config.containers.map(function (el, idx) {
                return 'blocks[' + idx + ']=' + el;
            }).join('&'),
            onSuccess: function (response) {
                let containers = response.responseJSON;
                containers.map(function (el) {
                    var className = el.container;
                    $$('.' + className)[0].update(el.html);
                });
                if (typeof callback !== 'undefined') {
                    callback();
                }
            }
        })
    },
    validateOrder: function () {
        this.checkoutInstance.blockPlaceOrder();
        bpmpi_authenticate();
    },

    afterValidate(resultType, data) {
        var authResult = {
            cavv: data.Cavv,
            xid: data.Xid,
            eci: data.Eci,
            version: data.Version,
            referenceId: data.ReferenceId,
            returnMessage: data.ReturnMessage
        };
        for (var d in authResult) {
            this.createFieldsOnContainer(d, authResult[d]);
        }
        switch (resultType) {
            case 'disabled' :
            case 'success':
                this.checkoutInstance.previous_button_action();
                break;
            case 'failure':
            case 'unenrolled':
                if (this.config.can_place_order[resultType]) {
                    this.checkoutInstance.previous_button_action();
                } else {
                    alert('Could not place order');
                }
                break;
            case 'error':
                if (this.config.can_place_order['error']) {
                    document.location.reload();
                }
                break;
        }
    },
    createFieldsOnContainer: function (fieldName, value) {
        var input = document.createElement('input');
        input.name = 'payment[' + this.checkoutInstance.getPaymentMethod() + '_' + fieldName + ']';
        input.value = value;
        input.type = 'hidden';
        this.checkoutInstance.getMethodContainer().append(input);
    },
    updateExpirationDate: function () {
        var expDate = this.checkoutInstance.getExpirationDate();
        var expArr = expDate.split("/");
        jQuery('.bpmpi_cardexpirationmonth').val(expArr[0].trim(' '));
        jQuery('.bpmpi_cardexpirationyear').val(expArr[1].trim(' '));
    },
    addClassToNumber: function () {
        jQuery(".bpmpi_cardnumber").removeClass("bpmpi_cardnumber");
        jQuery('input[name="payment['+ this.checkoutInstance.getPaymentMethod() + "_number"+']"]').addClass('bpmpi_cardnumber')
    }
};