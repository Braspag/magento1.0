var BraspagEwalletCheckout = Class.create();

BraspagEwalletCheckout.prototype = {
    initialize : function (ewalletHandler)
    {
        this.ewallet = ewalletHandler;
        this.initObservers();
        this.initPaymentChange();
    },
    initObservers : function () {
        var oldXHR = window.XMLHttpRequest;
        var self = this;
        function newXHR() {
            var realXHR = new oldXHR();
            realXHR.addEventListener("readystatechange", function() {
                if(realXHR.readyState === 4) {
                    if (realXHR.responseURL.indexOf('onestepcheckout/ajax/updatePaymentMethodForms') !== -1) {
                        self.ewallet.updateValues();
                        self.initPaymentChange();
                    }
                }

            }, false);
            return realXHR;
        }
        window.XMLHttpRequest = newXHR;
    },
    initPaymentChange : function () {
        var self = this;
        var interval = setInterval( function () {
            if (jQuery('input[name="payment[method]"]').length > 0) {
                if (self.getPaymentMethod() == 'braspag_ewallet') {
                    self.ewallet.updateValues(self.ewallet.loadEwalletCallback);
                    self.getPaymentButton().hide();
                }
                jQuery('input[name="payment[method]"]').change(function () {
                    if (self.getPaymentMethod() == 'braspag_ewallet') {
                        self.ewallet.updateValues(self.ewallet.loadEwalletCallback);
                        self.getPaymentButton().hide();
                    }
                    else {
                        self.ewallet.removeWalletCallback();
                        self.getPaymentButton().show();
                    }
                });
                clearInterval(interval);
            }
        });
    },
    hidePlaceOrder : function () {
        var self = this;
        var interval = setInterval( function () {
            if (self.getPlaceButton().length > 0) {
                self.getPlaceButton().hide();
                clearInterval(interval);
            }
        });
    },

    showPlaceOrder : function () {
        this.getPlaceButton().show();
    },

    getPlaceButton : function () {
        return jQuery("#review-buttons-container .btn-checkout");
    },

    getPaymentMethod: function () {
        var paymentMethod = $$('input[name="payment[method]"]:checked');
        if (paymentMethod.length > 0) {
            return paymentMethod[0].value;
        }
    },

    getPaymentButton : function ()
    {
        return jQuery("#onestepcheckout-place-order-button");
    },

    savePayment : function ()
    {
        this.getPaymentButton().click();
    }
};