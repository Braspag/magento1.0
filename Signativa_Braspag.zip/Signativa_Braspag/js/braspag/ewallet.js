var BraspagEwallet = Class.create();

BraspagEwallet.prototype = {
    initialize : function (config) {
        this.config = config;
        this.checkoutValues = {};
        this.isLoading = false;
        this.checkout = new BraspagEwalletCheckout(this);
        this.updateValues();
    },

    updateValues : function (callback)
    {
        this.isLoading = true;
        var self = this;
        new Ajax.Request(this.config.update_url, {
            method: 'get',
            onSuccess: function (response) {
                self.checkoutValues = response.responseJSON;
                self.isLoading = false;
                if (callback) {
                    callback();
                }
            }
        })
    },

    setCallbackOnSelect : function (callback) {
        this.loadEwalletCallback = callback;
    },

    setOnChangeToOtherMethod : function (callback) {
        this.removeWalletCallback = callback;
    },

    processPayment : function (paymentInfo) {
        console.log(paymentInfo);
        console.log(this);
        switch (this.config.ewallet) {
            case 'GooglePay':
                let data = paymentInfo.paymentMethodData;
                this.addValueToContainer('cc_flag', data.info.cardNetwork);
                this.addValueToContainer('last_four', data.info.cardDetails);
                this.addValueToContainer('token_data', data.tokenizationData.token);
                break;
        }
    },

    addValueToContainer : function (name, value)
    {
        var input = document.createElement('input');
        input.name = 'payment[' + this.checkout.getPaymentMethod() + '_' + name + ']';
        input.value = value;
        input.type = 'hidden';
        jQuery("#ewallet-fields").append(input);
    },

    savePayment : function ()
    {
        this.checkout.savePayment();
        this.setEwalletAsFinished();
    },

    addElementToContainer : function (element)
    {
        var ewallet = jQuery("#ewallet-container");
        if (ewallet.length > 0) {
            ewallet.append(element);
        }
    },

    clearContainer : function ()
    {
        jQuery("#ewallet-container").html('')
    },

    setEwalletAsFinished: function () {
        jQuery('#braspag_ewallet_finished').val('1');
    }
};