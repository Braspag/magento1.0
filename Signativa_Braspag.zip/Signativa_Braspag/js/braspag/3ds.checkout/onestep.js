var BraspagCheckoutInstance = Class.create();

BraspagCheckoutInstance.prototype = {
    initialize : function (manager, paymentCallback) {
        this.manager = manager;
        this.paymentCallback = paymentCallback;
        this.initObservers();
    },
    initObservers : function () {
        this.replaceOrderButton();
    },

    getPaymentMethod: function () {
        var paymentMethod = $$('input[name="payment[method]"]:checked');
        if (paymentMethod.length > 0) {
            return paymentMethod[0].value;
        }
    },
    replaceOrderButton : function () {
        var self = this;
        OSCForm.placeOrderButton.stopObserving();
        this.getPlaceButton().click(function() {
            self.paymentCallback(function () {
                self.manager.updateExpirationDate();
                self.manager.addClassToNumber();
                self.enablePlaceOrder();
                self.replaceOrderButton();
                self.manager.applied_changes = true;
                self.previous_button_action =  function ()  { OSCForm.placeOrder(); };
                self.manager.validateOrder();
            });
        });
    },
    blockPlaceOrder : function () {
        this.getPlaceButton().prop('disabled', true);
    },

    enablePlaceOrder : function () {
        this.getPlaceButton().prop('disabled', false)
    },

    getPlaceButton : function () {
        return jQuery("#onestepcheckout-place-order-button");
    },

    getMethodContainer : function () {
        return jQuery('#payment_form_'+this.getPaymentMethod());
    },

    getExpirationDate : function () {
        return jQuery("#"+this.getPaymentMethod()+"_expiration").val();
    }

};