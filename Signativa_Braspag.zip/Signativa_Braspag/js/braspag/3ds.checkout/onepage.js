var BraspagCheckoutInstance = Class.create();

BraspagCheckoutInstance.prototype = {
    initialize : function (manager, paymentCallback) {
        this.manager = manager;
        this.paymentCallback = paymentCallback;
        this.initObservers();
    },
    initObservers : function () {
        var oldXHR = window.XMLHttpRequest;
        var self = this;
        function newXHR() {
            var realXHR = new oldXHR();
            realXHR.addEventListener("readystatechange", function() {
                if(realXHR.readyState === 4) {
                    if (realXHR.responseURL.indexOf('checkout/onepage/savePayment') !== -1) {
                        self.paymentCallback(function (isThreeDs = true) {
                            if (!isThreeDs) {
                                self.enablePlaceOrder();
                            }
                            else {
                                self.manager.updateExpirationDate();
                                self.manager.addClassToNumber();
                                self.enablePlaceOrder();
                                self.replaceOrderButton();
                                self.manager.applied_changes = true;
                            }
                        });
                    }
                }

            }, false);
            return realXHR;
        }
        window.XMLHttpRequest = newXHR;
    },

    getPaymentMethod: function () {
        var paymentMethod = $$('input[name="payment[method]"]:checked');
        if (paymentMethod.length > 0) {
            return paymentMethod[0].value;
        }
    },
    replaceOrderButton : function () {
        var self = this;
        var interval = setInterval( function () {
            if (self.getPlaceButton().length > 0) {
                self.previous_button_action = self.getPlaceButton().prop('onclick');
                self.getPlaceButton().attr('onclick', '');
                self.getPlaceButton().click(function(){
                    self.manager.validateOrder();
                });
                clearInterval(interval);
            }
        });
    },
    blockPlaceOrder : function () {
        var self = this;
        var interval = setInterval( function () {
            if (self.getPlaceButton().length > 0) {
                self.getPlaceButton().prop('disabled', true);
                clearInterval(interval);
            }
        });
    },

    enablePlaceOrder : function () {
        this.getPlaceButton().prop('disabled', false)
    },
    
    getPlaceButton : function () {
        return jQuery("#review-buttons-container .btn-checkout");
    },

    getMethodContainer : function () {
        return jQuery('#payment_form_'+this.getPaymentMethod());
    },

    getExpirationDate : function () {
        return jQuery("#"+this.getPaymentMethod()+"_expiration").val();
    }

};