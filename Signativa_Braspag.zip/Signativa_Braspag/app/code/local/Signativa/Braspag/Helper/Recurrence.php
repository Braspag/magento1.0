<?php
class Signativa_Braspag_Helper_Recurrence extends Mage_Core_Helper_Abstract
{
    /**
     * @param null|Mage_Sales_Model_Quote $quote
     * @return bool
     */
    public function isCartRecurrent($quote=null)
    {
        if (!$this->getConfig('active')) {
            return false;
        }
	    if (!$quote){
		    $quote = $this->getCart()->getQuote();
        }

        return $quote->getData('is_order_recurrence') == '1';
    }

    /**
     * @param null|Mage_Sales_Model_Quote $quote
     * @return null|Mage_Sales_Model_Quote_Item
     */
    public function getRecurrentItem($quote=null)
    {
        if ($quote) {
            $items = $quote->getAllItems();
        }
        else {
            $items = $this->getCart()->getQuote()->getAllItems();
        }
        /**
         * @var $item Mage_Sales_Model_Quote_Item
         */
        foreach ($items as $item) {
            if ($item->getProduct()->getData('braspag_is_recurrent')){
                return $item;
            }
        }

        return null;
    }

    /**
     * @return Mage_Checkout_Model_Session
     */
    private function getCart() : Mage_Checkout_Model_Session
    {
        return Mage::getSingleton('checkout/session');
    }

    /**
     * @param $config
     * @return mixed
     */
    public function getConfig ($config) {
        return Mage::getStoreConfig('payment/braspag_recurrence/'.$config);
    }

    /**
     * @param $duration
     * @return false|string|null
     */
    public function calculateDuration($duration)
    {
        if ($duration instanceof  Mage_Catalog_Model_Product ) {
            $duration = $duration->getBraspagRecurrenceDuration();
        }
        if (!$duration) {
            return null;
        }
        return date('Y-m-d', strtotime('+ '.$duration));

    }

    public function allowNonRecurrentOnRecurrentCheckout()
    {
        return (bool) $this->getConfig('allow_non_recurrent');
    }

    public function getAllowedMethods ()
    {
        return explode(',', $this->getConfig('allowed_methods'));
    }

    public function setRecurrentPriceCart($product, $price)
    {
        $product->setCustomPrice($price);
        $product->setOriginalCustomPrice($price);
        $product->getProduct()->setIsSuperMode(true);

    }
}
