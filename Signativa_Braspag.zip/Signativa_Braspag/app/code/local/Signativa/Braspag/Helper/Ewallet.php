<?php


class Signativa_Braspag_Helper_Ewallet extends Mage_Core_Helper_Abstract
{
    /**
     * Returns value as json
     * @param $value
     * @return string
     */
    public function toJson($value)
    {
        return Zend_Json::encode($value);
    }

    /**
     * @param $items
     * @return array
     */
    public function prepareItems($items) : array
    {
        /**
         * @var Mage_Sales_Model_Quote_Item $item
         */
        $result = [];
        foreach ($items as $item) {
            $result[] = [
                'product_name' => $item->getName(),
                'qty' => $item->getQty(),
                'value' => $item->getRowTotal(),
                'sku' => $item->getSku()
            ];
        }

        return $result;
    }

    /**
     * @param Mage_Core_Controller_Request_Http $request
     * @return Signativa_Braspag_Model_Ewallet_Callback
     * @throws Exception
     */
    public function handleCallback (Mage_Core_Controller_Request_Http $request)
    {
        /**
         * @var $callback Signativa_Braspag_Model_Ewallet_Callback
         */

        $callback = Mage::getModel('braspag/ewallet_callback');

        $callback->setData('serialized_content', $this->prepareContent($request));

        return $callback->save();

    }

    protected function prepareContent(Mage_Core_Controller_Request_Http $request)
    {
        $dataToReturn = [];
        try {
            $dataToReturn = Zend_Json::decode($request->getRawBody(), true) ?? [];
        }
        catch (Exception $e) {}
        $dataToReturn = array_merge($dataToReturn, $request->getParams());

        return Zend_Json::encode($dataToReturn);
    }

}