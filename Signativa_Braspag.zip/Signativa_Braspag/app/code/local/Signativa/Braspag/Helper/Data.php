<?php

class Signativa_Braspag_Helper_Data extends Mage_Core_Helper_Abstract
{
    /**
     * @param $method
     * @param $config
     * @return mixed
     */
    public function getConfig($method, $config)
    {
        return Mage::getStoreConfig("payment/braspag_$method/$config");
    }

    /**
     * @param $config
     * @return mixed
     */
    public function getBaseConfig($config)
    {
        return Mage::getStoreConfig("payment/braspag/$config");
    }

    /**
     * @param Mage_Customer_Model_Customer $customer
     * @return object|Signativa_Braspag_Model_Resource_Hash_Collection
     */
    public function getSavedCcByCustomer(Mage_Customer_Model_Customer $customer)
    {
        /**
         * @var $collection Signativa_Braspag_Model_Resource_Hash_Collection
         */
        $collection = Mage::getModel('braspag/hash')->getCollection();
        $collection->addFieldToFilter('customer_id', $customer->getId());
        return $collection;
    }

    /**
     * @param $identity
     * @return string|string[]|null
     *
     */
    public function filterDigits($identity)
    {
        return preg_replace("/[^\d]/", '', $identity);
    }

    /**
     * @param $path
     * @return mixed
     */
    public function getAnyConfig($path)
    {
        return Mage::getStoreConfig($path);
    }

    /**
     * Get difference between two timestamps
     * @param $date1
     * @param null $date2
     * @return int
     * @throws Exception
     */
    public function getDateDifference($date1, $date2=null) {
        $dateCreatedAt = new DateTime($date1);
        $dateNow = new DateTime($date2);

        $diff = $dateCreatedAt->diff($dateNow);

        return (int) $diff->days;
    }

    /**
     * @param $date string|DateTime
     * @return string
     */
    public function formatDate($date) {
        if (is_string($date)) {
            $date = date_create($date);
        }
        return  date_format($date, 'Y-m-d');
    }

    /**
     * @param $status
     * @return string
     */
    public function prepareStatus($status)
    {
        if (!is_int($status)) {
            return $this->__($status);
        }
        foreach (Signativa_Braspag_Model_CallbackHandler_AntifraudStatus::getConstants() as $const) {
            if (in_array($status, $const)) {
                return $this->__($const[1]);
            }
        }
        return $status;
    }

    /**
     * @param $percent
     * @param $value
     * @return float
     */
    public function getPercentAsAmount($percent, $value) : float
    {
        return ($value * $percent) / 100;
    }

    /**
     * @param Signativa_Braspag_Model_Split_Merchant $merchant
     * @param Mage_Sales_Model_Quote $quote
     * @return Mage_Sales_Model_Quote_Item[]
     */
    public function getMerchantItems(Signativa_Braspag_Model_Split_Merchant $merchant, Mage_Sales_Model_Quote $quote) : array
    {
        $itemContainer = [];
        /**
         * @var $item Mage_Sales_Model_Quote_Item
         */
        foreach($quote->getAllVisibleItems() as $item) {
            if ($item->getProduct()->getBraspagMerchantId() == $merchant->getId()) {
                $itemContainer[] = $item;
            }
        }

        return $itemContainer;
    }

    /**
     * @param Signativa_Braspag_Model_Split_Merchant $merchant
     * @param Mage_Sales_Model_Quote $quote
     * @return decimal|int
     */
    public function getMerchantSubTotal(Signativa_Braspag_Model_Split_Merchant $merchant, Mage_Sales_Model_Quote $quote)
    {
        $sum = 0;
        foreach ($this->getMerchantItems($merchant, $quote) as $item) {
            if ($merchant->getId() == $item->getProduct()->getBraspagMerchantId()) {
                $sum = $sum + $item->getRowTotal() - $item->getDiscountAmount();
            }
        }
        return $sum;
    }

    /**
     * @param Mage_Sales_Model_Quote|null $quote
     * @return bool
     */
    public function isCartSplittable(Mage_Sales_Model_Quote $quote) : bool
    {
        $result = new Varien_Object();
        $result->setData('splittable', false);
        foreach($quote->getAllVisibleItems() as $item) {
            if ($item->getProduct()->getBraspagMerchantId()) {
                $result->setData('splittable', true);
            }
        }
        Mage::dispatchEvent('braspag_is_splitable', array( 'result' => $result, 'quote' => $quote));
        return $result->getData('splittable');
    }

    /**
     * @param Mage_Sales_Model_Quote|null $quote
     * @return Generator
     */
    public function getAllMerchantIds(Mage_Sales_Model_Quote $quote)
    {
        foreach($quote->getAllVisibleItems() as $item) {
            if ($id = $item->getProduct()->getBraspagMerchantId()) {
                yield $id;
            }
        }
    }

    /**
     * @param Mage_Sales_Model_Quote $quote
     * @return array
     */
    public function getQuoteMerchantIds(Mage_Sales_Model_Quote $quote) : array
    {
        $ids = iterator_to_array($this->getAllMerchantIds($quote));
        $idsObj = new Varien_Object();
        $idsObj->setData('merchant_ids', $ids);
        Mage::dispatchEvent('braspag_split_merchant_ids', array( 'ids' => $idsObj, 'quote' => $quote));
        return array_unique(array_filter($idsObj->getData('merchant_ids')));
    }

    /**
     * @param Signativa_Braspag_Model_Split_Merchant $merchant
     * @param Mage_Sales_Model_Quote $quote
     * @return float|int
     */
    public function getMerchantItemsQty(Signativa_Braspag_Model_Split_Merchant $merchant, Mage_Sales_Model_Quote $quote)
    {
        $qtySum = 0;
        foreach ($this->getMerchantItems($merchant, $quote) as $item) {
            $qtySum = $qtySum + $item->getQty();
        }

        return $qtySum;
    }
    /**
     * @param string $string
     */
    public function replaceSpecialChars($string){
        return preg_replace(array("/(á|à|ã|â|ä)/","/(Á|À|Ã|Â|Ä)/","/(é|è|ê|ë)/","/(É|È|Ê|Ë)/","/(í|ì|î|ï)/","/(Í|Ì|Î|Ï)/","/(ó|ò|õ|ô|ö)/","/(Ó|Ò|Õ|Ô|Ö)/","/(ú|ù|û|ü)/","/(Ú|Ù|Û|Ü)/","/(ñ)/","/(Ñ)/"),explode(" ","a A e E i I o O u U n N"),$string);
    }
}
	 