<?php


class Signativa_Braspag_VoidTransactionException extends Mage_Core_Exception
{

}