<?php


class Signativa_Braspag_Model_Source_Brand_Voucher extends Signativa_Braspag_Model_Source_Brand_Abstract
{
    protected $method = 'voucher';
}