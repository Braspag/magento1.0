<?php


class Simple
{

}