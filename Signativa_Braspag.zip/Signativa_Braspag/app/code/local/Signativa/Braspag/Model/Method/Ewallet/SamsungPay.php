<?php


class Signativa_Braspag_Model_Method_Ewallet_SamsungPay extends Signativa_Braspag_Model_Method_Ewallet_Abstract
{
    const XML_PATH_SERVICE_ID = 'payment/braspag_ewallet/samsungpay_service_id';

    const XML_PATH_MERCHANT_NAME = 'payment/braspag_ewallet/samsungpay_merchant_name';

    const XML_PATH_CARD_NETWORKS = 'payment/braspag_ewallet/samsungpay_card_networks';

    const CARD_NETWORKS = [
        'visa',
        'mastercard',
        'amex',
        'diners'
    ];

    /**
     * @return mixed
     */
    public function getCardNetworks()
    {
        return explode(',', Mage::getStoreConfig(self::XML_PATH_CARD_NETWORKS));
    }
    public function getSpecialTemplate()
    {
        return '/braspag/method/ewallet/special/samsungpay.phtml';
    }

    /**
     * @return stdClass
     */
    public function getAdditionalData()
    {
        // TODO: Implement getAdditionalData() method.
    }

    public function getWalletKey()
    {
        // TODO: Implement getWalletKey() method.
    }

    public function getServiceId()
    {
        return Mage::getStoreConfig(self::XML_PATH_SERVICE_ID);
    }

    public function getMerchantName()
    {
        return Mage::getStoreConfig(self::XML_PATH_MERCHANT_NAME);
    }
}