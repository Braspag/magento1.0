<?php


class Signativa_Braspag_Model_Source_Ewallet_GooglePay_Card extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        $result = [];
        foreach (Signativa_Braspag_Model_Method_Ewallet_GooglePay::GOOGLEPAY_CARD_NETWORKS as $card => $name) {
            $result [] = [
                'value' => $card,
                'label' => $name
            ];
        }

        return $result;
    }
}