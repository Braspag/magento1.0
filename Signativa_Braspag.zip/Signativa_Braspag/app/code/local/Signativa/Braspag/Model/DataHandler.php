<?php


class Signativa_Braspag_Model_DataHandler extends Varien_Object
{
    /**
     * @param $objectType
     * @param $data
     * @return mixed
     * @throws Exception
     */
    public function handle($objectType, $data)
    {
        if (!$objectType) {
            throw new \Exception('No object type defined');
        }

        $this->setObjectType($objectType);

        $data = $this->getHandler()->prepare($data);

        $instance = $this->getHandler()->getInstance();

        $instance->populate($data);

        return $instance;
    }

    /**
     * @return Signativa_Braspag_Model_DataHandler_Data
     * @throws Varien_Exception
     */
    private function getHandler()
    {
        if (!$this->getData('handler')) {
            $this->setData('handler', Mage::getModel('braspag/dataHandler_' . $this->getObjectType()));
        }

        return $this->getData('handler');
    }
}