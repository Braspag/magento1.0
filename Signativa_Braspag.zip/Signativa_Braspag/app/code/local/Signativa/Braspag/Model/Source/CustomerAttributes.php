<?php
/**
 * Created by PhpStorm.
 * User: matheus
 * Date: 18/05/19
 * Time: 13:48
 */

class Signativa_Braspag_Model_Source_CustomerAttributes extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        $result = [];
        /**
         * @var $attribute Mage_Customer_Model_Attribute
         */
        foreach ($this->getCustomerAttributes() as $attribute) {
            if (!$attribute->getStoreLabel()) {
                //continue;
            }
            $result[] = [
                'label' => $attribute->getStoreLabel(),
                'value' => $attribute->getAttributeCode()
            ];
        }

        return $result;
    }

    /**
     * @return array
     * @throws Varien_Exception
     */
    private function getCustomerAttributes()
    {
        return Mage::getModel('customer/customer')->getAttributes();
    }
}