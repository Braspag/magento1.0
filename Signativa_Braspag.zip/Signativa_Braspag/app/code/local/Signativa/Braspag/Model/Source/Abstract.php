<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/16/2019
 * Time: 7:05 PM
 */

abstract class Signativa_Braspag_Model_Source_Abstract
{
    /**
     * @return Signativa_Braspag_Helper_Data
     */
    public function getHelper()
    {
        return Mage::helper('braspag');
    }
}