<?php


class Signativa_Braspag_Model_Source_Provider_BankTransfer extends Signativa_Braspag_Model_Source_Abstract
{
    private $providers = [
        'Bradesco', 'BancoDoBrasil', 'SafetyPay', 'Itau'
    ];

    public function toOptionArray()
    {
        $result = [];
        foreach ($this->providers as $provider) {
            $result [] = [
                'label' => $provider,
                'value' => $provider
            ];
        }

        return $result;
    }

}