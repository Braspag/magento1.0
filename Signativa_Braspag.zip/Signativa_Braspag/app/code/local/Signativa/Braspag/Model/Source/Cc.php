<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/16/2019
 * Time: 8:31 PM
 */

class Signativa_Braspag_Model_Source_Cc extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        return [
            [
                'label' => '',
                'value' => ''
            ],
        ];
    }
}