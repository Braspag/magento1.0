<?php


class Signativa_Braspag_Model_Source_Cybersource_SequenceCriteria extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        return [
            [
                'label' => $this->getHelper()->__('Always'),
                'value' => \Braspag\API\FraudAnalysis::CRITERIA_ALWAYS
            ],
            [
                'label' => $this->getHelper()->__('On success'),
                'value' => \Braspag\API\FraudAnalysis::CRITERIA_ON_SUCCESS
            ]
        ];
    }
}