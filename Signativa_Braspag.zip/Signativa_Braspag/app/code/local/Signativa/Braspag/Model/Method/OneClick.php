<?php

use Braspag\API\Payment;
use Braspag\API\Sale;

class Signativa_Braspag_Model_Method_OneClick extends Signativa_Braspag_Model_Method_Cc
{
    protected $method = 'oneclick';
    protected $_formBlockType = 'braspag/method_oneClick_form';
    /**
     * @var Signativa_Braspag_Model_Hash
     */
    protected $token;

    public function isAvailable($quote = null)
    {
        $isParent = parent::isAvailable($quote);
        return $isParent && $this->isCustomerLoggedIn() && count(Mage::helper('braspag')->getSavedCcByCustomer($this->getCurrentCustomer())) > 0;
    }

    public function assignData($data)
    {
        if (!($data instanceof Varien_Object)) {
            $data = new Varien_Object($data);
        }
        $info = $this->getInfoInstance();
        /**
         * @var Signativa_Braspag_Model_Hash
         */
        $savedCcId = $data->getData('braspag_oneclick_saved_cc');
        $this->token = $this->getTokenById($savedCcId);
        $info->setCcType($this->token->getCardBrand())
            ->setPoNumber($data->getData('braspag_oneclick_installments'))
            ->setCcCid($data->getData('braspag_oneclick_cvv'))
            ->setCcNumber($savedCcId)
            ->setCcLast4($this->token->getLastFourDigits());
        return $this;
    }

    public function validate()
    {
//        parent::validate();
        $info = $this->getInfoInstance();
        $this->token = $this->getTokenById($info->getCcNumber());
        if ($this->token->getCustomerId() != $this->getCurrentCustomer()->getId()) {
            Mage::throwException('Invalid credit card');
        }

        return $this;
    }

    private function getTokenById($id)
    {
        return Mage::getModel('braspag/hash')->load($id);
    }
    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param $amount
     * @param bool $capture
     * @return Sale
     * @throws Varien_Exception
     * @throws Exception
     */
    protected function readyOrder($payment, $amount, $capture = false)
    {
        /**
         * @var $quote Mage_Sales_Model_Quote
         */
        $amount = $this->prepareAmount($amount);

        $quote = Mage::getSingleton('checkout/session')->getQuote();

        $sale = $this->initSale($quote->getReservedOrderId());

        $sale->setCustomer(
            $this->prepareCustomer($quote)
        );
        $pay = $sale->payment($amount, $payment->getPoNumber());
        $pay->setType(Payment::PAYMENTTYPE_CREDITCARD)
            ->creditCard($payment->getCcCid(), ucfirst($payment->getCcType()))
            ->setCardToken($this->token->getCardHash());
        $pay->setCapture($capture);
        //applies split
        $this->applySplit($pay, $quote, $payment);
        //handle a recurrent cart
        if ($this->getRecurrenceHelper()->isCartRecurrent($quote)) {
            $pay = $this->addRecurrenceToPayment($pay, $this->getRecurrenceHelper()->getRecurrentItem($quote));
        }
        //verify if anti fraud (ybersource is enabled
        if ($this->getCybersource()->isActive() && $this->getCybersource()->isBasicMode()) {
            $pay->setFraudAnalysis($this->prepareAntiFraud($payment));
        }
        $pay->setProvider($this->getProvider());

        return $sale;
    }
}