<?php


class Signativa_Braspag_Model_Source_Cybersource_Mode extends Signativa_Braspag_Model_Source_Abstract
{
    const COMPLETE_MODE = 'complete';

    const BASIC_MODE = 'basic';


    public function toOptionArray()
    {
        return [
            [
                'label' => $this->getHelper()->__('Basic Mode'),
                'value' => self::BASIC_MODE
            ],
            [
                'label' => $this->getHelper()->__('Complete Mode'),
                'value' => self::COMPLETE_MODE
            ]
        ];
    }
}