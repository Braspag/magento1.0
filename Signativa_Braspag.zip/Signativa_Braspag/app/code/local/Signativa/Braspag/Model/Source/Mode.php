<?php

class Signativa_Braspag_Model_Source_Mode extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        return [
            [
                'label' => $this->getHelper()->__('Production'),
                'value' => 'production'
            ],
            [
                'label' => $this->getHelper()->__('Sandbox'),
                'value' => 'sandbox'
            ]
        ];
    }
}