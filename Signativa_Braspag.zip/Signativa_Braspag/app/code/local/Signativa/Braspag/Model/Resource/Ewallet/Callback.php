<?php


class Signativa_Braspag_Model_Resource_Ewallet_Callback extends Mage_Core_Model_Resource_Db_Abstract
{
    protected function _construct()
    {
        $this->_init('braspag/ewallet_callback', 'entity_id');
    }

    protected function _beforeSave(Mage_Core_Model_Abstract $object)
    {
        if ($object->isObjectNew()) {
            $object->setCreatedAt($this->formatDate(true));
        }

        return parent::_beforeSave($object);
    }
}