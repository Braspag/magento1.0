<?php


class Signativa_Braspag_Model_Recurrence_Item extends Mage_Core_Model_Abstract
{
    const ACTIVE = 'active';

    const DISABLE = 'disable';

    protected function _construct()
    {
        $this->_init('braspag/recurrence_item');
    }

    /**
     * @param Mage_Sales_Model_Order_Item $item
     * @return $this
     */
    public function prepareFromOrderItem(Mage_Sales_Model_Order_Item $item)
    {
        $this->setParentItemId($item->getId())
            ->setState(self::ACTIVE)
            ->setPrice($item->getPrice())
            ->setQty($item->getQtyOrdered())
            ->setSku($item->getSku())
            ->setRecurrencePeriod($item->getProduct()->getBraspagRecurrencePeriod())
            ->setRecurrenceDuration($item->getProduct()->getBraspagRecurrenceDuration());

        return $this;
    }

    public function setRecurrence(Signativa_Braspag_Model_Recurrence $recurrence)
    {
        $this->setRecurrenceId($recurrence->getId());
        return $this;
    }

    /**
     * @return Mage_Sales_Model_Order_Item
     */
    public function getItemParent() : Mage_Sales_Model_Order_Item
    {
        return Mage::getModel('sales/order_item')->load($this->getParentItemId());
    }

    /**
     * @return Mage_Catalog_Model_Product
     */
    public function getProduct()
    {
        /**
         * @var $prod Mage_Catalog_Model_Product
         */
        $prod = Mage::getModel('catalog/product');

        return $prod->loadByAttribute('sku', $this->getSku());
    }
}