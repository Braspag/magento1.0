<?php

class Signativa_Braspag_Model_Product_Attribute_Merchant extends Mage_Eav_Model_Entity_Attribute_Source_Abstract
{
    /**
     * @return array
     */
    public function getAllOptions()
    {
        $this->_options = [
            [
                'value' => '',
                'label' => Mage::helper('braspag')->__('None')
            ]
        ];
        /**
         * @var $merchant Signativa_Braspag_Model_Split_Merchant
         */
        foreach ($this->getMerchantCollection() as $merchant) {
            $this->_options[] =
                [
                    'value' => $merchant->getId(),
                    'label' => $merchant->getMerchantName(),
                ];
        }
        return $this->_options;
    }

    /**
     * @return Signativa_Braspag_Model_Resource_Split_Merchant_Collection
     */
    public function getMerchantCollection() : Signativa_Braspag_Model_Resource_Split_Merchant_Collection
    {
        return Mage::getModel('braspag/split_merchant')->getCollection()->addFieldToSelect('merchant_name')->addFieldToSelect('entity_id');
    }
}
