<?php


class Signativa_Braspag_Model_Method_Ewallet_MasterPass extends Signativa_Braspag_Model_Method_Ewallet_Abstract implements Signativa_Braspag_Model_Method_Ewallet_Callbackable
{
    use Signativa_Braspag_Trait_Magento;

    const CARD_NETWORKS = [
        "master",
        "amex",
        "diners",
        "discover",
        "jcb",
        "maestro",
        "visa"
    ];
    const XML_PATH_CHECKOUT_ID = 'payment/braspag_ewallet/masterpass_checkout_id';

    const XML_PATH_CARD_NETWORKS = 'payment/braspag_ewallet/masterpass_card_networks';

    const MP_STATUS_CANCELED = 'cancel';

    /**
     * @return string
     */
    public function getCheckoutId()
    {
        return Mage::getStoreConfig(self::XML_PATH_CHECKOUT_ID);
    }

    /**
     * @return mixed
     */
    public function getCardNetworks()
    {
        return Mage::getStoreConfig(self::XML_PATH_CARD_NETWORKS);
    }


    public function getSpecialTemplate()
    {
        return '/braspag/method/ewallet/special/masterpass.phtml';
    }

    /**
     * @return stdClass
     */
    public function getAdditionalData()
    {
        // TODO: Implement getAdditionalData() method.
    }

    public function getWalletKey()
    {
        // TODO: Implement getWalletKey() method.
    }

    public function getCallbackUrl ()
    {
        return Mage::getUrl('braspag/ewallet/callback');
    }

    public function handleCallback(Signativa_Braspag_Model_Ewallet_Callback $callback)
    {
        /**
         * @var Mage_Sales_Model_Quote $quote
         */
        $data = $this->preparePayment($callback);
        $quote = Mage::getModel('sales/quote')->load($this->fetchQuoteId($callback));
        Mage::register('ewallet_quote', $quote, true);
        $order = $this->createOrderFromQuote($quote, $data);

        return $order;
    }

    /**
     * @param Signativa_Braspag_Model_Ewallet_Callback $callback
     * @return array
     * @throws Signativa_Braspag_CallbackException
     */
    protected function preparePayment(Signativa_Braspag_Model_Ewallet_Callback $callback)
    {
        if ($callback->getSerializedData('mpstatus') == self::MP_STATUS_CANCELED) {
            $error = new Signativa_Braspag_CallbackException('Callback failure check callback body for details');
            $error->setCallbackBody($callback);
            throw $error;
        }
        return [
            'method' => 'braspag_ewallet'
        ];
    }

    /**
     * @param Signativa_Braspag_Model_Ewallet_Callback $callback
     * @return int
     */
    public function fetchQuoteId(Signativa_Braspag_Model_Ewallet_Callback $callback)
    {
        return 95;
    }
}