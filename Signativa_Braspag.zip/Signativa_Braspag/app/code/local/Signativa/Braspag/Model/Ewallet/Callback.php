<?php


class Signativa_Braspag_Model_Ewallet_Callback extends Mage_Core_Model_Abstract
{
    private $serializedData = [];
    
    protected function _construct()
    {
        $this->_init('braspag/ewallet_callback');
    }


    public function getSerializedData($key = null)
    {
        if (empty($this->serializedData))
        {
            $this->serializedData = Zend_Json::decode($this->getSerializedContent());
        }

        if (!$key) {
            return $this->serializedData;
        }
        return $this->serializedData[$key] ?? null;
    }

    /**
     * @return Mage_Sales_Model_Quote
     */
    public function getQuoteInstance() : Mage_Sales_Model_Quote
    {
        return Mage::getModel('sales/quote')->load($this->getQuoteId());
    }
}