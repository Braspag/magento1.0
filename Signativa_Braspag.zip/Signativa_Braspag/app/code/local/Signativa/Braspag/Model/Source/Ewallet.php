<?php


class Signativa_Braspag_Model_Source_Ewallet extends Signativa_Braspag_Model_Source_Abstract
{

    public function toOptionArray()
    {
        $result = [];
        foreach (Signativa_Braspag_Model_Ewallet::getAvailableProviders()  as $provider => $class)
        {
            $result[] = [
                'label' => $provider,
                'value' => $class
            ];

        }

        return $result;
    }
}