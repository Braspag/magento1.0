<?php


class Signativa_Braspag_Model_Method_Voucher_ProviderBrand
{
    private $relation = [
        'Alelo' => ['Elo']
    ];

    public function getBrandsByProvider($provider)
    {
        return $this->relation[$provider] ?? null;
    }

    public function getProviders()
    {
        return array_keys($this->relation);
    }
}