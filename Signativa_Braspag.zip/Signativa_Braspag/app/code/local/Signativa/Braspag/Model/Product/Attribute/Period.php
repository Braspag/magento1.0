<?php


use Braspag\API\RecurrentPayment;

class Signativa_Braspag_Model_Product_Attribute_Period extends Mage_Eav_Model_Entity_Attribute_Source_Abstract
{
    /**
     * @return array
     */
    public function getAllOptions()
    {
        $this->_options = [
            [
                'value' => '',
                'label' => Mage::helper('catalog')->__('-- Please Select --'),
            ],
            [
                'value' => RecurrentPayment::INTERVAL_MONTHLY,
                'label' => Mage::helper('catalog')->__('Monthly'),
            ],
            [
                'value' => RecurrentPayment::INTERVAL_BIMONTHLY,
                'label' => Mage::helper('catalog')->__('Bi-Monthly'),
            ],
            [
                'value' => RecurrentPayment::INTERVAL_QUARTERLY,
                'label' => Mage::helper('catalog')->__('Quarterly'),
            ],
            [
                'value' => RecurrentPayment::INTERVAL_SEMIANNUAL,
                'label' => Mage::helper('catalog')->__('Semi-Annual'),
            ],
            [
                'value' => RecurrentPayment::INTERVAL_ANNUAL,
                'label' => Mage::helper('catalog')->__('Annual'),
            ]
        ];

        return $this->_options;
    }
}