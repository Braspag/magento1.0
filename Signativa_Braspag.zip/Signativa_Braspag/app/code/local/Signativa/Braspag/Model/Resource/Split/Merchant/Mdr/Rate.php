<?php


class Signativa_Braspag_Model_Resource_Split_Merchant_Mdr_Rate extends Mage_Core_Model_Resource_Db_Abstract
{

    protected function _construct()
    {
        $this->_init('braspag/split_merchant_mdr_rate', 'entity_id');
    }

    public function _beforeSave(Mage_Core_Model_Abstract $object)
    {
        $collection = $object->getCollection()
                             ->addFieldToFilter('brand', $object->getBrand())
                             ->addFieldToFilter('installment', $object->getInstallment())
                             ->addFieldToFilter('merchant_id', $object->getMerchantId())
                             ->addFieldToFilter('debit', $object->getDebit());

        if ($collection->count() > 0) {
            if ($collection->getFirstItem()->getId() != $object->getId()) {
                throw new Exception('You cannot repeat rates for the sames installment and brand');
            }
        }
        return $this;
    }

}