<?php

use Braspag\API\Payment;
use Braspag\API\Sale;

class Signativa_Braspag_Model_Method_Bankslip extends Signativa_Braspag_Model_Method_Abstract
{
    protected $method = 'bankslip';
    protected $_formBlockType = 'braspag/method_bankslip_form';
    protected $_infoBlockType = 'braspag/method_bankslip_info';
    protected $_canOrder = true;
    protected $_canVoid                     = true;

    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param float $amount
     * @return Mage_Payment_Model_Abstract
     * @throws Varien_Exception
     * @throws Mage_Core_Exception
     */
    public function order(Varien_Object $payment, $amount)
    {
        parent::order($payment, $amount);

        $sale = $this->readyOrder($payment, $amount);

        $result = $this->placeOrder($sale);

        $payment->setIsTransactionClosed(false);

        $payment->setTransactionId($result->getPayment()->getPaymentId());

        $this->setAdditionalInformation($payment, $result);

        return $this;
    }

    /**
     * @param $payment Mage_Sales_Model_Order_Payment
     *
     * @param $information Sale
     * @return Signativa_Braspag_Model_Method_Bankslip
     * @throws Mage_Core_Exception
     */
    public function setAdditionalInformation($payment, $information)
    {
        $payment->setAdditionalInformation('bankslip_url', $information->getPayment()->getUrl());
        $payment->setAdditionalInformation('provider', $information->getPayment()->getProvider());
        $payment->setAdditionalInformation('bankslip_number', $information->getPayment()->getBarCodeNumber());
        $payment->setAdditionalInformation('payment_id', $information->getPayment()->getPaymentId());
        $payment->setAdditionalInformation('bankslip_expire', $information->getPayment()->getExpirationDate());
        if ($information->getPayment()->getDoSplit()) {
            $payment->setAdditionalInformation('split_merchant', Zend_Json::decode(Zend_Json::encode($information->getPayment()->getSplitPayments())));
        }
        return $this;
    }

    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param $amount
     * @return \Braspag\API\Sale
     * @throws Varien_Exception
     */
    protected function readyOrder($payment, $amount)
    {
        return $this->getBankslipType()->readyOrder($payment, $amount);
    }

    private function getBankslipType() 
    {
        $type = $this->getConfigData('type') ?? 'pagador';
        $instance = Mage::getModel('braspag/method_bankslip_'.$type);

        return $instance;
    }
}