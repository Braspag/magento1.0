<?php


use Braspag\API\RecurrentPayment;
use Braspag\API\Request\BraspagRequestException;
use Braspag\API\Sale;

abstract class Signativa_Braspag_Model_CallbackHandler_Abstract extends Varien_Object
{
    use Signativa_Braspag_Trait_Api;

    use Signativa_Braspag_Trait_Log;

    use Signativa_Braspag_Trait_Magento;

    abstract public function execute();

    /**
     * @param bool $getRecurrence
     * @return RecurrentPayment|Sale
     * @throws BraspagRequestException
     */
    public function readySale($getRecurrence=false)
    {
        $callbackInfo = $this->getCallbackInfo();
        if (isset($callbackInfo['RecurrentPaymentId']) && $getRecurrence) {
            return $this->getRecurrentSaleInfo($callbackInfo['RecurrentPaymentId']);
        }
        $sale = $this->getSaleInfo($callbackInfo['PaymentId']);
        return $sale;
    }

    /**
     * @param $orderId
     * @return Mage_Sales_Model_Order
     */
    public function getOrderByIncrementId($orderId) : Mage_Sales_Model_Order
    {
        return Mage::getModel('sales/order')->load($orderId, 'increment_id');
    }
}