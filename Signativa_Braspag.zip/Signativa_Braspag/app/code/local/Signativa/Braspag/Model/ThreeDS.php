<?php

class Signativa_Braspag_Model_ThreeDS extends Varien_Object
{
    const CONFIG_CONTAINER = 'payment/threeds_auth/';

    const SANDBOX_ENDPOINT = 'https://mpisandbox.braspag.com.br';

    const PRODUCTION_ENDPOINT = 'https://mpi.braspag.com.br';

    const SANDBOX_ENVIRONMENT = 'SDB';

    const PRODUCTION_ENVIRONMENT = 'PRD';
    /**
     * @var Signativa_Braspag_Model_ThreeDS_Api
     */
    protected $api;

    public function _construct()
    {
        $this->setHelper(Mage::helper('braspag'));
        $this->api = Mage::getModel('braspag/threeDS_api', [
            'url' => $this->getApiEndpoint(),
            'credential' => [
                'client_id' => $this->getClientId(),
                'client_secret' => $this->getClientSecret()
            ]
        ]);
    }

    /**
     * @return bool
     */
    public function isActive()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.'active');
    }
    /**
     * @return string
     */
    public function getApiEndpoint()
    {
        if ($this->getEnvironment() == 'production') {
            return self::PRODUCTION_ENDPOINT;
        }
        return self::SANDBOX_ENDPOINT;
    }

    /**
     * @return mixed
     */
    public function getEnvironment()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.'environment');
    }

    /**
     * @return mixed
     */
    public function getClientId()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.$this->getEnvironment().'_client_id');
    }

    /**
     * @return mixed
     */
    public function getClientSecret()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.$this->getEnvironment().'_client_secret');
    }

    public function authenticate()
    {
        $action = Mage::getModel('braspag/threeDS_api_token');
        $action->setMethod(Zend_Http_Client::POST);
        $action->setPostParameters([
            'EstablishmentCode' => $this->getEstablishmentCode(),
            'MerchantName' => $this->getMerchantName(),
            'MCC' => $this->getMcc()
        ]);

        return $this->execute($action);
    }

    public function getEstablishmentCode()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.'establishment_code');
    }

    /**
     * @return mixed
     */
    public function getMerchantName()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.'merchant_name');
    }

    /**
     * @return mixed
     */
    public function getMcc()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.'mcc');
    }
    /**
     * @return mixed
     */
    public function canCreateOrderError()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.'reload_page_after_error');
    }
    /**
     * @return mixed
     */
    public function canCreateOrderFailure()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.'create_order_after_failure');
    }
    /**
     * @return mixed
     */
    public function canCreateOrderUnenrolled()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.'create_order_unenrolled');
    }
    /**
     * @param $action
     * @return bool|mixed
     */
    protected function execute($action) {
        return $this->api->executeAction($action);
    }

    /**
     * @return Mage_Core_Model_Abstract|Signativa_Braspag_Model_ThreeDs_BlockLoader
     */
    public function getBlockLoader() {
        return Mage::getSingleton('braspag/threeDS_blockLoader');
    }

    /**
     * @return Signativa_Braspag_Helper_Data
     */
    public function getHelper()
    {
        return $this->getData('helper');
    }

    public function allowedMethods()
    {
        return [ 'braspag_cc', 'braspag_debit'];
    }

    public function getAntiFraudFields()
    {
        return [
            'cavv',
            'xid',
            'eci',
            'version',
            'referenceId'
        ];
    }
}