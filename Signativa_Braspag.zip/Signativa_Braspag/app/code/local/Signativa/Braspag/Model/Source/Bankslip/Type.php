<?php

class Signativa_Braspag_Model_Source_Bankslip_Type 
{
    protected $types = [
        'Braspag',
        'Pagador'
    ];
    public function toOptionArray()
    {

        $result = [];
        foreach ($this->types as $type) {
            $result[] = [
                'label' => $type,
                'value' => strtolower($type)
            ];
        }

        return $result;
    }
}