<?php


class Signativa_Braspag_Model_Source_Brand_Abstract extends Signativa_Braspag_Model_Source_Abstract
{
    protected $method;

    use Signativa_Braspag_Trait_Log;

    /**
     * @return array
     */
    public function toOptionArray()
    {
        /**
         * @var $relator Signativa_Braspag_Model_Method_Cc_ProviderBrand
         */
        $relator = Mage::getModel('braspag/method_'.$this->method.'_providerBrand');

        $brands = $relator->getBrandsByProvider($this->getProvider());
        //if no brands are found for the provider we return a simple message
        if (!$brands) {
            $this->log('No brands found for provider: ' . $this->getProvider());
            return [
                [
                    'label' => 'Provider is not defined',
                    'value' => ''
                ]
            ];
        }
        $result = [];
        foreach ($brands as $brand) {
            $result[] = [
                'label' => $brand,
                'value' => $brand
            ];
        }

        return $result;
    }

    /**
     * @return mixed
     */
    private function getProvider()
    {
        return Mage::getStoreConfig('payment/braspag_'.$this->method.'/provider');
    }
}