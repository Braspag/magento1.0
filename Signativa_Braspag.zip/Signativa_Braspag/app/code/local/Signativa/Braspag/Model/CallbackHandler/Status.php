<?php

class Signativa_Braspag_Model_CallbackHandler_Status extends Signativa_Braspag_Model_CallbackHandler_Abstract
{
    /**
     * @throws Mage_Core_Exception
     */
    public function execute()
    {
        //request sale info from braspag API
        $sale = $this->readySale();

        $order = $this->getOrder($sale->getMerchantOrderId());
        /**
         * @var $payment \Braspag\API\Payment
         */
        $payment = $sale->getPayment();
        if (
            $order->canInvoice() &&
            $payment->getStatus() == Signativa_Braspag_Model_Payment::PAYMENT_CONFIRMED
        ) {
            $this->createInvoice($order, true);
        } else {
            if (
                $order->canCancel() &&
                in_array($payment->getStatus(), Signativa_Braspag_Model_Payment::$canceledStatuses)
            ) {
                $this->cancelOrder($order);
            }
        }

    }
}
