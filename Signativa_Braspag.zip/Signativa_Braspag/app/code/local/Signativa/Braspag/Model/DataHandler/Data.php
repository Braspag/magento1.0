<?php
/**
 * Created by PhpStorm.
 * User: matheus
 * Date: 18/05/19
 * Time: 12:53
 */

interface Signativa_Braspag_Model_DataHandler_Data
{
    public function prepare($data);

    public function getInstance();
}