<?php


class Signativa_Braspag_Model_DataHandler_CustomerOrder extends Signativa_Braspag_Model_DataHandler_Customer
{
    use Signativa_Braspag_Trait_Log;
    /**
     * @param $orderData Mage_Sales_Model_Quote
     * @return stdClass
     * @throws Varien_Exception
     */
    public function prepare($orderData)
    {
        $data = new stdClass();
        //Setting the customer name
        $data->Name = $orderData->getData('customer_firstname');
        if ($middlename = $orderData->getData('customer_middlename')) {
            $data->Name = $data->Name.' '.$middlename;
        }
        $data->Name = $data->Name.' '. $orderData->getData('customer_lastname');

        $data->Email = $orderData->getData('customer_email');
        //preparing the customer identity
        $identity = $orderData->getData('customer_taxvat');

        $data->Phone = $this->filterDigits($orderData->getBillingAddress()->getTelephone());
        //removes non digits from customers identity
        $identity = $this->filterDigits($identity);
        //if length of identity higher than 11 is a cnpj else a cpf
        $data->IdentityType = strlen($identity) > 11 ? self::CNPJ_IDENTITY : self::CPF_IDENTITY;
        $data->Identity = $identity;

        $data->Birthdate = Mage::helper('braspag')->formatDate($orderData->getData('customer_dob'));
        //preparing the customer address
        $data->Address = $this->prepareAddress($orderData->getBillingAddress(), $this->fetchIso3());

        if (!$orderData->isVirtual()) {
            $data->DeliveryAddress = $this->prepareAddress($orderData->getShippingAddress(), $this->fetchIso3());
        }

        $this->log($data);

        return $data;
    }

    public function getCybersource() : Signativa_Braspag_Model_Cybersource
    {
        return Mage::getSingleton('braspag/cybersource');
    }

    protected function fetchIso3()
    {
        return !($this->getCybersource()->isActive() && $this->getCybersource()->isBasicMode());
    }
}