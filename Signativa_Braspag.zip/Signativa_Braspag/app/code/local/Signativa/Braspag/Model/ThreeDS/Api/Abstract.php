<?php


class Signativa_Braspag_Model_ThreeDS_Api_Abstract extends Varien_Object
{
    protected $route = '';

    public function getRoute() {
        return $this->route;
    }

    public function handleResponse($response)
    {
        return Zend_Json::decode($response);
    }
}