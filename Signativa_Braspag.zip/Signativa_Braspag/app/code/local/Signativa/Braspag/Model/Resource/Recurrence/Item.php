<?php


class Signativa_Braspag_Model_Resource_Recurrence_Item extends Mage_Core_Model_Resource_Db_Abstract
{

    protected function _construct()
    {
        $this->_init('braspag/recurrence_item', 'item_id');
    }


    protected function _beforeSave(Mage_Core_Model_Abstract $object)
    {
        if ($object->isObjectNew()) {
            $object->setCreatedAt($this->formatDate(true));
        }

        $object->setUpdatedAt($this->formatDate(true));

        return parent::_beforeSave($object);
    }
}