<?php
/**
 * Created by PhpStorm.
 * User: matheus
 * Date: 19/05/19
 * Time: 12:46
 */

class Signativa_Braspag_Model_Source_Provider_Bankslip extends Signativa_Braspag_Model_Source_Abstract
{
    private $providers = [
        'Bradesco2',
        'BancoDoBrasil',
        'BancoDoBrasil2',
        'ItauShopline',
        'Itau2',
        'Santander2',
        'Caixa2',
        'CitiBank2',
        'BankOfAmerica'
    ];

    public function toOptionArray()
    {
        $result = [];
        foreach ($this->providers as $provider) {
            $result[] =  [
                'label' => $provider,
                'value' => $provider
            ];
        }

        return $result;
    }
}