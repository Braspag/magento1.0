<?php
/**
 * Created by PhpStorm.
 * User: matheus
 * Date: 19/05/19
 * Time: 17:13
 */

class Signativa_Braspag_Model_Source_Installments extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        $result = [];

        for ($i = 1; $i <= 12; $i++) {
            $result[] = [
                'label' => $this->getHelper()->__('%d installments(s)', $i),
                'value' => $i
            ];
        }

        return $result;
    }
}