<?php


class Signativa_Braspag_Model_Source_Cybersource_ShippingMethods extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        $result = [];
        $result [] = [
            'label' => $this->getHelper()->__('Not defined'),
            'value' => ''
        ];

        $methods = $this->getShippingConfig()->getActiveCarriers();
        foreach ($methods as $shippingCode => $shippingModel) {
            $result[] = [
                'label' => Mage::getStoreConfig('carriers/'.$shippingCode.'/title'),
                'value' => $shippingCode
            ];
        }

        return $result;
    }

    /**
     * @return Mage_Core_Model_Abstract|Mage_Shipping_Model_Config
     */
    public function getShippingConfig()
    {
        return Mage::getSingleton('shipping/config');
    }
}