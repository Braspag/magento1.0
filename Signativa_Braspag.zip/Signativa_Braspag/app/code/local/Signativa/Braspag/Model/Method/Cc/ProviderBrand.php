<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/16/2019
 * Time: 8:58 PM
 */

class Signativa_Braspag_Model_Method_Cc_ProviderBrand
{
    protected $relation = [
        'Cielo' => ['Visa', 'Master', 'Amex', 'Elo', 'Aura', 'Jcb', 'Diners', 'Discover'],
        'Cielo30' => ['Visa', 'Master', 'Amex', 'Elo', 'Aura', 'Jcb', 'Diners', 'Discover', 'Hipercard', 'Hiper'],
        'Redecard' => ['Visa', 'Master', 'Hipercard', 'Diners'],
        'Rede' => ['Visa', 'Master', 'Hipercard', 'Hiper', 'Diners', 'Elo', 'Amex'],
        'Rede2' => ['Visa', 'Master', 'Hipercard', 'Hiper', 'Diners', 'Elo', 'Amex'],
        'Getnet' => ['Visa', 'Master', 'Elo', 'Amex'],
        'GlobalPayments' => ['Visa', 'Master'],
        'Stone' => ['Visa', 'Master', 'Hipercard', 'Elo'],
        'FirstData' => ['Visa', 'Master', 'Cabal'],
        'Sub1' => ['Visa', 'Master', 'Diners', 'Amex', 'Discover', 'Cabal'],
        'Banorte' => ['Visa', 'Master', 'Carnet'],
        'Credibanco' => ['Visa', 'Master', 'Diners', 'Amex', 'Credential'],
        'Transbank' => ['Visa', 'Master', 'Diners', 'Amex'],
        'RedeSitef' => ['Visa', 'Master', 'Hipercard', 'Hiper', 'Diners'],
        'CieloSitef' => ['Visa', 'Master', 'Amex', 'Elo', 'Aura', 'Jcb', 'Diners', 'Discover'],
        'SantanderSitef' => ['Visa', 'Master']
    ];

    public function getBrandsByProvider($provider)
    {
        return $this->relation[$provider] ?? null;
    }

    public function getProviders()
    {
        return array_keys($this->relation);
    }
}