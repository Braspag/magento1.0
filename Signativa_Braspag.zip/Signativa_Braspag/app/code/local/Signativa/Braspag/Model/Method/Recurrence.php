<?php


class Signativa_Braspag_Model_Method_Recurrence extends Signativa_Braspag_Model_Method_Abstract
{

    protected $method = 'recurrence';
    protected $_canCapture = true;
    protected $_formBlockType = 'braspag/method_cc_form';
    protected $_infoBlockType = 'braspag/method_cc_info';
    /**
     * Prepare additional information into payment
     * @param $payment
     * @param $information \Braspag\API\Sale
     * @return mixed
     */
    public function setAdditionalInformation($payment, $information)
    {
        $paymentInfo = $information->getPayment();
        $payment->setAdditionalInformation('provider', $paymentInfo->getProvider());
        $payment->setAdditionalInformation('payment_id', $paymentInfo->getPaymentId());
        $payment->setAdditionalInformation('parent_order_id', $information->getMerchantOrderId());
        if ($paymentInfo->getFraudAnalysis()) {
            $payment->setAdditionalInformation('cybersource_status', $paymentInfo->getFraudAnalysis()->getStatus());
        }
    }

    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param $amount
     * @return \Braspag\API\Sale
     * @throws Varien_Exception
     */
    protected function readyOrder($payment, $amount)
    {
        // TODO: Implement readyOrder() method.
    }

    public function capture(Varien_Object $payment, $amount)
    {
        $this->setAdditionalInformation($payment, $this->getParentSale());
        return $this;
    }

    public function getParentSale() : \Braspag\API\Sale
    {
        return Mage::registry('parent_info');
    }
}