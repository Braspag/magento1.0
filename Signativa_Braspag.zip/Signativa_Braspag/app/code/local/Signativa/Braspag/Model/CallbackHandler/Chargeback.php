<?php


class Signativa_Braspag_Model_CallbackHandler_Chargeback extends Signativa_Braspag_Model_CallbackHandler_Abstract
{
    /**
     * Handles refund callback
     * @return $this
     * @throws \Braspag\API\Request\BraspagRequestException
     */
    public function execute()
    {
        /**
         * @var $sale \Braspag\API\Sale
         */
        $sale = $this->readySale();

        $order = $this->getOrderByIncrementId($sale->getMerchantOrderId());
        if (!$order->canCreditmemo()) {
            $this->log('[Braspag Callback] received chargeback for order: '. $order->getIncrementId().' but could not create credit memo for it');
            return $this;
        }
        //try to create credit memo for it
        $this->createCreditmemo($order);

        return $this;
    }
}