<?php

/**
 * Customer Example
 *   "Customer":
 * {
 * "Name":"Nome do Comprador",
 * "Identity":"12345678909",
 * "IdentityType":"CPF",
 * "Address":{
 * "Street":"Alameda Xingu",
 * "Number":"512",
 * "Complement":"27 andar",
 * "ZipCode":"12345987",
 * "City":"São Paulo",
 * "State":"SP",
 * "Country":"BRA",
 * "District":"Alphaville"
 * }
 */
class Signativa_Braspag_Model_DataHandler_Customer implements Signativa_Braspag_Model_DataHandler_Data
{
    const CPF_IDENTITY = 'CPF';

    const CNPJ_IDENTITY = 'CNPJ';

    /**
     * @param $customerData Mage_Customer_Model_Customer
     * @return stdClass
     * @throws Varien_Exception
     */
    public function prepare($customerData)
    {
        $data = new stdClass();
        //Setting the customer name
        $data->Name = $customerData->getName();
        //preparing the customer identity
        $identity = $customerData->getData($this->getIdentityAttribute());
        //removes non digits from customers identity
        $identity = $this->filterDigits($identity);
        //if length of identity higher than 11 is a cnpj else a cpf
        $data->IdentityType = strlen($identity) > 11 ? self::CNPJ_IDENTITY : self::CPF_IDENTITY;
        $data->Identity = $identity;
        //preparing the customer address
        $data->Address = $this->prepareAddress($customerData->getDefaultBillingAddress());

        $data->DeliveryAddress = $this->prepareAddress($customerData->getDefaultShippingAddress());


        return $data;
    }

    /**
     * @return \Braspag\API\Customer
     */
    public function getInstance()
    {
        return new \Braspag\API\Customer();
    }

    /**
     * @param $address Mage_Customer_Model_Address|Mage_Sales_Model_Quote_Address
     * @return stdClass
     * @throws Varien_Exception
     */
    public function prepareAddress($address, $isIso3=true)
    {
        $addressObject = new stdClass();

        $addressObject->ZipCode = $this->filterDigits($address->getPostcode());

        $addressObject->City = Mage::helper('braspag')->replaceSpecialChars($address->getCity());

        $addressObject->State = $address->getRegionCode();
        if ($isIso3)
            $addressObject->Country = $address->getCountryModel()->getIso3Code();
        else
            $addressObject->Country = $address->getCountryModel()->getIso2Code();
        foreach ($this->prepareStreet($address) as $attr => $value) {
            $addressObject->$attr = $value;
        }

        return $addressObject;
    }

    public function getIdentityAttribute()
    {
        return Mage::helper('braspag')->getBaseConfig('customer_identity');
    }

    public function filterDigits($identity)
    {
        return preg_replace("/[^\d]/", '', $identity);
    }

    /**
     * @param $address Mage_Customer_Model_Address
     * @return array
     */
    protected function prepareStreet($address)
    {
        return [
            "Street" => Mage::helper('braspag')->replaceSpecialChars($address->getStreet(Mage::helper('braspag')->getBaseConfig('street_field'))),
            "Number" => $address->getStreet(Mage::helper('braspag')->getBaseConfig('number_field')),
            "Complement" => Mage::helper('braspag')->replaceSpecialChars($address->getStreet(Mage::helper('braspag')->getBaseConfig('complement_field'))),
            "District" => Mage::helper('braspag')->replaceSpecialChars($address->getStreet(Mage::helper('braspag')->getBaseConfig('neighborhood_field')))
        ];
    }
}