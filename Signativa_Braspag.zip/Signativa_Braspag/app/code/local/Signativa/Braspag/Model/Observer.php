<?php

class Signativa_Braspag_Model_Observer extends Varien_Object
{
    const AUTOLOAD_PATH = DS . 'braspag-php-sdk' . DS . 'vendor' . DS . 'autoload.php';

    const RECURRENCE_TRAIT = 'Signativa_Braspag_Trait_Recurrence';

    public function init()
    {
        include_once(Mage::getBaseDir('lib') . self::AUTOLOAD_PATH);
    }

    /**
     * Used when magento is checking if method is available for quote, this is needed to prevent any other methods
     * to create a non recurrent order
     * @param Varien_Event_Observer $event
     * @return $this
     */
    public function filterWhenRecurrent(Varien_Event_Observer $event)
    {
        //We need to check first if recurrence is active
        if (!$this->getRecurrenceHelper()->getConfig('active')) {
            return $this;
        }
        /**
         * @var $quote Mage_Sales_Model_Quote
         * @var $method Mage_Payment_Model_Method_Abstract
         */
        $quote = $event->getEvent()->getQuote();
        $method = $event->getEvent()->getMethodInstance();
        $result = $event->getEvent()->getResult();
        if ($this->getRecurrenceHelper()->allowNonRecurrentOnRecurrentCheckout() &&
            $quote->getData('is_order_recurrence') === '1'){
            if (in_array($method->getCode(), $this->getRecurrenceHelper()->getAllowedMethods()) && (!Mage::registry('is_recurrence_create')))
            {
                $result->isAvailable = true;
            } else {
                $result->isAvailable = false;
            }
            return $this;
        }
        //we also use this event to only allow the use of the recurrence method when creating recurrences of an order
        if ($method->getCode() == 'braspag_recurrence' && Mage::registry('is_recurrence_create')) {
            $result->isAvailable = true;
        } else {
            if ($method->getCode() == 'braspag_recurrence') {
                $result->isAvailable = false;
            } else {
                $result->isAvailable = $quote->getData('is_order_recurrence') != '1' && $result->isAvailable || ($quote->getData('is_order_recurrence') === '1' && in_array(self::RECURRENCE_TRAIT,
                            class_uses($method)));
            }
        }

        return $this;
    }

    /**
     * @param $event
     * @return $this
     * @throws Mage_Core_Exception
     */
    public function cartProductAddAfter($event)
    {
        if (!$this->getRecurrenceHelper()->getConfig('active')) {
            return $this;
        }
        /**
         * @var Mage_Catalog_Model_Product $product
         * @var Mage_Sales_Model_Quote $quote
         */
        $product = $event->getProduct();
        $quote = $event->getQuoteItem()->getQuote();
        $item = $event->getQuoteItem();
        $isRecurrence = Mage::app()->getRequest()->getPost('recurrence');
	    $isRecurrence = filter_var($isRecurrence, FILTER_VALIDATE_BOOLEAN);
        if($isRecurrence){
            $quote->setData('is_order_recurrence','1');
            if($product->getData('braspag_recurrence_price') && $product->getData('braspag_recurrence_price') > 0){
                $this->getRecurrenceHelper()->setRecurrentPriceCart($item, $product->getData('braspag_recurrence_price'));
            }else{
                $this->getRecurrenceHelper()->setRecurrentPriceCart($item, $product->getData('price'));
            }
            $this->validateProduct($product, $quote);
        }else{
            if($product->getData('braspag_is_recurrent') == '2' ){
                $this->validateProduct($product, $quote,true);
                $this->getRecurrenceHelper()->setRecurrentPriceCart($item, $product->getData('price'));
            }else{
                $this->validateProduct($product, $quote);
            }
        }
        return $this;
    }

    public function salesQuoteRemoveItem($event)
    {
        $quote    = $event->getQuoteItem()->getQuote();
        $item     = $event->getQuoteItem()->getProduct();
        $product  = Mage::getModel('catalog/product')->load($item->getId());

        if($product->getData('braspag_is_recurrent') == '1' || $product->getData('braspag_is_recurrent') == '2'){
            if($quote->getData('is_order_recurrence') === '1') {
                $quote->setData('is_order_recurrence', '0');
            }
        }

        return $this;
    }

    /**
     * Prevent item mixing in cart, mostly products with different recurrence periods and duration
     * @param Mage_Catalog_Model_Product $product
     * @param Mage_Sales_Model_Quote $quote
     * @return $this
     * @throws Mage_Core_Exception
     */
    protected function validateProduct(Mage_Catalog_Model_Product $product, Mage_Sales_Model_Quote $quote, $isComprarRecorrent = null)
    {
        if ($quote->getItemsQty() == 0) {
            return $this;
        }

        if($isComprarRecorrent === true){
            if($quote->getData('is_order_recurrence') == '1'){
                Mage::throwException($this->getHelper()->__('Cannot add non recurrent product to cart, please place current order'));
            }
            return $this;
        }

        if ($quote->getData('is_order_recurrence') == '1' && !$product->getBraspagIsRecurrent()) {
            Mage::throwException($this->getHelper()->__('Cannot add non recurrent product to cart, please place current order'));
        }

        if ($quote->getData('is_order_recurrence') != '1' && $product->getBraspagIsRecurrent()) {
            Mage::throwException($this->getHelper()->__('Cannot add recurrent product to cart, please place current order'));
        }

        if ($quote->getData('is_order_recurrence') == '1' && $product->getBraspagIsRecurrent()) {
            /**
             * @var $item Mage_Sales_Model_Quote_Item
             */
            foreach ($quote->getAllItems() as $item) {
                if ($item->getProduct()->getBraspagRecurrenceDuration() != $product->getBraspagRecurrenceDuration() ||
                    $item->getProduct()->getBraspagRecurrencePeriod() != $product->getBraspagRecurrencePeriod()
                ) {
                    Mage::throwException($this->getHelper()->__('Cannot add recurrent product to cart, please place current order'));
                }
            }
        }

        return $this;
    }

    /**
     * @return Mage_Core_Helper_Abstract|Signativa_Braspag_Helper_Data
     */
    protected function getHelper()
    {
        return Mage::helper('braspag');
    }

    /**
     * @return Mage_Core_Helper_Abstract|Signativa_Braspag_Helper_Recurrence
     */
    protected function getRecurrenceHelper()
    {
        return Mage::helper('braspag/recurrence');
    }

    /**
     * Adds cybersource js if active
     * @return $this
     */
    public function addCybersourceJs()
    {
        if (!$this->getHelper()->getAnyConfig('payment/braspag_cybersource/active')) {
            return $this;
        }
        /**
         * @var Mage_Page_Block_Html_Head $head
         */
        $head = Mage::app()->getLayout()->getBlock('head');
        $head->append(Mage::app()->getLayout()->createBlock('braspag/cybersource'));

        return $this;
    }

    /**
     * On order_place_after verifies if order is recurrent and if it is, creates a recurrence registry of it
     * @param $observer
     * @return $this
     * @throws Exception
     */
    public function createRecurrence($observer)
    {
        if (!$this->getHelper()->getConfig('recurrence', 'active') || Mage::registry('is_recurrence_create')) {
            return $this;
        }
        /**
         * @var Mage_Sales_Model_Order $order
         */
        $order = $observer->getEvent()->getOrder();

        if ($this->getRecurrenceHelper()->isCartRecurrent($order->getQuote()) && (in_array(self::RECURRENCE_TRAIT, class_uses($order->getPayment()->getMethodInstance())))) {
            /**
             * @var Signativa_Braspag_Model_Recurrence $recurrenceInstance
             * @var Mage_Sales_Model_Order_Item $item
             */
            $recurrenceInstance = Mage::getModel('braspag/recurrence');
            $recurrenceInstance->createFromOrder($order);
            foreach ($order->getAllVisibleItems() as $item) {
                $recurrenceInstance->addItem($item);
            }
            $recurrenceInstance->save();
            $recurrenceInstance->addTransaction($order);
        }
        return $this;
    }

    /**
     * Prevent recurrent mixing when cart merge
     * @param $observer
     * @return $this
     */
    public function mergeItemsCleaner($observer)
    {
        if (!$this->getHelper()->getConfig('recurrence', 'active')) {
            return $this;
        }

        if ($this->getRecurrenceHelper()->isCartRecurrent($observer->getQuote()) || $this->getRecurrenceHelper()->isCartRecurrent($observer->getSource())) {
            foreach ($observer->getSource()->getAllItems() as $item) {
                $item->isDeleted(true);
                if ($item->getHasChildren()) {
                    foreach ($item->getChildren() as $child) {
                        $child->isDeleted(true);
                    }
                }
            }
            $observer->getSource()->collectTotals()->save();
        }
        return $this;
    }

    /**
     * @param $observer
     * @return $this
     */
    public function preventNonSplitMethods($observer)
    {
        //verify if split is active and if the config allows non split methods to work on splittable orders
        if (!$this->getSplitManager()->isActive() && !$this->getSplitManager()->allowNonSplitOnSplit()) {
            return $this;
        }
        /**
         * @var Mage_Sales_Model_Quote $quote
         * @var Mage_Payment_Model_Method_Abstract $method
         */
        $quote = $observer->getEvent()->getQuote();
        $method = $observer->getEvent()->getMethodInstance();
        $result = $observer->getEvent()->getResult();
        if (!$quote) {
            return $this;
        }

        if (!($method instanceof Signativa_Braspag_Model_Method_Abstract)) {
            $result->isAvailable = false;
            return $this;
        }

        if (!$this->getSplitManager()->getHelper()->isCartSplittable($quote)) {
            return $this;
        }

        if (!$method->canSplit()) {
            $result->isAvailable = false;
        }

        return $this;
    }

    /**
     * @return Signativa_Braspag_Model_Split
     */
    public function getSplitManager(): Signativa_Braspag_Model_Split
    {
        return Mage::getSingleton('braspag/split');
    }

    /**
     * @param Varien_Event_Observer $observer
     * @return $this
     */
    public function preventAuthCaptureOnSplit(Varien_Event_Observer $observer)
    {
        if ($this->getData('prevent_auth_executed')) {
            return $this;
        }
        if ($this->getSplitManager()->isActive() &&
            (
                $this->getHelper()->getConfig('cc',
                    'payment_action') == Mage_Payment_Model_Method_Abstract::ACTION_AUTHORIZE_CAPTURE ||
                $this->getHelper()->getConfig('oneclick',
                    'payment_action') == Mage_Payment_Model_Method_Abstract::ACTION_AUTHORIZE_CAPTURE
            )
        ) {
            Mage::getConfig()->saveConfig('payment/braspag_cc/payment_action',
                Mage_Payment_Model_Method_Abstract::ACTION_AUTHORIZE);
            Mage::getConfig()->saveConfig('payment/braspag_oneclick/payment_action',
                Mage_Payment_Model_Method_Abstract::ACTION_AUTHORIZE);
            Mage::getSingleton('adminhtml/session')->addWarning($this->getHelper()->__('With split enabled only authorize is allowed'));
            $this->setData('prevent_auth_executed', true);
        }
        return $this;
    }

    /**
     * @param Varien_Event_Observer $event
     * @return $this
     */
    public function sendNewOrderEmail(Varien_Event_Observer $event)
    {
        try {
            $order = $this->getCheckoutSession()->getLastRealOrder();
            if ($order->getId()) {
                $methodInstance = $order->getPayment()->getMethodInstance();
                if (!is_object($methodInstance)) {
                    return $this;
                }
                if ($methodInstance instanceof Signativa_Braspag_Model_Method_Abstract) {
                    if (method_exists($methodInstance, 'getOrderPlaceRedirectUrl')) {
                        $order->queueNewOrderEmail();
                    }
                }
            }
        }
        catch(Exception $e) {
            Mage::logException($e);
        }

        return $this;
    }

    /**
     * @return Mage_Core_Model_Abstract|Mage_Checkout_Model_Session
     */
    protected function getCheckoutSession()
    {
        return Mage::getSingleton('checkout/session');
    }
}
