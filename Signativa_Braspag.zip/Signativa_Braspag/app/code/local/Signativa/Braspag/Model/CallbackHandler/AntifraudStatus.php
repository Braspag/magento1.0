<?php


use Braspag\API\Payment;
use Braspag\API\Request\BraspagRequestException;

class Signativa_Braspag_Model_CallbackHandler_AntifraudStatus extends Signativa_Braspag_Model_CallbackHandler_Abstract
{
    use Signativa_Braspag_Trait_FraudAnalysis;

    const UNKNOWN_STATUS = [0, 'Pendent'];

    const ACCEPT_STATUS = [1, 'Accept'];

    const REJECT_STATUS = [2, 'Reject'];

    const REVIEW_STATUS = [3, 'Review'];

    const ABORT_STATUS = [4, 'ProviderError'];

    const UNFINISHED_STATUS = [5, 'Unfinished'];

    /**
     * @return $this
     * @throws BraspagRequestException
     * @throws Mage_Core_Exception
     */
    public function execute()
    {
        $sale = $this->readySale();
        /**
         * @var $payment Payment
         */
        $payment = $sale->getPayment();

        $order = $this->getOrderByIncrementId($sale->getMerchantOrderId());
        //if we have a cybersource transaction id it is in complete mode
        $antiFraudTransactionId = $order->getPayment()->getAdditionalInformation('cybersource_transaction_id');
        if ($antiFraudTransactionId) {
            $analysisResult = $this->getAnalysis($antiFraudTransactionId);
            $newStatus = $analysisResult->getStatus();
        }
        else {
            $newStatus = $payment->getFraudAnalysis()->getStatus();
        }
        $oldStatus = $order->getPayment()->getAdditionalInformation('cybersource_status');

        if ($oldStatus == $newStatus) {
            $this->log('[Braspag Callback] - Antifraud Status is unchanged for order: '. $sale->getMerchantOrderId());
            return $this;
        }

        $order->getPayment()->setAdditionalInformation('cybersource_status', $newStatus)->save();

        if (in_array($newStatus, self::ACCEPT_STATUS)) {  // if transaction has been accepted by anti fraud
            if ($this->getCybersource()->captureOnAccept()) {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' capturing order: '. $sale->getMerchantOrderId());
                $this->createInvoice($order);
            }
            else {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' but not capturing order: '. $sale->getMerchantOrderId());
            }
        }
        else if (in_array($newStatus, self::REJECT_STATUS)) {
            if ($this->getCybersource()->cancelOnReject()) {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' canceling order: '. $sale->getMerchantOrderId());
                $this->cancelOrder($order);
            }
            else {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' but not canceling order: '. $sale->getMerchantOrderId());
            }
        }
        else if (in_array($newStatus, self::REVIEW_STATUS)) {
            $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' reviewing order: '. $sale->getMerchantOrderId());
        }
        else if (in_array($newStatus, self::ABORT_STATUS)) {
            if ($this->getCybersource()->cancelOnAbort()) {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' canceling order: '. $sale->getMerchantOrderId());
                $this->cancelOrder($order);
            }
            else {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' but not canceling order: '. $sale->getMerchantOrderId());
            }
        }
        else if (in_array($newStatus, self::UNFINISHED_STATUS)) {
            if ($this->getCybersource()->cancelOnUnfinished()) {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' canceling order: '. $sale->getMerchantOrderId());
                $this->cancelOrder($order);
            }
            else {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' but not canceling order: '. $sale->getMerchantOrderId());
            }
        }
        else if (in_array($newStatus, self::UNKNOWN_STATUS)) {
            if ($this->getCybersource()->cancelOnUnknown()) {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' canceling order: '. $sale->getMerchantOrderId());
                $this->cancelOrder($order);
            }
            else {
                $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' but not canceling order: '. $sale->getMerchantOrderId());
            }
        }
        else {
            $this->log('[Braspag Callback] - Antifraud Status: '.$newStatus.' is not predicted for order: '. $sale->getMerchantOrderId());
        }
        return $this;
    }

    static function getConstants() {
        $oClass = new ReflectionClass(__CLASS__);
        return $oClass->getConstants();
    }

}