<?php


class Signativa_Braspag_Model_Payment_ReasonCode
{
    const Successful = 0;
    const AffiliationNotFound = 1;
    const IssuficientFunds = 2;
    const CouldNotGetCreditCard = 3;
    const ConnectionWithAcquirerFailed = 4;
    const InvalidTransactionType = 5;
    const InvalidPaymentPlan = 6;
    const Denied = 7;
    const Scheduled = 8;
    const Waiting = 9;
    const Authenticated = 10;
    const NotAuthenticated = 11;
    const ProblemsWithCreditCard = 12;
    const CardCanceled = 13;
    const BlockedCreditCard = 14;
    const CardExpired = 15;
    const AbortedByFraud = 16;
    const CouldNotAntifraud = 17;
    const TryAgain = 18;
    const InvalidAmount = 19;
    const ProblemsWithIssuer = 20;
    const InvalidCardNumber = 21;
    const TimeOut = 22;
    const CartaoProtegidoIsNotEnabled = 23;
    const PaymentMethodIsNotEnabled = 24;
    const TransactionalError = 37;
    const InvalidRequest = 98;
    const InternalError = 99;

    public static $errorCodes = [
        self::AffiliationNotFound,
        self::IssuficientFunds,
        self::CouldNotGetCreditCard,
        self::ConnectionWithAcquirerFailed,
        self::InvalidTransactionType,
        self::InvalidPaymentPlan,
        self::Denied,
        self::NotAuthenticated,
        self::ProblemsWithCreditCard,
        self::CardCanceled,
        self::BlockedCreditCard,
        self::CardExpired,
        self::AbortedByFraud,
        self::CouldNotAntifraud,
        self::TryAgain,
        self::InvalidAmount,
        self::ProblemsWithIssuer,
        self::InvalidCardNumber,
        self::TimeOut,
        self::CartaoProtegidoIsNotEnabled,
        self::PaymentMethodIsNotEnabled,
        self::InvalidRequest,
        self::InternalError,
        self::TransactionalError,
    ];
}