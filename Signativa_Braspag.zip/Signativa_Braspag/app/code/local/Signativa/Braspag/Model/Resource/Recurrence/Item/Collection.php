<?php


class Signativa_Braspag_Model_Resource_Recurrence_Item_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{

    protected function _construct()
    {
        $this->_init('braspag/recurrence_item');
    }

    /**
     * @param Signativa_Braspag_Model_Recurrence $recurrence
     * @return Mage_Eav_Model_Entity_Collection_Abstract
     */
    public function filterByRecurrence(Signativa_Braspag_Model_Recurrence $recurrence)
    {
        return $this->addFieldToFilter('recurrence_id', $recurrence->getId());
    }

    /**
     * @return Mage_Core_Model_Resource_Db_Collection_Abstract|Signativa_Braspag_Model_Resource_Recurrence_Item_Collection
     */
    public function joinWithProducts()
    {
        $this->getSelect()->joinLeft(['product' => 'catalog_product_entity'], '`main_table`.`sku` = `product`.`sku`', array('product_id' => 'product.entity_id'));

        return $this;
    }
}