<?php

use Braspag\API\CreditCard;
use Braspag\API\FraudAnalysis;
use Braspag\API\Payment;
use Braspag\API\Sale;

class Signativa_Braspag_Model_Method_Cc extends Signativa_Braspag_Model_Method_Abstract implements Signativa_Braspag_Model_Validation_Card
{
    //Adding recurrent trait to CC
    use Signativa_Braspag_Trait_Recurrence;
    //adding fraud analysis trait
    use Signativa_Braspag_Trait_FraudAnalysis;

    protected $method = 'cc';
    protected $_formBlockType = 'braspag/method_cc_form';
    protected $_infoBlockType = 'braspag/method_cc_info';
    protected $_canAuthorize = true;
    protected $_canCapture = true;
    protected $_canCapturePartial = true;
    protected $_canVoid = true;
    protected $_canRefund = true;
    protected $_canRefundInvoicePartial = true;

    protected $canSplit = true;

    const SAVE_CC_KEY = 'braspag_save_cc';


    public function assignData($data)
    {
        if (!($data instanceof Varien_Object)) {
            $data = new Varien_Object($data);
        }
        $info = $this->getInfoInstance();

        $date = $this->prepareExpireDate($data->getData('braspag_cc_expiration'));
        if ($data->getData('braspag_cc_cavv')) {
            $this->registerAntiFraud($data);
        }

        $info->setCcType($data->getData('braspag_cc_flag'))
            ->setCcNumber($data->getData('braspag_cc_number'))
            ->setPoNumber($data->getData('braspag_cc_installments') ?? 1)
            ->setCcCid($data->getData('braspag_cc_cvv'))
            ->setCcExpMonth($date[0])
            ->setCcExpYear($date[1])
            ->setCcLast4(substr($data->getData('braspag_cc_number'), -4))
            ->setCcOwner($data->getData('braspag_cc_name'));

        Mage::register(self::SAVE_CC_KEY, (bool)$data->getData('braspag_cc_save_cc'), true);

        return parent::assignData($data);
    }
    protected function handleFraud($payment, Payment $payResult)
    {
        if ($this->getCybersource()->isActive() &&
            $this->getCybersource()->isBasicMode()
        ) {
            try {
                $this->handleAnalysis($payResult->getFraudAnalysis(), $payment);
            }
            catch (Signativa_Braspag_VoidTransactionException $e) {
                $this->void($payment);
                Mage::logException($e);
                Mage::throwException($this->_getHelper()->__('Order cannot be placed, denied by antifraud'));
            }
            catch (Signativa_Braspag_AnalysisErrorException $e) {
                Mage::logException($e);
                Mage::throwException($this->_getHelper()->__('Order cannot be placed, denied by antifraud'));

            }
        }
        if ($this->getCybersource()->isActive() &&
            $this->getCybersource()->isCompleteMode() &&
            $this->getCybersource()->getSequence() == FraudAnalysis::AUTHORIZE_FIRST_SEQUENCE
        ) {
            $this->analyseOrder($payment, $payResult);
        }
    }
    public function authorize(Varien_Object $payment, $amount)
    {
        parent::authorize($payment, $amount);
        //prepare order information
        $sale = $this->readyOrder($payment, $amount);
        //place the order through the Braspag API
        $result = $this->placeOrder($sale);
        //set additional information to payment
        $this->setAdditionalInformation($payment, $result);
        /**
         * @var $payResult Payment
         */
        $payResult = $result->getPayment();
        //verify anti fraud if allowed
        $this->handleFraud($payment, $payResult);
        //set transaction id to allow the magento payment flow
        $payment->setIsTransactionClosed(false);

        $payment->setTransactionId($payResult->getAuthorizationCode());
        //save credit card token
        /**
         * @var $cc CreditCard
         */
        $cc = $payResult->getCreditCard();
        if ($cc->getSaveCard()) {
            $this->saveCcHash($payment, $cc);
        }
        return $this;
    }

    /**
     * @param $payment
     * @param $information Sale
     * @return mixed|void
     */
    public function setAdditionalInformation($payment, $information)
    {
        /**
         * @var $paymentInfo Payment
         */
        $paymentInfo = $information->getPayment();
        $payment->setAdditionalInformation('provider', $paymentInfo->getProvider());
        $payment->setAdditionalInformation('payment_id', $paymentInfo->getPaymentId());
        if ($paymentInfo->getFraudAnalysis()) {
            $payment->setAdditionalInformation('cybersource_status', $paymentInfo->getFraudAnalysis()->getStatus());
        }
        /**
         * @var $recurrent Braspag\API\RecurrentPayment
         */
        if ($recurrent = $paymentInfo->getRecurrentPayment()) {
            $payment->setAdditionalInformation('recurrence_next', $recurrent->getNextRecurrency());
            $payment->setAdditionalInformation('recurrence_end', $recurrent->getEndDate());
            $payment->setAdditionalInformation('recurrence_payment_id', $recurrent->getRecurrentPaymentId());
            $payment->setAdditionalInformation('recurrence_interval', $recurrent->getInterval());
        }

        if ($paymentInfo->getDoSplit()) {
            $payment->setAdditionalInformation('split_merchant', Zend_Json::decode(Zend_Json::encode($paymentInfo->getSplitPayments())));
        }

    }

    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param $amount
     * @param bool $capture
     * @return Sale
     * @throws Varien_Exception
     * @throws Exception
     */
    protected function readyOrder($payment, $amount, $capture = false)
    {
        /**
         * @var $quote Mage_Sales_Model_Quote
         */
        $amount = $this->prepareAmount($amount);

        $quote = Mage::getSingleton('checkout/session')->getQuote();

        if ($this->getCybersource()->isActive() &&
            $this->getCybersource()->isCompleteMode() &&
            $this->getCybersource()->getSequence() == FraudAnalysis::ANALYSE_FIRST_SEQUENCE
        ) {
            $this->analyseOrder($payment);
        }
        $sale = $this->initSale($quote->getReservedOrderId());

        $sale->setCustomer(
            $this->prepareCustomer($quote)
        );

        $pay = $sale->payment($amount, $payment->getPoNumber());

        //sets creditcard information
        $pay->setType(Payment::PAYMENTTYPE_CREDITCARD)
            ->creditCard($payment->getCcCid(), ucfirst($payment->getCcType()))
            ->setExpirationDate($payment->getCcExpMonth() . '/' . $payment->getCcExpYear())
            ->setCardNumber(Mage::helper('braspag')->filterDigits($payment->getCcNumber()))
            ->setHolder($payment->getCcOwner())
            ->setSaveCard(Mage::registry(self::SAVE_CC_KEY));

        $pay->setCapture($capture);
        //applies split
        $this->applySplit($pay, $quote, $payment);

        //handle a recurrent cart
        if ($this->getRecurrenceHelper()->isCartRecurrent($quote)) {
            $pay = $this->addRecurrenceToPayment($pay, $this->getRecurrenceHelper()->getRecurrentItem($quote));
        }
        //verify if anti fraud (ybersource is enabled
        if ($this->getCybersource()->isActive() && $this->getCybersource()->isBasicMode()) {
            $pay->setFraudAnalysis($this->prepareAntiFraud($payment));
        }
        //verify if authentication is provided
        if ($data = Mage::registry(self::ANTIFRAUD_INFO_CONTAINER)) {
            $pay->setAuthenticate(true)
                ->setExternalAuthentication($data)
                ->setReturnUrl($this->getReturnUrl());
        } else {
            if ($this->getThreeDs()->isActive()) {
                throw new Exception($this->_getHelper()->__('No anti-fraud data was sent'));
            }
        }
        $pay->setProvider($this->getProvider());

        return $sale;
    }

    /**
     * @param Varien_Object $payment
     * @param float $amount
     * @return $this|Mage_Payment_Model_Abstract|mixed
     * @throws Mage_Core_Exception
     * @throws Varien_Exception
     * @throws \Braspag\API\Request\BraspagRequestException
     */
    public function capture(Varien_Object $payment, $amount)
    {
        if ($this->getConfigPaymentAction() == self::ACTION_AUTHORIZE_CAPTURE) {
            $sale = $this->readyOrder($payment, $amount, true);
            $this->handlerOrder($sale, $payment);
            return $this;
        }
        return parent::capture($payment, $amount); // TODO: Change the autogenerated stub
    }

    /**
     * @param Sale $sale
     * @param $payment
     * @return mixed
     * @throws Mage_Core_Exception
     */
    protected function handlerOrder(Sale $sale, $payment)
    {
        //place the order through the Braspag API
        $result = $this->placeOrder($sale);
        //set additional information to payment
        $this->setAdditionalInformation($payment, $result);
        /**
         * @var $payResult Payment
         */
        $payResult = $result->getPayment();

        $this->handleFraud($payment, $payResult);
        //set transaction id to allow the magento payment flow
        $payment->setIsTransactionClosed(false);

        $payment->setTransactionId($payResult->getAuthorizationCode());
        /**
         * @var $cc CreditCard
         */
        //save credit card token
        $cc = $payResult->getCreditCard();
        if ($cc->getSaveCard()) {
            $this->saveCcHash($payment, $cc);
        }

        return $payment;
    }

    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param CreditCard $cc
     * @return Signativa_Braspag_Model_Method_Cc
     */
    public function saveCcHash(Mage_Sales_Model_Order_Payment $payment, CreditCard $cc)
    {
        try {
            $hash = Mage::getModel('braspag/hash')->setCustomerId($this->getCurrentCustomer()->getId())
                ->setCardHash($cc->getCardToken())
                ->setCardBrand($payment->getCcType())
                ->setLastFourDigits($payment->getCcLast4())
                ->save();
        } catch (Exception $e) {
            $this->log('Could not save CC token for customer ' . $this->getCurrentCustomer()->getId());
        }
        return $this;
    }

    /**
     * @param $brand
     * @return mixed
     * @throws Mage_Core_Exception
     */
    public function getCardRegex($brand)
    {
        $regexContainer = [
            "amex" => [
                "pattern" => "/^3[47][0-9]{13}$/",
                "valid_length" => [15]
            ],
            "diners" => [
                "pattern" => "/(^[35](?:0[0-5]|[68][0-9])[0-9]{11}$)|(^30[0-5]{11}$)|(^3095(\d{10})$)|(^36{12}$)|(^3[89](\d{12})$)/",
                "valid_length" => [14]
            ],
            "jcb" => [
                "pattern" => "/^35(2[89]|[3-8][0-9])/",
                "valid_length" => [16]
            ],
            "visa" =>
                [
                    "pattern" => "/^(4)(\d{12}|\d{15})$|^(606374\d{10}$)/",
                    "valid_length" => [16]
                ],
            'aura' => [
                "pattern" => "/^50[0-9]{14}$/",
                "valid_length" => [16]
            ],
            "master" => [
                "pattern" => "/^(5[1-5]\d{14}$)|^(2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d\d|7(?:[01]\d|20))\d{12}$)/",
                "valid_length" => [16]
            ],
            "elo" => [
                "pattern" => "/(^(636368|438935|504175|451416|636297|650901|650485|650541|650700|650720|650720|650720|655021|650405)\d{10})$|(^(5090|5067|4576|4011)\d{12})$|(^(50904|50905|50906)\d{11})$/",
                "valid_length" => [16]
            ],
            "discovery" => [

                "pattern" => "/^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)/",
                "valid_length" => [16]
            ],
            "hipercard" => [
                "pattern" => "/^(384100|384140|384160|606282)(\d{10}|\d{13})$/",
                "valid_length" => [19]
            ],
            "hiper" => [
                "pattern" => "/^(((637095)|(637612)|(637599)|(637609)|(637568))\d{0,10})$/",
                "valid_length" => [16]
            ]
        ];
        if (!isset($regexContainer[strtolower($brand)])) {
            Mage::throwException($this->_getHelper()->__('Invalid credit card'));
        }
        return $regexContainer[strtolower($brand)];
    }

    /**
     * @param $brand
     * @return int
     */
    public function getCvvLengthByBrand($brand)
    {
        if (strtolower($brand) == 'amex') {
            return 4;
        }
        return 3;
    }

    /**
     * @param $payment
     * @return FraudAnalysis
     * @throws Exception
     */
    public function prepareAntiFraud($payment)
    {
        return $this->getDataHandler()->handle('fraudAnalysis', $payment);
    }

    /**
     * @param $payment
     * @param $additionalData
     * @throws Exception
     */
    public function analyseOrder($payment, Payment $additionalData = null)
    {
        /**
         * @var \Braspag\API\Analysis $antiFraud
         */
        $antiFraud = $this->prepareAntiFraud($payment);
        if ($additionalData) {
            $antiFraud->setBraspagTransactionId($additionalData->getTid());
        }
        try {
            $this->handleAnalysis($this->sendToAnalysis($antiFraud), $payment);
        }
        catch (Signativa_Braspag_VoidTransactionException $e) {
            $this->void($payment);
            Mage::logException($e);
            Mage::throwException($this->_getHelper()->__('Order cannot be placed, denied by antifraud'));
        }
        catch (Signativa_Braspag_AnalysisErrorException $e) {
            Mage::logException($e);
            Mage::throwException($this->_getHelper()->__('Order cannot be placed, denied by antifraud'));

        }
    }
}