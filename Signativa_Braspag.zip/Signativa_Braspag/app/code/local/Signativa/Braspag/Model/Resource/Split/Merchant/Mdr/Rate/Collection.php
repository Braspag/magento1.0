<?php


class Signativa_Braspag_Model_Resource_Split_Merchant_Mdr_Rate_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{

    protected function _construct()
    {
        $this->_init('braspag/split_merchant_mdr_rate');
    }

    public function filterByMerchant(Signativa_Braspag_Model_Split_Merchant $merchant)
    {
        return $this->addFieldToFilter('merchant_id', $merchant->getId());
    }
}