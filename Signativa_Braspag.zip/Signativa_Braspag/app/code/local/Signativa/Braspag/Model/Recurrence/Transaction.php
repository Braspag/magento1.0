<?php


class Signativa_Braspag_Model_Recurrence_Transaction extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('braspag/recurrence_transaction');
    }

    /**
     * @return Mage_Sales_Model_Order
     * @throws Exception
     */
    public function getOrder(): Mage_Sales_Model_Order
    {
        if (!$this->getOrderId()) {
            throw new Exception('No order id defined');
        }
        return Mage::getModel('sales/order')->load($this->getOrderId());
    }
}