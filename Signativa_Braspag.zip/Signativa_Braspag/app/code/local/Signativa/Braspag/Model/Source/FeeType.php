<?php


class Signativa_Braspag_Model_Source_FeeType extends Signativa_Braspag_Model_Source_Abstract
{
    /**
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => 'simple',
                'label' => $this->getHelper()->__('Simple Fee')
            ],
            [
                'value' => 'composed',
                'label' => $this->getHelper()->__('Composed Fee')
            ]
        ];
    }
}