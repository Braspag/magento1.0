<?php

class Signativa_Braspag_Model_Product_Attribute_Duration extends Mage_Eav_Model_Entity_Attribute_Source_Abstract
{
    protected  $periods = [
        'Month',
        'Year'
    ];
    /**
     * @return array
     */
    public function getAllOptions()
    {
        $this->_options = [
            [
                'value' => '',
                'label' => Mage::helper('catalog')->__('Infinite'),
            ]
        ];

        foreach ($this->periods as $period) {
            for ( $i = 1; $i < 12; $i++) {
                $label = $period;
                if ($i > 1) {
                    $label = $label . 's';
                }

                $this->_options [] = [
                    'value' => $i.' '.$period,
                    'label' => Mage::helper('braspag')->__("%d $label", $i)
                ];
            }
        }

        return $this->_options;
    }
}
