<?php

use Braspag\API\Payment;
use Braspag\API\Sale;

class Signativa_Braspag_Model_Method_Bankslip_Pagador extends Signativa_Braspag_Model_Method_Bankslip
{
    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param $amount
     * @return Sale
     * @throws Exception
     */
    protected function readyOrder($payment, $amount)
    {
        /**
         * @var $quote Mage_Sales_Model_Quote
         */
        $amount = $this->prepareAmount($amount);

        $quote = Mage::getSingleton('checkout/session')->getQuote();

        $sale = $this->initSale($quote->getReservedOrderId());

        $sale->setCustomer(
            $this->prepareCustomer($quote)
        );
        $pay = $sale->payment($amount);

        $pay->setType(Payment::PAYMENTTYPE_BOLETO);

        $pay->setProvider($this->getProvider());

        return $sale;
    }
}