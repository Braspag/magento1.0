<?php

class Signativa_Braspag_Model_Method_Ewallet extends Signativa_Braspag_Model_Method_Abstract
{

    protected $method = 'ewallet';
    protected $_formBlockType = 'braspag/method_ewallet_form';
    protected $_infoBlockType = 'braspag/method_cc_info';
    protected $_canAuthorize = true;

    /**
     * @var Signativa_Braspag_Model_Ewallet
     */
    protected $ewalletHandler;

    public function assignData($data)
    {
        if (!($data instanceof Varien_Object)) {
            $data = new Varien_Object($data);
        }

        $this->getEwalletInstance()->addData($data->getData());

        $info = $this->getInfoInstance();

        $info->setCcType($data->getData('braspag_ewallet_cc_flag'))
            ->setCcLast4($data->getData('braspag_ewallet_last_four'));

        return parent::assignData($data);
    }

    /**
     * Prepare additional information into payment
     * @param $payment
     * @param $information
     * @return mixed
     */
    public function setAdditionalInformation($payment, $information)
    {
        // TODO: Implement setAdditionalInformation() method.
    }

    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param $amount
     * @return \Braspag\API\Sale
     * @throws Varien_Exception
     * @throws Exception
     */
    protected function readyOrder($payment, $amount)
    {
        /**
         * @var $quote Mage_Sales_Model_Quote
         */
        $amount = $this->prepareAmount($amount);

        $quote = Mage::getSingleton('checkout/session')->getQuote();
        if (!$quote->getId()) {
            $quote = Mage::registry('ewallet_quote');
        }

        $sale = $this->initSale($quote->getReservedOrderId());

        $sale->setCustomer(
            $this->prepareCustomer($quote)
        );
        /**
         * @var $pay \Braspag\API\Payment
         */
        $pay = $sale->payment($amount);

        $pay->setType(\Braspag\API\Payment::PAYMENTTYPE_EWALLET);

        $wallet = $sale->wallet($this->getEwalletHandler()->getEwalletName(), $this->getEwalletInstance()->getWalletKey());
        $wallet->setAdditionalData($this->getEwalletInstance()->getAdditionalData());

        $pay->setProvider($this->getProvider());
        return $sale;
    }

    /**
     * @return Signativa_Braspag_Model_Ewallet
     */
    public function getEwalletHandler() : Signativa_Braspag_Model_Ewallet
    {
        if (!$this->ewalletHandler) {
            $this->ewalletHandler = Mage::getModel('braspag/ewallet');
        }
        return $this->ewalletHandler;
    }

    /**
     * @return Signativa_Braspag_Model_Method_Ewallet_Abstract
     */
    public function getEwalletInstance()
    {
        return $this->getEwalletHandler()->getEwalletInstance();
    }
    public function authorize(Varien_Object $payment, $amount)
    {
        parent::authorize($payment, $amount);
        //prepare order information
        $sale = $this->readyOrder($payment, $amount);
        //place the order through the Braspag API
        $result = $this->placeOrder($sale);
        //set additional information to payment
        $this->setAdditionalInformation($payment, $result);
        /**
         * @var $payResult Payment
         */
        $payResult = $result->getPayment();
        //set transaction id to allow the magento payment flow
        $payment->setIsTransactionClosed(false);

        $payment->setTransactionId($payResult->getAuthorizationCode());

        return $this;
    }
}