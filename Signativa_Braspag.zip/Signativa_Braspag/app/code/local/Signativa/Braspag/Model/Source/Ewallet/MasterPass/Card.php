<?php


class Signativa_Braspag_Model_Source_Ewallet_MasterPass_Card extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        $result = [];
        foreach (Signativa_Braspag_Model_Method_Ewallet_MasterPass::CARD_NETWORKS as $card) {
            $result[] =  [
                'value' => $card,
                'label' => ucfirst($card)
            ];
        }

        return $result;
    }
}