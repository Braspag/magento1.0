<?php


class Signativa_Braspag_Model_Cron_OrderProcessor extends Varien_Object implements Signativa_Braspag_Model_Cron_Task
{
    use Signativa_Braspag_Trait_Magento;
    use Signativa_Braspag_Trait_Api;
    use Signativa_Braspag_Trait_Log;

    public function execute()
    {
        $orders = $this->getOrderCollection();
        $this->log('Processing orders, qty: '. $orders->count());
        /**
         * @var $order Mage_Sales_Model_Order
         */
        foreach ($orders as $order) {
            try {
                $paymentId = $order->getPayment()->getAdditionalInformation('payment_id');
                $sale = $this->getApi()->getSale($paymentId);
                $payment = $sale->getPayment();
                if (
                    $order->canInvoice() &&
                    $payment->getStatus() == Signativa_Braspag_Model_Payment::PAYMENT_CONFIRMED
                ) {
                    $this->createInvoice($order, true);
                } else if ($order->canCreditmemo() &&
                    $payment->getStatus() == Signativa_Braspag_Model_Payment::REFUNDED
                ) {
                    $this->createCreditmemo($order);
                }
                else if (
                        $order->canCancel() &&
                        ($payment->getStatus() == Signativa_Braspag_Model_Payment::DENIED ||
                            $payment->getStatus() == Signativa_Braspag_Model_Payment::NOT_FINISHED)
                ) {
                    $this->cancelOrder($order);
                }
                else {
                    $this->log('No action for order: '.$order->getIncrementId(). ' status: '. $payment->getStatus());
                }
            }
            catch (Exception $e) {
                $this->log('[BRASPAG CRON] ERROR - Processing order: '. $order->getIncrementId());
                $this->log($e->getMessage());
                $this->log($e->getTraceAsString());
            }
        }
        return $this;
    }

    /**
     * @return Mage_Core_Model_Resource_Db_Collection_Abstract|Mage_Sales_Model_Resource_Order_Collection
     */
    protected function getOrderCollection()
    {
        /**
         * @var $orders Mage_Sales_Model_Resource_Order_Collection
         */

        $orders = Mage::getModel('sales/order')->getCollection();

        $orders = $orders->join(
            array('payment' => 'sales/order_payment'),
            'main_table.entity_id=payment.parent_id',
            array('payment_method' => 'payment.method')
        );

        $orders->addFieldToFilter('payment.method', ['like' => 'braspag_%']);
        $orders->addFieldToFilter('payment.method', ['nlike' => 'braspag_recurrence']);
        $orders->addFieldToFilter('state', ['nin' => $this->getIgnorableStates()]);
        return $orders;
    }

    /**
     * @return array
     */
    protected function getIgnorableStates() : array
    {
        return [
            Mage_Sales_Model_Order::STATE_CLOSED,
            Mage_Sales_Model_Order::STATE_CANCELED,
            Mage_Sales_Model_Order::STATE_COMPLETE
        ];
    }
}