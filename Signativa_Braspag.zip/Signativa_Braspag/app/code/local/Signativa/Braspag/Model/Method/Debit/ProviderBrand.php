<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/20/2019
 * Time: 9:37 PM
 */

class Signativa_Braspag_Model_Method_Debit_ProviderBrand
{
    private $relation = [
        'Cielo' => ['Visa', 'Master'],
        'Cielo30' => ['Visa', 'Master'],
        'Getnet' => ['Visa', 'Master'],
        'FirstData' => ['Visa', 'Master'],
        'GlobalPayments' => ['Visa', 'Master'],
    ];

    public function getBrandsByProvider($provider)
    {
        return $this->relation[$provider] ?? null;
    }

    public function getProviders()
    {
        return array_keys($this->relation);
    }
}