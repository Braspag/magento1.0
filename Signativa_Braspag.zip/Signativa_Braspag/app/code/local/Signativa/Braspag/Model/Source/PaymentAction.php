<?php


class Signativa_Braspag_Model_Source_PaymentAction extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        return [
            [
                'label' => $this->getHelper()->__('Only authorize'),
                'value' => Mage_Payment_Model_Method_Abstract::ACTION_AUTHORIZE
            ],
            [
                'label' => $this->getHelper()->__('Authorize and Capture'),
                'value' => Mage_Payment_Model_Method_Abstract::ACTION_AUTHORIZE_CAPTURE
            ]
        ];
    }
}