<?php

use Braspag\API\FraudAnalysis;

class Signativa_Braspag_Model_DataHandler_FraudAnalysis implements Signativa_Braspag_Model_DataHandler_Data
{
    /**
     * @param $paymentData
     * @return object
     * @throws Exception
     */
    public function prepare($paymentData)
    {
        $fraud = new stdClass();
        Mage::dispatchEvent('before_prepare_cybersource_antifraud', ['fraudAnalysis' => $fraud]);
        if ($this->getCybersource()->isBasicMode()) {
            $fraud->Sequence = $this->getCybersource()->getSequence();
            $fraud->SequenceCriteria = $this->getCybersource()->getSequenceCriteria();
            $fraud->FingerPrintId = $this->getCybersource()->getSessionId();
            $fraud->CaptureOnLowRisk = (bool)$this->getCybersource()->getCaptureOnLow();
            $fraud->VoidOnHighRisk = (bool)$this->getCybersource()->getVoidOnHigh();
            $fraud->Cart = [
                "returnsAccepted" => $this->getCybersource()->getReturnsAccepted(),
                'items' => iterator_to_array($this->prepareCart())
            ];
            $fraud->Browser = $this->prepareBrowser();
            $fraud->Shipping = new \stdClass();
            if (!$this->getCybersource()->getQuote()->isVirtual()) {
                $fraud->Shipping->Addressee = $this->getCybersource()->getQuote()->getShippingAddress()->getName();
                $fraud->Shipping->Phone = Mage::helper('braspag')->filterDigits($this->getCybersource()->getQuote()->getBillingAddress()->getTelephone());
                $fraud->Shipping->ShippingMethod = $this->getCybersource()->isCurrentMethodFetch() == Signativa_Braspag_Model_Cybersource::CYBERSOURCE_TRUE ? 'Pickup' : 'Other';
            }
        }
        else {
            $fraud->MerchantOrderId = $this->getCybersource()->getQuote()->getReservedOrderId();
            $fraud->TransactionAmount = str_replace('.', '', (string)$this->getCybersource()->getQuote()->getGrandTotal()) * 100;
            $fraud->CartItems = iterator_to_array($this->prepareCart());
            $fraud->Customer = $this->prepareCustomer($this->getCybersource()->getQuote());
            $fraud->Card = $this->prepareCard($paymentData);
            $fraud->Currency = Mage::app()->getStore()->getCurrentCurrencyCode();
            $fraud = $this->prepareAddresses($this->getCybersource()->getQuote(), $fraud);
        }
        $fraud->TotalOrderAmount = str_replace(',', '', str_replace('.', '', (string)$this->getCybersource()->getQuote()->getGrandTotal())) * 100;
        $fraud->Provider = Signativa_Braspag_Model_Cybersource::CYBERSOURCE_CODE;
        $fraud->MerchantDefinedFields = $this->getCybersource()->prepareMdd($paymentData)->toStdObj();

        Mage::dispatchEvent('after_prepare_cybersource_antifraud', ['fraudAnalysis' => $fraud]);


        return $fraud;

    }

    /**
     * @return \Braspag\API\Analysis|FraudAnalysis
     */
    public function getInstance()
    {
        if ($this->getCybersource()->isBasicMode())
            return new FraudAnalysis();
        else
            return new \Braspag\API\Analysis();
    }

    /**
     * @return Signativa_Braspag_Model_Cybersource
     */
    protected function getCybersource(): Signativa_Braspag_Model_Cybersource
    {
        return Mage::getSingleton('braspag/cybersource');
    }

    /**
     * @return Signativa_Braspag_Helper_Data
     */
    protected function getHelper(): Signativa_Braspag_Helper_Data
    {
        return Mage::helper('braspag');
    }

    /**
     * @return Generator
     */
    public function prepareCart()
    {
        /**
         * @var $item Mage_Sales_Model_Quote_Item
         */
        foreach ($this->getCybersource()->getQuote()->getAllVisibleItems() as $item) {
            yield (object)[
                'sku' => $item->getSku(),
                'unitPrice' => str_replace(',', '', str_replace('.', '', (string)number_format($item->getPrice(), 2))),
                'quantity' => $item->getQty(),
                'name' => $item->getName()
            ];
        }
    }

    /**
     * @return object
     */
    public function prepareBrowser()
    {
        /**
         * @var $http Mage_Core_Helper_Http
         */
        $http = Mage::helper('core/http');
        return (object)[
            'cookieAccepted' => true,
            'type' => $this->extractBrowserName($http->getHttpUserAgent()),
            'ipAddress' => Mage::app()->getRequest()->getClientIp()
        ];
    }

    /**
     * @param $userAgent
     * @return bool|string
     */
    public function extractBrowserName($userAgent)
    {

        if (strpos(strtolower($userAgent), "safari/") and strpos(strtolower($userAgent), "opr/")) {
            // OPERA
            return "Opera";
        } elseIf (strpos(strtolower($userAgent), "safari/") and strpos(strtolower($userAgent), "chrome/")) {
            // CHROME
            return "Chrome";
        } elseIf (strpos(strtolower($userAgent), "msie")) {
            // INTERNET EXPLORER
            return "Internet Explorer";
        } elseIf (strpos(strtolower($userAgent), "firefox/")) {
            // FIREFOX
            return "Mozilla Firefox";
        } elseIf (strpos(strtolower($userAgent), "safari/") and strpos(strtolower($userAgent),
                "opr/") == false and strpos(strtolower($userAgent), "chrome/") == false) {
            // SAFARI
            return "Safari";
        } else {
            // OUT OF DATA
            return false;
        }
    }

    /**
     * @param Mage_Sales_Model_Quote $quote
     * @return stdClass
     */
    public function prepareCustomer(Mage_Sales_Model_Quote $quote) : stdClass
    {
        /**
         * @var $http Mage_Core_Helper_Http
         */
        $http = Mage::helper('core/http');
        $customer = new stdClass();
        $customer->MerchantCustomerId = Mage::helper('braspag')->filterDigits($quote->getCustomerTaxvat());
        $customer->FirstName = $quote->getCustomerFirstname();
        $customer->LastName = $quote->getCustomerLastname();
        $customer->Email = $quote->getCustomerEmail();
        $customer->Ip = Mage::app()->getRequest()->getClientIp();
        $customer->BrowserCookiesAccepted = true;
        $customer->BrowserType = $this->extractBrowserName($http->getHttpUserAgent());
        $customer->BrowserFingerprint =  $this->getCybersource()->getSessionId();
        $customer->Phone = Mage::helper('braspag')->filterDigits($quote->getBillingAddress()->getTelephone());
        return $customer;
    }

    /**
     * @param Mage_Sales_Model_Quote $quote
     * @param stdClass $data
     * @return stdClass
     * @throws Varien_Exception
     */
    public function prepareAddresses(Mage_Sales_Model_Quote $quote, stdClass $data)
    {
        $data->Billing = $this->prepareBilling($quote);
        if (!$quote->isVirtual()) {
            $data->Shipping = $this->prepareShipping($quote);
        }
        return $data;
    }

    /**
     * @param Mage_Sales_Model_Quote $quote
     * @return stdClass
     * @throws Varien_Exception
     */
    public function prepareBilling(Mage_Sales_Model_Quote $quote) : stdClass
    {
        /**
         * @var $customerParser Signativa_Braspag_Model_DataHandler_Customer
         */
        $customerParser = Mage::getSingleton('braspag/dataHandler_customer');

        return $customerParser->prepareAddress($quote->getBillingAddress(), false);

    }

    /**
     * @param Mage_Sales_Model_Quote $quote
     * @return stdClass
     * @throws Varien_Exception
     */
    public function prepareShipping(Mage_Sales_Model_Quote $quote) : stdClass
    {
        /**
         * @var $customerParser Signativa_Braspag_Model_DataHandler_Customer
         */
        $customerParser = Mage::getSingleton('braspag/dataHandler_customer');
        $shippingAddress = $customerParser->prepareAddress($quote->getShippingAddress(), false);
        $shippingAddress->FirstName = $quote->getShippingAddress()->getFirstname();
        $shippingAddress->LastName = $quote->getShippingAddress()->getLastname();
        return $shippingAddress;
    }

    public function prepareCard($payment)
    {
        $card = new stdClass();

        $card->Cvv = $payment->getCcCid();
        $card->Brand = ucfirst($payment->getCcType());
        $card->ExpirationDate = $payment->getCcExpMonth() . '/' . $payment->getCcExpYear();
        $card->Number = Mage::helper('braspag')->filterDigits($payment->getCcNumber());
        $card->Holder = $payment->getCcOwner();

        return $card;
    }

}