<?php


interface Signativa_Braspag_Model_Validation_Card
{
    public function getCardRegex($brand);

    public function getCvvLengthByBrand($brand);
}