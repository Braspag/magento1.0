<?php


class Signativa_Braspag_Model_Source_Provider_Voucher extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        $result =[];
        foreach ($this->getProviders() as $provider) {
            $result[] =  [
                'label' => $provider,
                'value' => $provider
            ];
        }
        return $result;
    }

    private function getProviders()
    {
        /**
         * @var $relator Signativa_Braspag_Model_Method_Voucher_ProviderBrand
         */
        $relator = Mage::getModel('braspag/method_voucher_providerBrand');

        return $relator->getProviders();
    }
}