<?php


class Signativa_Braspag_Model_Split_Merchant extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('braspag/split_merchant');
    }

    /**
     * Returns prepared MDR if you want it raw use getData('mdr')
     * @param null $installment
     * @param null $brand
     * @return string
     */
    public function getMdr($installment = null, $brand = null, $debit = false)
    {
        if ($installment && $brand) {
            if ($rate = $this->getMdrRate($installment, $brand, $debit)) {
                return number_format($rate->getMdr(), 2);
            }
        }
        if ($this->getData('mdr') === false || $this->getData('mdr') === null) {
            return number_format($this->getSplit()->getDefaultMdr(), 2);
        }

        return number_format($this->getData('mdr'), 2);
    }

    /**
     * Returns prepared FEE if you want it raw use getData('fee')
     * @return mixed
     */
    public function getFee()
    {
        if ($this->getData('fee') === false || $this->getData('fee') === null) {
            return $this->getSplit()->getDefaultFee();
        }
        return str_replace(',', '', str_replace('.', '', number_format($this->getData('fee'), 2)));
    }

    /**
     * @return Signativa_Braspag_Model_Split
     */
    protected function getSplit(): Signativa_Braspag_Model_Split
    {
        return Mage::getSingleton('braspag/split');
    }

    public function getMdrRates(): Signativa_Braspag_Model_Resource_Split_Merchant_Mdr_Rate_Collection
    {
        /**
         * @var $collection Signativa_Braspag_Model_Resource_Split_Merchant_Mdr_Rate_Collection
         */
        $collection = Mage::getModel('braspag/split_merchant_mdr_rate')->getCollection();

        return $collection->filterByMerchant($this);
    }

    public function addMdrRate($brand, $installment, $rate, $debit): Signativa_Braspag_Model_Split_Merchant_Mdr_Rate
    {
        $mdrRate = Mage::getModel('braspag/split_merchant_mdr_rate');
        $mdrRate->setBrand($brand)->setInstallment($installment)->setMdr($rate)->setMerchantId($this->getId())->setDebit((int)$debit);
        return $mdrRate->save();
    }

    /**
     * @param $installment
     * @param $brand
     * @param bool $isDebit
     * @return Signativa_Braspag_Model_Split_Merchant_Mdr_Rate|null
     */
    public function getMdrRate($installment, $brand, $isDebit = false)
    {
        $rates = $this->getMdrRates()->addFieldToFilter('installment', $installment)->addFieldToFilter('brand',
            $brand)->addFieldToFilter('debit', (int)$isDebit);
        if ($rates->count() > 0) {
            return $rates->getFirstItem();
        }
        return null;
    }
}