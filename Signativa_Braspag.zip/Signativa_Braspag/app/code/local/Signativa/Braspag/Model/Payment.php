<?php


class Signativa_Braspag_Model_Payment
{
    const NOT_FINISHED = 0;

    const AUTHORIZED = 1;

    const PAYMENT_CONFIRMED = 2;

    const DENIED = 3;

    const VOIDED = 10;

    const REFUNDED = 11;

    const PENDING = 12;

    const ABORTED = 13;

    const SCHEDULED = 20;

    public static $canceledStatuses = [
        self::ABORTED,
        self::VOIDED,
        self::DENIED,
        self::REFUNDED,
        self::NOT_FINISHED
    ];
}