<?php

class Signativa_Braspag_Model_CallbackHandler extends Varien_Object
{
    use Signativa_Braspag_Trait_Log;
    /**
     *    Mudança de status do pagamento
     */
    const STATUS_CHANGE = 1;

    /**
     *  Recorrência criada
     */
    const ACTIVATED_RECURRENCE = 2;

    /**
     * Mudança de status do Antifraude
     */
    const ANTIFRAUD_STATUS_CHANGE = 3;

    /**
     * Mudança de status do pagamento recorrente (Ex. desativação automática)
     */
    const RECURRENCE_STATUS_CHANGE = 4;

    /**
     * Estorno negado (aplicável para Rede)
     */
    const REFUND_DENIED = 5;
    /**
     * Boleto registrado pago a menor
     */
    const UNDERPAID_BANKSLIP = 6;
    /**
     * Notificação de chargeback
     */
    const CHARGEBACK = 7;

    /**
     * @param Mage_Core_Controller_Request_Http $request
     * @throws Signativa_Braspag_CallbackException
     * @throws Zend_Json_Exception
     */
    public function handle(Mage_Core_Controller_Request_Http $request)
    {
        $data = $this->parseCallback($request->getRawBody());
        $this->log('[Braspag Callback] ' . print_r($data, true));
        /**
         *  Handle each type of possible callback from braspag
         */
        $handler = null;
        switch ($data['ChangeType']) {
            case self::STATUS_CHANGE:
                $handler = $this->getHandlerInstance('status', $data);
                break;
            case self::ACTIVATED_RECURRENCE:
                $handler = $this->getHandlerInstance('recurrenceActive', $data);
                break;
            case self::ANTIFRAUD_STATUS_CHANGE:
                $handler = $this->getHandlerInstance('antifraudStatus', $data);
                break;
            case self::RECURRENCE_STATUS_CHANGE:
                $handler = $this->getHandlerInstance('recurrenceStatus', $data);
                break;
            case self::REFUND_DENIED:
                $handler = $this->getHandlerInstance('refundDenied', $data);
                break;
            case self::UNDERPAID_BANKSLIP:
                $handler = $this->getHandlerInstance('underpaid', $data);
                break;
            case self::CHARGEBACK:
                $handler = $this->getHandlerInstance('chargeback', $data);
                break;
            default:
                throw new Signativa_Braspag_CallbackException("Could not process callback, reason: Invalid callback type");
        }

        $handler->execute();

    }

    /**
     * @param $postData
     * @return mixed
     * @throws Zend_Json_Exception
     */
    private function parseCallback($postData)
    {
        if (!$postData) {
            throw new Exception('No post data received from callback');
        }

        return Zend_Json::decode($postData);
    }

    /**
     * @param $handlerName
     * @param $callbackInfo
     * @return Signativa_Braspag_Model_CallbackHandler_Abstract|Varien_Object
     */
    private function getHandlerInstance($handlerName, $callbackInfo): Signativa_Braspag_Model_CallbackHandler_Abstract
    {
        return Mage::getSingleton('braspag/callbackHandler_' . $handlerName)->setData('callback_info', $callbackInfo);
    }
}