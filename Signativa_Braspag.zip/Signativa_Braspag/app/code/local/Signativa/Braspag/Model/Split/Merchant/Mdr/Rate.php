<?php


class Signativa_Braspag_Model_Split_Merchant_Mdr_Rate extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('braspag/split_merchant_mdr_rate');
    }
}