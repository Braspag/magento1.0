<?php


class Signativa_Braspag_Model_Resource_Recurrence_Transaction_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{

    protected function _construct()
    {
        $this->_init('braspag/recurrence_transaction');
    }

    /**
     * @param Signativa_Braspag_Model_Recurrence $recurrence
     * @return Mage_Eav_Model_Entity_Collection_Abstract
     */
    public function filterByRecurrence(Signativa_Braspag_Model_Recurrence $recurrence)
    {
        return $this->addFieldToFilter('recurrence_id', $recurrence->getId());
    }
}