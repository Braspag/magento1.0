<?php
/**
 * Created by PhpStorm.
 * User: matheus
 * Date: 18/05/19
 * Time: 18:49
 */

class Signativa_Braspag_Model_Source_StreetLines extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        $result = [];
        for ($i = 1; $i <= 4; $i++) {
            $result[] = [
                'label' => $this->getHelper()->__("Street [%s]", $i),
                'value' => $i
            ];
        }

        return $result;
    }
}