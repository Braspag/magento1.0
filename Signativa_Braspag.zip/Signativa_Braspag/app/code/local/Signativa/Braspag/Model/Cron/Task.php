<?php


interface Signativa_Braspag_Model_Cron_Task
{
    public function execute();
}