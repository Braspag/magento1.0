<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/20/2019
 * Time: 9:50 PM
 */

class Signativa_Braspag_Model_Source_Brand_Debit extends Signativa_Braspag_Model_Source_Brand_Abstract
{
    protected  $method = 'debit';
}