<?php


class Signativa_Braspag_Model_Cybersource_Mdd extends Varien_Object implements JsonSerializable
{
    const IS_LOGGED_IN = 1;

    const AMOUNT_DAYS_IS_CUSTOMER = 2;

    const INSTALLMENT_AMOUNT = 3;

    const SALE_CHANNEL = 4;

    const DAYS_SINCE_LAST_ORDER = 6;

    const CUSTOMER_WILL_FETCH = 9;

    const SHIPPING_METHOD = 37;

    const  ORDER_QTY = 44;

    const CARD_NAME = 46;

    const AVERAGE_ORDER_AMOUNT = 49;

    const IS_VIP_CUSTOMER = 51;

    const BUSINESS_SEGMENT = 94;

    const PLATFORM_NAME = 95;

    const SUFFIX_CC_NUMBER = 23;

    const CUSTOMER_SEX = 25;

    const BIN_CC_NUMBER = 26;

    const CONTAINER = 'mdd_data';

    /**
     * Specify data which should be serialized to JSON
     * @link https://php.net/manual/en/jsonserializable.jsonserialize.php
     * @return mixed data which can be serialized by <b>json_encode</b>,
     * which is a value of any type other than a resource.
     * @since 5.4.0
     */
    public function jsonSerialize()
    {
        return $this->getData(self::CONTAINER);
    }

    /**
     * @param $id
     * @param $value
     * @return Varien_Object
     */
    public function addValue($id, $value) {
        if (!$this->hasData(self::CONTAINER)) {
            $this->setData(self::CONTAINER, []);
        }
        $currData = $this->getData(self::CONTAINER);
        $currData[] = [
            'Id' => $id,
            'Value' => $value
        ];

        return $this->setData(self::CONTAINER, $currData);
    }

    public function toStdObj()
    {
        return $this->getData(self::CONTAINER);
    }
}