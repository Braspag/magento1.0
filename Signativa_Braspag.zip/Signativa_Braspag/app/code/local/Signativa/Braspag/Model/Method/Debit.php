<?php

use Braspag\API\Payment;
use Braspag\API\Sale;

class Signativa_Braspag_Model_Method_Debit extends Signativa_Braspag_Model_Method_Abstract
{
    protected $method = 'debit';
    protected $_formBlockType = 'braspag/method_debit_form';
    protected $_infoBlockType = 'braspag/method_debit_info';
    protected $_canOrder = true;
    protected $canSplit  = true;

    /**
     * @param mixed $data
     * @return $this|Mage_Payment_Model_Info
     */
    public function assignData($data)
    {
        if (!($data instanceof Varien_Object)) {
            $data = new Varien_Object($data);
        }
        $info = $this->getInfoInstance();
        $date = $this->prepareExpireDate($data->getData('braspag_debit_expiration'));
        $info->setCcType($data->getData('braspag_debit_flag'))
            ->setCcNumber($data->getData('braspag_debit_number'))
            ->setCcCid($data->getData('braspag_debit_cvv'))
            ->setCcExpMonth($date[0])
            ->setCcExpYear($date[1])
            ->setCcLast4(substr($data->getData('braspag_debit_number'), -4))
            ->setCcOwner($data->getData('braspag_debit_name'));

        return $this;
    }

    /**
     * @param $payment
     * @param $information Braspag\API\Sale
     * @return mixed|void
     * @throws Zend_Json_Exception
     */
    public function setAdditionalInformation($payment, $information)
    {
        $payment->setAdditionalInformation('payment_id', $information->getPayment()->getPaymentId());
        $payment->setAdditionalInformation('status', $information->getPayment()->getStatus());
        if ($information->getPayment()->getDoSplit()) {
            $payment->setAdditionalInformation('split_merchant', Zend_Json::decode(Zend_Json::encode($information->getPayment()->getSplitPayments())));
        }
        /**
         * @var Mage_Checkout_Model_Session $session
         */
        $session = Mage::getSingleton('checkout/session');
        $session->setData(self::REDIRECT_CONTAINER, $information->getPayment()->getAuthenticationUrl());
    }

    /**
     * @return string
     */
    public function getOrderPlaceRedirectUrl()
    {
        return Mage::getUrl('braspag/redirect');
    }

    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param $amount
     * @return Sale
     * @throws Exception
     */
    protected function readyOrder($payment, $amount)
    {
        /**
         * @var $quote Mage_Sales_Model_Quote
         */

        $amount = $this->prepareAmount($amount);
        $quote = Mage::getSingleton('checkout/session')->getQuote();

        $sale = $this->initSale($quote->getReservedOrderId());

        $sale->setCustomer(
            $this->prepareCustomer($quote)
        );
        $pay = $sale->payment($amount);

        $pay->setType(Payment::PAYMENTTYPE_DEBITCARD)
            ->debitCard($payment->getCcCid(), ucfirst($payment->getCcType()))
            ->setExpirationDate($payment->getCcExpMonth() . '/' . $payment->getCcExpYear())
            ->setCardNumber($payment->getCcNumber())
            ->setHolder($payment->getCcOwner());
        //applies split
        $this->applySplit($pay, $quote);

        $pay->setProvider($this->getProvider());
        $pay->setReturnUrl($this->getReturnUrl());

        return $sale;
    }

    /**
     * @param Varien_Object $payment
     * @param float $amount
     * @return $this|Signativa_Braspag_Model_Method_Debit
     * @throws Mage_Core_Exception
     * @throws Zend_Json_Exception
     */
    public function order(Varien_Object $payment, $amount)
    {
        $sale = $this->readyOrder($payment, $amount);

        $result = $this->placeOrder($sale);

        $payment->setIsTransactionClosed(false);

        $payment->setTransactionId($result->getPayment()->getPaymentId());

        $this->setAdditionalInformation($payment, $result);

        return $this;
    }
}