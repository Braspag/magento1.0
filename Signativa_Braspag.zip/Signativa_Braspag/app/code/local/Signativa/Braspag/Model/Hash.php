<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/23/2019
 * Time: 8:46 PM
 */

class Signativa_Braspag_Model_Hash extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('braspag/hash');
    }
}