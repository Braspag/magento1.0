<?php


class Signativa_Braspag_Model_Ewallet extends Varien_Object
{
    use Signativa_Braspag_Trait_Api;

    const XML_EWALLET_TYPE_PATH = 'payment/braspag_ewallet/type';

    const XML_EWALLET_ACTIVE_PATH = 'payment/braspag_ewallet/active';

    const XML_EWALLET_ENVIRONMENT_PATH = 'payment/braspag_ewallet/environment';


    const AVAILABLE_PROVIDERS = [
        'ApplePay' => 'braspag/method_ewallet_applePay',
        'GooglePay'=> 'braspag/method_ewallet_googlePay',
        'MasterPass'=> 'braspag/method_ewallet_masterPass',
        'SamsungPay'=> 'braspag/method_ewallet_samsungPay',
        'VisaCheckout'=> 'braspag/method_ewallet_visaCheckout'
    ];

    /**
     * @param $ewallet string
     * @return Signativa_Braspag_Model_Method_Ewallet_Abstract
     */
    protected function getInstance($ewallet)
    {
        /**
         * @var $instance Signativa_Braspag_Model_Method_Ewallet_Abstract
         */
        $instance = Mage::getSingleton($ewallet);
        $instance->setEwallet($this);
        return $instance;
    }

    /**
     * @return false|Mage_Core_Model_Abstract|Signativa_Braspag_Model_Method_Ewallet_Abstract
     */
    public function getEwalletInstance()
    {
        return $this->getInstance($this->getEwalletId());
    }

    /**
     * @return mixed
     */
    public function getEwalletId()
    {
        return Mage::getStoreConfig(self::XML_EWALLET_TYPE_PATH);
    }

    public function getEwalletName()
    {
        foreach (self::AVAILABLE_PROVIDERS as $name => $id) {
            if ($this->getEwalletId() == $id)
                return $name;
        }
    }

    /**
     * @return array
     */
    public static function getAvailableProviders()
    {
        $result = self::AVAILABLE_PROVIDERS;
        Mage::dispatchEvent('braspag_ewallet_providers', $result);
        return $result;
    }

    /**
     * @return bool
     */
    public function isActive()
    {
        return (bool) Mage::getStoreConfig(self::XML_EWALLET_ACTIVE_PATH);
    }

    /**
     * @return bool
     */
    public function isSandbox() : bool
    {
        return Mage::getStoreConfig(self::XML_EWALLET_ENVIRONMENT_PATH) == 'sandbox';
    }

    /**
     * @return bool
     */
    public function isProduction() : bool
    {
        return Mage::getStoreConfig(self::XML_EWALLET_ENVIRONMENT_PATH) == 'production';
    }

    /**
     * @return Mage_Core_Helper_Abstract|Signativa_Braspag_Helper_Ewallet
     */
    public function getHelper()
    {
        return Mage::helper('braspag/ewallet');
    }

    /**
     * @return Mage_Sales_Model_Quote
     */
    public function getQuote() : Mage_Sales_Model_Quote
    {
        return Mage::getSingleton("checkout/cart")->getQuote();
    }


}