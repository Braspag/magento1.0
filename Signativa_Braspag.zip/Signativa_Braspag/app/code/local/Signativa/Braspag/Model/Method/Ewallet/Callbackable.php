<?php


interface Signativa_Braspag_Model_Method_Ewallet_Callbackable
{
    public function handleCallback(Signativa_Braspag_Model_Ewallet_Callback $callback);

    public function fetchQuoteId(Signativa_Braspag_Model_Ewallet_Callback $callback);
}