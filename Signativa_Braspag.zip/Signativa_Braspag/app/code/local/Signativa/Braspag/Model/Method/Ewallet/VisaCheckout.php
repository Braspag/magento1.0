<?php


class Signativa_Braspag_Model_Method_Ewallet_VisaCheckout extends Signativa_Braspag_Model_Method_Ewallet_Abstract
{
    const XML_PATH_API_KEY = 'payment/braspag_ewallet/visa_api_key';

    const XML_PATH_ENCRYPTION_KEY = 'payment/braspag_ewallet/visa_encryption_key';

    public function getSpecialTemplate()
    {
        return '/braspag/method/ewallet/special/visacheckout.phtml';
    }

    /**
     * @return stdClass
     */
    public function getAdditionalData()
    {
        // TODO: Implement getAdditionalData() method.
    }

    /**
     * @return string
     */
    public function getWalletKey()
    {
        // TODO: Implement getWalletKey() method.
    }

    /**
     * @return mixed
     */
    public function getApiKey()
    {
        return Mage::getStoreConfig(self::XML_PATH_API_KEY);
    }

    /**
     * @return mixed
     */
    public function getEncryptionKey()
    {
        return Mage::getStoreConfig(self::XML_PATH_ENCRYPTION_KEY);
    }

}