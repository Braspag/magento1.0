<?php


class Signativa_Braspag_Model_Method_Ewallet_ApplePay extends Signativa_Braspag_Model_Method_Ewallet_Abstract
{

    public function getSpecialTemplate()
    {
        return '/braspag/ewallet/special/applepay.phtml';
    }

    /**
     * @return stdClass
     */
    public function getAdditionalData()
    {
        // TODO: Implement getAdditionalData() method.
    }

    public function getWalletKey()
    {
        // TODO: Implement getWalletKey() method.
    }
}