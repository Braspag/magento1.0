<?php


class Signativa_Braspag_Model_CallbackHandler_RecurrenceStatus extends Signativa_Braspag_Model_CallbackHandler_Abstract
{
    /**
     * Handles recurrence status change callback
     * @return $this
     * @throws \Braspag\API\Request\BraspagRequestException
     */
    public function execute()
    {
        /**
         * @var $sale \Braspag\API\RecurrentPayment
         */
        $sale = $this->readySale();
        $status = $sale->getStatus();

        $order = $this->getOrder($sale->getMerchantOrderId());

        $recurrenceInstance = $this->getRecurrenceInstance($order->getId());
        if ($recurrenceInstance->getStatus() == $status) {
            $this->log('[Braspag Callback] received for recurrence of order: '.$order->getIncrementId(). ' but the status is the same');
            return $this;
        }

        $recurrenceInstance->setStatus($status)
                            ->save();

        return $this;
    }
}