<?php


class Signativa_Braspag_Model_ThreeDS_Api extends Varien_Object
{
    use Signativa_Braspag_Trait_Log;
    /**
     * @var Zend_Http_Client
     */
    protected $httpClient;

    public function __construct($args)
    {
        parent::__construct();
        $this->httpClient = new Zend_Http_Client($args['url']);

        if  (count($args['credential'] > 1)) {
            $this->httpClient->setAuth($args['credential']['client_id'], $args['credential']['client_secret']);
        }
    }

    public function executeAction(Signativa_Braspag_Model_ThreeDS_Api_Abstract $action)
    {
        $this->httpClient->setUri($this->httpClient->getUri().$action->getRoute());
        $this->httpClient->setMethod($action->getMethod());
        $this->httpClient->setParameterGet($action->getGetParams());
        $this->httpClient->setHeaders('Content-Type', 'application/json');
        $this->httpClient->setRawData(Zend_Json::encode($action->getPostParameters()));
        try {
            $response = $this->httpClient->request();
            return $action->handleResponse($response->getBody());
        }
        catch (Zend_Http_Client_Exception $exception) {
            $this->log('HTTP EXCEPTION: '. $exception->getMessage()."\n".$exception->getTraceAsString());
            return false;
        }
    }
}