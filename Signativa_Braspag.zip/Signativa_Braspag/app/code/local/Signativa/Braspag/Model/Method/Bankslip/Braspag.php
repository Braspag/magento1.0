<?php
use Braspag\API\Payment;
use Braspag\API\Sale;

class Signativa_Braspag_Model_Method_Bankslip_Braspag  extends Signativa_Braspag_Model_Method_Bankslip
{
    const BRASPAG_PROVIDER = 'braspag';
    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param $amount
     * @return Sale
     * @throws Exception
     */
    protected function readyOrder($payment, $amount)
    {
        /**
         * @var $quote Mage_Sales_Model_Quote
         */
        $amount = $this->prepareAmount($amount);

        $quote = Mage::getSingleton('checkout/session')->getQuote();

        $sale = $this->initSale($quote->getReservedOrderId());

        $sale->setCustomer(
            $this->prepareCustomer($quote)
        );
        $pay = $sale->payment($amount);

        $pay->setType(Payment::PAYMENTTYPE_BOLETO);

        $pay->setProvider(self::BRASPAG_PROVIDER);

        $pay->setDemonstrative($this->getData('demonstrative') ?? null);

        $pay->setBoletoNumber($this->getConfigData('boleto_number') ?? null);

        $pay->setBank($this->getConfigData('bank'));

        return $sale;
    }
}