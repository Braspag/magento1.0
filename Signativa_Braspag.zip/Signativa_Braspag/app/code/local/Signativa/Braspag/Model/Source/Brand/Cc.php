<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/16/2019
 * Time: 9:02 PM
 */

class Signativa_Braspag_Model_Source_Brand_Cc extends Signativa_Braspag_Model_Source_Brand_Abstract
{
    protected $method = 'cc';
}