<?php


class Signativa_Braspag_Model_ThreeDs_BlockLoader extends Varien_Object
{
    const TARGET_LAYOUT_FULL_ACTION_NAME = 'checkout_onepage_index';

    public $blockContainerRelation = [
        'threeds-payment' => 'braspag.threeds.payment',
        'threeds-cart' => 'braspag.threeds.cart',
        'threeds-order' => 'braspag.threeds.order',
        'threeds-userAccount' => 'braspag.threeds.userAccount',
        'threeds-device' => 'braspag.threeds.device',
        'threeds-address-billing' => 'braspag.threeds.address.billing',
        'threeds-address-shipping' => 'braspag.threeds.address.shipping',
    ];

    public function getBlock($name)
    {
        $this->_initLayout();
        $block = $this->getLayout()->getBlock($name);
        if (strpos($name, 'shipping') !== false ) {
            $block->setAddressType('shipping');
        }
        return $block->toHtml();
    }

    /**
     * @param $container
     * @return mixed|null
     */
    public function getBlockNameByContainer($container)
    {
        return $this->blockContainerRelation[$container] ?? null;
    }

    /**
     * @return $this
     * @throws Mage_Core_Model_Store_Exception
     */
    protected function _initLayout() {
        if ($this->getLoaded()) {
            return $this;
        }
        $update = $this->getLayout()->getUpdate();
//        $update->addHandle('default'); //load default handle
//        $update->addHandle('STORE_' . Mage::app()->getStore()->getCode()); // load store handle
//        $package = Mage::getSingleton('core/design_package');
//        $update->addHandle(
//            'THEME_' . $package->getArea() . '_' . $package->getPackageName() . '_' . $package->getTheme('layout')
//        ); // load theme handle
        $update->addHandle(strtolower(self::TARGET_LAYOUT_FULL_ACTION_NAME)); // load action handle
        $update->load();
        $this->getLayout()->generateXml();
        $this->getLayout()->generateBlocks();
        return $this->setLoaded(true);
    }
}