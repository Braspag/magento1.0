<?php


class Signativa_Braspag_Model_Source_ProductCode extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        return [
            [
                'label' => $this->getHelper()->__('Hotelaria'),
                'value' => 'ACC'
            ],
            [
                'label' => $this->getHelper()->__('Financiamento de conta'),
                'value' => 'ACF'
            ],
            [
                'label' => $this->getHelper()->__('Check acceptance'),
                'value' => 'CHA'
            ],
            [
                'label' => $this->getHelper()->__('Digital Goods'),
                'value' => 'DIG'
            ],
            [
                'label' => $this->getHelper()->__('Dispensação de dinheiro'),
                'value' => 'DSP'
            ],
            [
                'label' => $this->getHelper()->__('Combustível'),
                'value' => 'GAS'
            ],
            [
                'label' => $this->getHelper()->__('Varejo geral'),
                'value' => 'GEN'
            ],
            [
                'label' => $this->getHelper()->__('Artigos de luxo'),
                'value' => 'LUX'
            ],
            [
                'label' => $this->getHelper()->__('Recarga'),
                'value' => 'PAL'
            ],
            [
                'label' => $this->getHelper()->__('Compra de mercadorias'),
                'value' => 'PHY'
            ],
            [
                'label' => $this->getHelper()->__('Transação quase-dinheiro'),
                'value' => 'QCT'
            ],
            [
                'label' => $this->getHelper()->__('Aluguel de Carros'),
                'value' => 'REN'
            ],
            [
                'label' => $this->getHelper()->__('Restaurante'),
                'value' => 'RES'
            ],
            [
                'label' => $this->getHelper()->__('Serviços'),
                'value' => 'SVC'
            ],
            [
                'label' => $this->getHelper()->__('Outros'),
                'value' => 'TBD'
            ],
            [
                'label' => $this->getHelper()->__('Turismo'),
                'value' => 'TRA'
            ]
        ];
    }
}