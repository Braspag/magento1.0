<?php


class Signativa_Braspag_Model_Recurrence extends Mage_Core_Model_Abstract
{
    use Signativa_Braspag_Trait_Recurrence;

    const STATUS_ACTIVE = 1;

    const STATUS_FINALIZED = 2;

    const STATUS_HOLD = [3, 4, 5];

    const XML_PATH_NEW_RECURRENCE_EMAIL = 'sales_email/recurrence/template';
    const XML_PATH_EMAIL_IDENTITY               = 'sales_email/recurrence/identity';
    const XML_PATH_EMAIL_COPY_TO                = 'sales_email/recurrence/copy_to';
    const XML_PATH_EMAIL_COPY_METHOD            = 'sales_email/recurrence/copy_method';
    const XML_PATH_EMAIL_ENABLED                = 'sales_email/recurrence/enabled';
    /**
     * @var Signativa_Braspag_Model_Recurrence_Item[]|Signativa_Braspag_Model_Resource_Recurrence_Item_Collection
     */
    protected $items;

    /**
     * Prepares self based on an order
     * @param Mage_Sales_Model_Order $order
     * @return $this
     */
    public function createFromOrder(Mage_Sales_Model_Order $order)
    {
        $payment = $order->getPayment();
        $this->setParentId($order->getId())
            ->setState(self::STATUS_ACTIVE)
            ->setRecurrentTransactionId($payment->getAdditionalInformation('recurrence_payment_id'))
            ->setNextRecurrence($payment->getAdditionalInformation('recurrence_next'))
            ->setLastOrderCreated($order->getIncrementId())
            ->setDiscountAmount($order->getDiscountAmount())
            ->setShippingAmount($order->getShippingAmount())
            ->setShippingMethod($order->getShippingMethod())
            ->setStoreId($order->getStoreId())
            ->setCustomerId($order->getCustomerId())
            ->setGrandTotal($order->getGrandTotal());
        return $this;
    }

    /**
     * @param Mage_Sales_Model_Order_Item|Signativa_Braspag_Model_Recurrence_Item $item
     */
    public function addItem($item)
    {
        if (!is_array($this->items)) {
            $this->items = [];
        }
        /**
         * @var $recurrenceItem Signativa_Braspag_Model_Recurrence_Item
         */
        if ($item instanceof  Signativa_Braspag_Model_Recurrence_Item) {
            $this->items[] = $item;
        }
        else {
            $recurrenceItem = Mage::getModel('braspag/recurrence_item');
            $this->items[] = $recurrenceItem->prepareFromOrderItem($item);
        }
    }

    /**
     * @return $this|Mage_Core_Model_Abstract
     * @throws Exception
     */
    public function _afterSave()
    {
        parent::_afterSave();
        foreach ($this->getItems() as $item) {
            $item->setRecurrence($this)->save();
        }
        return $this;
    }

    /**
     * @return Signativa_Braspag_Model_Recurrence_Item[]|Signativa_Braspag_Model_Resource_Recurrence_Item_Collection
     */
    public function getItems()
    {
        if (!$this->items && $this->getId()) {
            $this->items = Mage::getModel('braspag/recurrence_item')->getCollection()->addFieldToFilter('recurrence_id', $this->getId());
        }
        return $this->items;
    }

    /**
     * @param Signativa_Braspag_Model_Recurrence_Item[]|Signativa_Braspag_Model_Resource_Recurrence_Item_Collection $items
     */
    public function setItems($items)
    {
        $this->items = $items;
    }

    /**
     * @param Mage_Sales_Model_Order $order
     * @return $this
     */
    public function addTransaction(Mage_Sales_Model_Order $order)
    {
        /**
         * @var $transaction Signativa_Braspag_Model_Recurrence_Transaction
         */
        $transaction = Mage::getModel('braspag/recurrence_transaction')->setRecurrenceId($this->getId())->setOrderId($order->getId())->save();
        return $this;
    }

    /**
     * @return Signativa_Braspag_Model_Resource_Recurrence_Transaction_Collection
     */
    public function getTransactions()
    {
        if (!$this->getData('transactions') && $this->getId()) {
            $this->setTransactions(Mage::getModel('braspag/recurrence_transaction')->getCollection()->addFieldToFilter('recurrence_id', $this->getId()));
        }

        return $this->getData('transactions');
    }
    protected function _construct()
    {
        $this->_init('braspag/recurrence');
    }

    /**
     * @return Mage_Sales_Model_Order
     */
    public function getParentOrder() : Mage_Sales_Model_Order
    {
        return Mage::getSingleton('sales/order')->load($this->getParentId());
    }

    /**
     * @return string
     */
    public function getStateLabel()
    {
        if ($this->getState() == self::STATUS_ACTIVE) {
            return 'Active';
        }
        else if ($this->getState() == self::STATUS_FINALIZED) {
            return 'Finalized';
        }
        else {
            return 'On hold';
        }
    }

    /**
     * @return string
     */
    public function getShippingMethodLabel()
    {
        return $this->getLastOrder()->getShippingDescription();
    }

    /**
     * @return Mage_Sales_Model_Order
     */
    public function getLastOrder() : Mage_Sales_Model_Order
    {
        return Mage::getSingleton('sales/order')->load($this->getLastTransaction()->getOrderId());
    }

    /**
     * @return Signativa_Braspag_Model_Recurrence_Transaction
     */
    public function getLastTransaction() : Signativa_Braspag_Model_Recurrence_Transaction
    {
        return $this->getTransactions()->addOrder('created_at', Varien_Data_Collection_Db::SORT_ORDER_DESC)->getFirstItem();
    }

    /**
     * @return string|null
     */
    public function getShippingAddressFormatted()
    {
        return $this->getLastOrder()->getShippingAddress()->format('html');
    }

    /**
     * @return string|null
     */
    public function getBillingAddressFormatted()
    {
        return $this->getLastOrder()->getBillingAddress()->format('html');
    }

    /**
     * @return int
     */
    public function isVirtual()
    {
        return $this->getParentOrder()->getIsVirtual();
    }

    /**
     * @return \Braspag\API\RecurrentPayment
     * @throws \Braspag\API\Request\BraspagRequestException
     */
    public function getRecurrenceInfo () : \Braspag\API\RecurrentPayment
    {   if (!$this->getData('recurrence_info')) {
            $this->setData('recurrence_info', $this->getRecurrentSaleInfo($this->getRecurrentTransactionId()));
        }
        return $this->getData('recurrence_info');
    }

    /**
     * @return float
     */
    public function getSubtotal()
    {
        $subtotal = 0;
        foreach ($this->getItems() as $item){
            if ($item->getState() == Signativa_Braspag_Model_Recurrence_Item::DISABLE) {
                continue;
            }
            $subtotal = $subtotal + ($item->getPrice() * $item->getQty());
        }
        return $subtotal;
    }

    public function deactivate($online=true)
    {
        $this->setData('state', self::STATUS_HOLD[0]);
        if ($online) {
            $recurrence = $this->getRecurrenceInfo();
            if (!in_array($recurrence->getStatus(), self::STATUS_HOLD) && $recurrence->getStatus() != self::STATUS_FINALIZED) {
                $this->deactivateOnline($this->getRecurrentTransactionId());
            }
            else {
                $this->setState($recurrence->getStatus())->save();
                throw new Exception('Could not deactivate recurrence');
            }
        }

        return $this->save();
    }

    public function activate($online=true)
    {
        $this->setData('state', self::STATUS_ACTIVE);
        if ($online) {
            $recurrence = $this->getRecurrenceInfo();
            if ($recurrence->getStatus() != self::STATUS_ACTIVE && $recurrence->getStatus() != self::STATUS_FINALIZED) {
                $this->activateOnline($this->getRecurrentTransactionId());
            }
            else {
                $this->setState($recurrence->getStatus())->save();
                throw new Exception('Could not activate recurrence');
            }
        }

        return $this->save();
    }

    public function updateTotal()
    {
        $subTotal = $this->getSubtotal();
        $this->setGrandTotal(( $subTotal + $this->getShippingAmount()) - $this->getDiscountAmount());
        $this->save();
    }
}