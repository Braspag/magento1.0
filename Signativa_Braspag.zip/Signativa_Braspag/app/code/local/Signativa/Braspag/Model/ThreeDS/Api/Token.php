<?php

/**
 * {
    "EstablishmentCode":"1006993069",
    "MerchantName": "Loja Exemplo Ltda",
    "MCC": "5912"
    }
 */
class Signativa_Braspag_Model_ThreeDS_Api_Token extends Signativa_Braspag_Model_ThreeDS_Api_Abstract
{
    protected $route = '/v2/auth/token';
}