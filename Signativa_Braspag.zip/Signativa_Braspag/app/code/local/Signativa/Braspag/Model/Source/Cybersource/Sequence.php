<?php


class Signativa_Braspag_Model_Source_Cybersource_Sequence extends Signativa_Braspag_Model_Source_Abstract
{
    public function toOptionArray()
    {
        return [
            [
                'label' => 'Analyse First',
                'value' => \Braspag\API\FraudAnalysis::ANALYSE_FIRST_SEQUENCE
            ],
            [
                'label' => 'Authorize First',
                'value' => \Braspag\API\FraudAnalysis::AUTHORIZE_FIRST_SEQUENCE
            ]

        ];
    }
}