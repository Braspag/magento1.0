<?php


class Signativa_Braspag_Model_Fee
{

}