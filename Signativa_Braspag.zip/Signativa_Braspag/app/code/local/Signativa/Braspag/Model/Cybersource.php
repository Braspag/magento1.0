<?php


class Signativa_Braspag_Model_Cybersource extends Varien_Object
{

    const CONFIG_CONTAINER = 'payment/braspag_cybersource/';

    const CYBERSOURCE_TRUE = 'SIM';

    const CYBERSOURCE_FALSE = 'NAO';

    const CYBERSOURCE_CODE = 'Cybersource';

    /**
     *
     */
    public function _construct()
    {
        $this->setHelper(Mage::helper('braspag'));
    }

    /**
     * @return bool
     */
    public function isActive()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'active');
    }

    /**
     * @return Signativa_Braspag_Helper_Data
     */
    public function getHelper(): Signativa_Braspag_Helper_Data
    {
        return $this->getData('helper');
    }

    /**
     * Returns Organization ID
     * @return mixed
     */
    public function getOrgId()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . $this->getEnvironment() . '_organization_id');
    }

    /**
     * Returns Environment
     * @return string
     */
    public function getEnvironment()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'environment');
    }

    /**
     * @return string
     */
    public function getSequence()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'sequence');
    }

    /**
     * @return string
     */
    public function getSequenceCriteria()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'sequence_criteria');
    }

    /**
     * @return string
     */
    public function getCaptureOnLow()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'capture_on_low');
    }

    /**
     * @return string
     */
    public function getVoidOnHigh()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'void_on_high');
    }

    /**
     * @return mixed
     */
    public function getMerchantId()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'merchant_id');
    }

    /**
     * @return bool
     */
    public function getReturnsAccepted()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'returns_accepted');
    }

    /**
     * @return Signativa_Braspag_Model_Cybersource_Mdd
     * @throws Exception
     * @var $paymentInfo Mage_Sales_Model_Order_Payment
     */
    public function prepareMdd($paymentInfo): Signativa_Braspag_Model_Cybersource_Mdd
    {
        $instance = $this->getMddInstance();

        $instance->addValue(
            Signativa_Braspag_Model_Cybersource_Mdd::IS_LOGGED_IN,
            $this->getCustomerSession()->isLoggedIn() ? $this->getCustomerSession()->getCustomer()->getEmail() : 'Guest'
        );
        if ($this->getCustomerSession()->isLoggedIn()) {
            $instance->addValue(
                Signativa_Braspag_Model_Cybersource_Mdd::AMOUNT_DAYS_IS_CUSTOMER,
                $this->getAmountDaysCustomer()
            );
            $instance->addValue(
                Signativa_Braspag_Model_Cybersource_Mdd::DAYS_SINCE_LAST_ORDER,
                $this->getDaysSinceLastOrder()
            );
        }
        $instance->addValue(
            Signativa_Braspag_Model_Cybersource_Mdd::INSTALLMENT_AMOUNT,
            $paymentInfo->getPoNumber()
        );
        $instance->addValue(
            Signativa_Braspag_Model_Cybersource_Mdd::SALE_CHANNEL,
            $this->getSaleChannel()
        );
        if ($this->getFetchAtStoreMethod()) {
            $instance->addValue(
                Signativa_Braspag_Model_Cybersource_Mdd::CUSTOMER_WILL_FETCH,
                $this->isCurrentMethodFetch()
            );
        }
        $instance->addValue(
            Signativa_Braspag_Model_Cybersource_Mdd::ORDER_QTY,
            $this->getOrderQty()
        );
        $instance->addValue(
            Signativa_Braspag_Model_Cybersource_Mdd::CARD_NAME,
            $paymentInfo->getCcOwner()
        );
        $instance->addValue(
            Signativa_Braspag_Model_Cybersource_Mdd::AVERAGE_ORDER_AMOUNT,
            $this->getAverageOrderAmount()
        );

        $instance->addValue(
            Signativa_Braspag_Model_Cybersource_Mdd::IS_VIP_CUSTOMER,
            $this->isCustomerVip()
        );
        $instance->addValue(
            Signativa_Braspag_Model_Cybersource_Mdd::PLATFORM_NAME,
            Mage::getStoreConfig(Signativa_Braspag_Model_Method_Abstract::XML_PATH_PLATFORM_NAME)
        );

        if ($segment = $this->getBusinessSegment()) {
            $instance->addValue(Signativa_Braspag_Model_Cybersource_Mdd::BUSINESS_SEGMENT,
                $segment
            );
        }

        if ($this->getQuote()->getCustomerGender()) {
            $instance->addValue(Signativa_Braspag_Model_Cybersource_Mdd::CUSTOMER_SEX,
                $this->getCustomerGender()
            );
        }

        if ($bin = $this->getBin($paymentInfo)) {
            $instance->addValue(Signativa_Braspag_Model_Cybersource_Mdd::BIN_CC_NUMBER, $bin);
        }

        if ($lastFour = $paymentInfo->getCcLast4()) {
            $instance->addValue(Signativa_Braspag_Model_Cybersource_Mdd::SUFFIX_CC_NUMBER, $lastFour);
        }

        Mage::dispatchEvent('braspag_cybersource_mdd_set', ['mdd_instance' => $instance]);

        return $instance;
    }

    /**
     * Returns merchant defined fields representative instance
     * @return Signativa_Braspag_Model_Cybersource_Mdd
     */
    protected function getMddInstance(): Signativa_Braspag_Model_Cybersource_Mdd
    {
        return Mage::getModel('braspag/cybersource_mdd');
    }

    /**
     * @return Mage_Customer_Model_Session
     */
    protected function getCustomerSession(): Mage_Customer_Model_Session
    {
        return Mage::getSingleton('customer/session');
    }

    /**
     * @return int
     * @throws Exception
     */
    protected function getAmountDaysCustomer(): int
    {
        $createdAt = $this->getCustomerSession()->getCustomer()->getCreatedAt();
        return $this->getHelper()->getDateDifference($createdAt);
    }

    /**
     * @return int
     * @throws Exception
     */
    public function getDaysSinceLastOrder()
    {
        /**
         * @var $orderCollection Mage_Sales_Model_Resource_Order_Collection
         * @var $lastOrder Mage_Sales_Model_Order
         */
        $orderCollection = Mage::getSingleton("sales/order")->getCollection();
        $lastOrder = $orderCollection->addFieldToFilter('customer_email', $this->getQuote()->getCustomerEmail())
            ->setOrder('created_at', Mage_Sales_Model_Resource_Order_Collection::SORT_ORDER_DESC)
            ->getFirstItem();

        return $this->getHelper()->getDateDifference($lastOrder->getCreatedAt());
    }

    /**
     * @return Mage_Sales_Model_Quote
     */
    public function getQuote(): Mage_Sales_Model_Quote
    {
        if ($this->getData('quote')) {
            return $this->getData('quote');
        }
        $this->setData('quote', Mage::getSingleton('checkout/cart')->getQuote());

        return $this->getData('quote');
    }

    /**
     * By default the sale channel should be web, so we only return web here
     * @return string
     */
    public function getSaleChannel()
    {
        return 'Web';
    }

    /**
     * @return string
     */
    public function getFetchAtStoreMethod()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'fetch_at_store');
    }

    /**
     * @return string
     */
    public function isCurrentMethodFetch()
    {
        if ($this->getQuote()->isVirtual()) {
            return self::CYBERSOURCE_TRUE;
        }
        if (strpos($this->getQuote()->getShippingAddress()->getShippingMethod(),
                $this->getFetchAtStoreMethod()) !== false) {
            return self::CYBERSOURCE_TRUE;
        }
        return self::CYBERSOURCE_FALSE;
    }

    /**
     * @return int
     */
    public function getOrderQty()
    {
        /**
         * @var $orderCollection Mage_Sales_Model_Resource_Order_Collection
         */
        $orderCollection = Mage::getSingleton("sales/order")->getCollection();
        return $orderCollection->addFieldToFilter('customer_email', $this->getQuote()->getCustomerEmail())
            ->count();
    }

    /**
     * @return string
     */
    public function getSessionId(): string
    {
        /**
         * @var $session Mage_Core_Model_Session
         */
        $session = Mage::getSingleton('core/session');
        return $session->getEncryptedSessionId();
    }

    /**
     * @return bool
     */
    public function isBasicMode()
    {
        return $this->getMode() == Signativa_Braspag_Model_Source_Cybersource_Mode::BASIC_MODE;
    }

    /**
     * Returns current cybersource mode complete|basic
     * @return string
     */
    public function getMode()
    {
        $mode = $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'mode');

        return $mode ?? Signativa_Braspag_Model_Source_Cybersource_Mode::BASIC_MODE;
    }

    /**
     * @return bool
     */
    public function isCompleteMode()
    {
        return $this->getMode() == Signativa_Braspag_Model_Source_Cybersource_Mode::COMPLETE_MODE;
    }

    /**
     * @return bool
     */
    public function cancelOnError()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'cancel_on_error');
    }

    /**
     * @return bool
     */
    public function cancelOnReject()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'cancel_on_reject');
    }
    /**
     * @return bool
     */
    public function captureOnAccept()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'automatically_capture_accept');
    }
    /**
     * @return bool
     */
    public function callbackCancelOnReject()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'automatically_cancel_reject');
    }
    /**
     * @return bool
     */
    public function cancelOnAbort()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'automatically_cancel_abort');
    }
    /**
     * @return bool
     */
    public function cancelOnUnfinished()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'automatically_cancel_unfinished');
    }
    /**
     * @return bool
     */
    public function cancelOnUnknown()
    {
        return (bool)$this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'automatically_cancel_unknown');
    }

    public function getAverageOrderAmount()
    {
        $customerEmail = $this->getQuote()->getData('customer_email');
        /**
         * @var $orders Mage_Sales_Model_Resource_Order_Collection
         */
        $fromDate = date('Y-m-d H:i:s', strtotime('-6 months'));
        $orders = Mage::getModel('sales/order')->getCollection();
        $orders->addFieldToFilter('customer_email', $customerEmail)
                ->addFieldToFilter('created_at', array('from' => $fromDate))
                ->addFieldToFilter('state', array('neq' => Mage_Sales_Model_Order::STATE_CANCELED));
        /**
         * @var $order Mage_Sales_Model_Order
         */
        $totals = [];
        foreach ($orders as $order) {
            $totals[] = number_format($order->getGrandTotal(), 2);
        }
        $result = 0;
        if (count($totals) > 0) {
            $result = array_sum($totals) / count($totals);
        }

        return $this->getHelper()->filterDigits(number_format($result, 2));
    }

    /**
     * @return mixed
     */
    public function getCustomerGroupsVip()
    {
        return explode(",", $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER . 'customer_group_vip'));
    }

    /**
     * @return string
     */
    public function isCustomerVip()
    {
        if (in_array($this->getQuote()->getCustomerGroupId(), $this->getCustomerGroupsVip()))
        {
            return self::CYBERSOURCE_TRUE;
        }
        return self::CYBERSOURCE_FALSE;
    }

    /**
     * @return mixed
     */
    public function getBusinessSegment()
    {
        return $this->getHelper()->getAnyConfig(self::CONFIG_CONTAINER.'business_segment');
    }

    public function getBin(Mage_Sales_Model_Order_Payment $payment)
    {
        return substr($payment->getCcNumber(), 0, 6);
    }

    /**
     * @return string
     */
    public function getCustomerGender()
    {
        if ($this->getCustomerAttribute('gender')->getFrontend()->getValue($this->getQuote()->getCustomer()) == 'Male') {
            return 'M';
        }
        return 'F';
    }

    /**
     * @param $attributeCode
     * @return Mage_Eav_Model_Attribute
     */
    protected function getCustomerAttribute($attributeCode)
    {
        return Mage::getSingleton('eav/config')->getAttribute('customer', $attributeCode);
    }


}