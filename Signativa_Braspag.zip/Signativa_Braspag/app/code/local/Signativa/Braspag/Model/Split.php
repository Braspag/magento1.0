<?php


class Signativa_Braspag_Model_Split extends Mage_Core_Model_Abstract
{
    const XML_ACTIVE_PATH = 'payment/braspag_split/active';

    const XML_DEFAULT_MDR_PATH = 'payment/braspag_split/default_mdr';

    const XML_DEFAULT_FEE_PATH = 'payment/braspag_split/default_fee';

    const XML_DEFAULT_NON_SPLIT_ON_SPLIT = 'payment/braspag_split/allow_now_split_methods_on_splitable_quotes';

    /**
     * @param int $id
     * @return Signativa_Braspag_Model_Split_Merchant
     */
    public function fetchMerchant(int $id) : Signativa_Braspag_Model_Split_Merchant
    {
        return $this->getMerchantInstance()->load($id);
    }

    /**
     * @return Signativa_Braspag_Model_Split_Merchant
     */
    protected function getMerchantInstance() : Signativa_Braspag_Model_Split_Merchant
    {
        return Mage::getModel('braspag/split_merchant');
    }

    /**
     * @param Mage_Sales_Model_Quote $quote
     * @param Signativa_Braspag_Model_Split_Merchant $merchant
     * @return array
     * @throws Exception
     */
    public function prepareSplitFromQuote(Mage_Sales_Model_Quote $quote, Signativa_Braspag_Model_Split_Merchant $merchant) : array
    {
        $result = new Varien_Object();


        $result->setSubTotal(str_replace(',', '', str_replace('.', '',
                number_format(
                            $this->prepareSubtotal($this->getHelper()->getMerchantSubTotal($merchant, $quote),
                            $merchant,
                            $quote
                        ), 2
                    )
                )
            )
        );

        $result->setShipping(str_replace(',', '', str_replace('.', '',
                number_format($this->prepareShipping($quote->getShippingAddress()->getShippingAmount(), $merchant),2)
                )
            )
        );
        return $result->getData();

    }

    /**
     * @param $subTotal
     * @param Signativa_Braspag_Model_Split_Merchant $merchant
     * @param Mage_Sales_Model_Quote $quote
     * @return int
     * @throws Exception
     */
    protected function prepareSubtotal($subTotal, Signativa_Braspag_Model_Split_Merchant $merchant, Mage_Sales_Model_Quote $quote)
    {
        if ($merchant->getIsPercent()) {
            $value = $this->getHelper()->getPercentAsAmount($merchant->getSplitAmountSubtotal(), $subTotal);
        }
        else {
            if ($merchant->getSplitForEachItem()) {
                $value = (float) $this->getHelper()->getMerchantItemsQty($merchant, $quote) * $merchant->getSplitAmountSubtotal();
            }
            else {
                $value = (float) $merchant->getSplitAmountSubtotal();
            }
        }

        if ($value > $subTotal) {
            throw new Exception('Invalid split amount');
        }

        return $value;
    }

    /**
     * @param $shippingValue
     * @param Signativa_Braspag_Model_Split_Merchant $merchant
     * @return int
     * @throws Exception
     */
    protected function prepareShipping($shippingValue, Signativa_Braspag_Model_Split_Merchant $merchant)
    {
        if (!$merchant->getSplitShipping()) {
            return 0;
        }

        if ($merchant->getIsPercentShipping()) {
            $value = $this->getHelper()->getPercentAsAmount($merchant->getSplitAmountShipping(), $shippingValue);
        }
        else {
            $value = (float)$merchant->getSplitAmountShipping();
        }
        if ($value > $shippingValue) {
            throw new Exception('Invalid split amount');
        }

        return $value;
    }

    /**
     * @return Signativa_Braspag_Helper_Data
     */
    public function getHelper() : Signativa_Braspag_Helper_Data
    {
        return Mage::helper('braspag');
    }

    /**
     * @return bool
     */
    public function isActive() : bool
    {
        return (bool) $this->getHelper()->getAnyConfig(self::XML_ACTIVE_PATH);
    }

    /**
     * @return string
     */
    public function getDefaultMdr()
    {
        return number_format(Mage::getStoreConfig(self::XML_DEFAULT_MDR_PATH) ?? 0, 2);
    }

    public function getDefaultFee()
    {
        return str_replace(',', '', str_replace('.', '', number_format(Mage::getStoreConfig(self::XML_DEFAULT_MDR_PATH) ?? 0, 2)));
    }

    /**
     * @param Mage_Sales_Model_Quote $quote
     * @return Signativa_Braspag_Model_Resource_Split_Merchant_Collection
     */
    public function getMerchants(Mage_Sales_Model_Quote $quote) : Signativa_Braspag_Model_Resource_Split_Merchant_Collection
    {
        return Mage::getModel('braspag/split_merchant')->getCollection()
            ->addFieldToFilter('entity_id', array('in' => $this->getHelper()->getQuoteMerchantIds($quote)));
    }

    /**
     * Returns config that defines if non split methods are allowed on split quotes
     * @return bool
     */
    public function allowNonSplitOnSplit()
    {
        return (bool) Mage::getStoreConfig(self::XML_DEFAULT_NON_SPLIT_ON_SPLIT);
    }

    /**
     * @param Signativa_Braspag_Model_Split_Merchant $merchant
     * @param Mage_Sales_Model_Quote $quote
     * @return mixed
     */
    public function getMerchantTotal(Signativa_Braspag_Model_Split_Merchant $merchant, Mage_Sales_Model_Quote $quote)
    {
        return str_replace(',', '', str_replace('.', '', number_format($this->getHelper()->getMerchantSubTotal($merchant, $quote),  2)));
    }

    /**
     * @param Mage_Sales_Model_Quote $quote
     * @return mixed
     */
    public function getShippingAmount(Mage_Sales_Model_Quote $quote)
    {
        $shippingAmount = $quote->getShippingAddress()->getShippingAmount();
        return str_replace(',', '', str_replace('.', '', number_format($shippingAmount, 2)));
    }

}