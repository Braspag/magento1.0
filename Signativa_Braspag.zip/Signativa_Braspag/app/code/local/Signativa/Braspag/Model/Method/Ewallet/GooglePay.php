<?php


class Signativa_Braspag_Model_Method_Ewallet_GooglePay extends Signativa_Braspag_Model_Method_Ewallet_Abstract
{
    const XML_PATH_ALLOWED_CARD_NETWORKS = 'payment/braspag_ewallet/google_card_networks';

    const XML_PATH_MERCHANT_NAME = 'payment/braspag_ewallet/google_merchant_name';

    const XML_PATH_MERCHANT_ID = 'payment/braspag_ewallet/google_merchant_id';

    const DEFAULT_GATEWAY = 'cielo';

    const GOOGLEPAY_CARD_NETWORKS = [
        'AMEX' => 'American Express',
        'DISCOVER' => 'Discover',
        'INTERAC' => 'Interac',
        'JCB' => 'JCB',
        'MASTERCARD' => 'Mastercard',
        'VISA' => 'Visa'
    ];

    public function getSpecialTemplate()
    {
        return 'braspag'.DS.'method'.DS.'ewallet'.DS. 'special'.DS. 'googlepay.phtml';
    }

    /**
     * @return array
     */
    public function getAllowedCardNetworks ()
    {
        return explode(',', Mage::getStoreConfig(self::XML_PATH_ALLOWED_CARD_NETWORKS));
    }

    /**
     * @return string
     */
    public function getMerchantId() : string
    {
        return Mage::getStoreConfig(self::XML_PATH_MERCHANT_ID) ?? '';
    }

    /**
     * @return string
     */
    public function getMerchantName() : string
    {
        return Mage::getStoreConfig(self::XML_PATH_MERCHANT_NAME) ?? 'Merchant Example';
    }

    /**
     * @return string
     */
    public function getEnvironment () : string {
        if ($this->getEwallet()->isProduction()) {
            return 'PRODUCTION';
        }
        return 'TEST';
    }

    /**
     * @return stdClass
     * @throws Zend_Json_Exception
     */
    public function getAdditionalData()
    {
        $tokenData = $this->getParsedTokenData();
        $obj = new stdClass();
        $obj->Signature = $tokenData['signature'];
        return $obj;
    }

    /**
     * @return  string
     * @throws Zend_Json_Exception
     */
    public function getWalletKey()
    {
        return $this->getParsedTokenData()['signedMessage'];
    }

    /**
     * @return mixed
     * @throws Zend_Json_Exception
     */
    protected function getParsedTokenData ()
    {
        if (!$this->getData('parsed_token_data')) {
            $this->setData('parsed_token_data', Zend_Json::decode($this->getData('braspag_ewallet_token_data')));
        }
        return $this->getData('parsed_token_data');
    }
}