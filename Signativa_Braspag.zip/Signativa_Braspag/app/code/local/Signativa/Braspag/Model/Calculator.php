<?php


class Signativa_Braspag_Model_Calculator extends Varien_Object
{

}