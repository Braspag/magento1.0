<?php


class Signativa_Braspag_Model_CallbackHandler_RecurrenceActive extends Signativa_Braspag_Model_CallbackHandler_Abstract
{
    use Signativa_Braspag_Trait_Recurrence;

    /**
     * Handles recurrence active callback
     * @return $this
     * @throws \Braspag\API\Request\BraspagRequestException
     */
    public function execute()
    {
        /**
         * @var $sale \Braspag\API\Sale
         */
        $sale = $this->readySale();
        $orderIncrementId = $sale->getMerchantOrderId();
        /**
         * @var $order Mage_Sales_Model_Order
         */
        $order = Mage::getModel('sales/order')->load($orderIncrementId, 'increment_id');

        $recurrenceInstance = $this->getRecurrenceInstance($order->getId());

        $recurrenceInstance->setState(Signativa_Braspag_Model_Recurrence::STATUS_ACTIVE);

        $recurrenceInstance->save();

        $this->createRecurrenceFromOrder($order, $sale);

        return $this;
    }
}