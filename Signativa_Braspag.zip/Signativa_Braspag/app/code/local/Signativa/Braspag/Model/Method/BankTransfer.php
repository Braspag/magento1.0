<?php

use Braspag\API\Payment;
use Braspag\API\Sale;

/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/20/2019
 * Time: 10:40 PM
 */
class Signativa_Braspag_Model_Method_BankTransfer extends Signativa_Braspag_Model_Method_Abstract
{
    protected $method = 'banktransfer';
    protected $_formBlockType = 'braspag/method_bankTransfer_form';
    protected $_infoBlockType = 'braspag/method_bankTransfer_info';

    /**
     * @param $payment
     * @param $information Braspag\API\Sale
     * @return mixed|void
     * @throws Zend_Json_Exception
     */
    public function setAdditionalInformation($payment, $information)
    {
        /**
         * @var $paymentInfo Payment
         */
        $paymentInfo = $information->getPayment();
        $payment->setAdditionalInformation('payment_id', $paymentInfo->getPaymentId());
        $payment->setAdditionalInformation('status', $paymentInfo->getStatus());
        $payment->setAdditionalInformation('provider', $this->getProvider());

        if ($paymentInfo->getDoSplit()) {
            $payment->setAdditionalInformation('split_merchant', Zend_Json::decode(Zend_Json::encode($paymentInfo->getSplitPayments())));
        }
        /**
         * @var Mage_Checkout_Model_Session $session
         */
        $session = Mage::getSingleton('checkout/session');
        $session->setData(self::REDIRECT_CONTAINER, $paymentInfo->getUrl());
    }

    /**
     * @param Mage_Sales_Model_Order_Payment $payment
     * @param $amount
     * @return Sale
     * @throws Varien_Exception
     * @throws Exception
     */
    protected function readyOrder($payment, $amount)
    {
        /**
         * @var $quote Mage_Sales_Model_Quote
         */

        $amount = $this->prepareAmount($amount);

        $quote = Mage::getSingleton('checkout/session')->getQuote();

        $sale = $this->initSale($quote->getReservedOrderId());

        $sale->setCustomer(
            $this->prepareCustomer($quote)
        );
        $pay = $sale->payment($amount);
        $pay->setType(Payment::PAYMENTTYPE_ELECTRONIC_TRANSFER);
        $pay->setProvider($this->getProvider());
        $pay->setReturnUrl($this->getReturnUrl());

        return $sale;
    }

    /**
     * @param Varien_Object $payment
     * @param float $amount
     * @return $this|Signativa_Braspag_Model_Method_Debit
     * @throws Mage_Core_Exception
     * @throws Varien_Exception
     * @throws Zend_Json_Exception
     */
    public function order(Varien_Object $payment, $amount)
    {
        $sale = $this->readyOrder($payment, $amount);

        $result = $this->placeOrder($sale);

        $payment->setIsTransactionClosed(false);

        $payment->setTransactionId($result->getPayment()->getPaymentId());

        $this->setAdditionalInformation($payment, $result);

        return $this;
    }

    /**
     * @return string
     */
    public function getOrderPlaceRedirectUrl()
    {
        return Mage::getUrl('braspag/redirect');
    }
}