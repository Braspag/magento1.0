<?php


abstract class Signativa_Braspag_Model_Method_Ewallet_Abstract extends Varien_Object
{
    /**
     * @var Signativa_Braspag_Model_Ewallet
     */
    protected $ewallet;

    abstract public function getSpecialTemplate();

    /**
     * @param Signativa_Braspag_Model_Ewallet $ewallet
     * @return $this
     */
    public function setEwallet(Signativa_Braspag_Model_Ewallet $ewallet)
    {
        $this->ewallet = $ewallet;
        return $this;
    }

    /**
     * @return Signativa_Braspag_Model_Ewallet
     */
    public function getEwallet() : Signativa_Braspag_Model_Ewallet
    {
        return $this->ewallet;
    }
    /**
     * @return stdClass
     */
    abstract public function getAdditionalData();

    abstract public function getWalletKey();
}