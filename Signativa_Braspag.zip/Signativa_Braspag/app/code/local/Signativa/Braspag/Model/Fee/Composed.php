<?php


class Signativa_Braspag_Model_Fee_Composed extends Signativa_Braspag_Model_Fee
{

}