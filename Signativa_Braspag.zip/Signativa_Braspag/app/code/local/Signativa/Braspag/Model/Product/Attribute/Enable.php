<?php

class Signativa_Braspag_Model_Product_Attribute_Enable extends Mage_Eav_Model_Entity_Attribute_Source_Abstract
{
    /**
     * @return array
     */
    public function getAllOptions()
    {
        $this->_options = [
            [
                'value' => '',
                'label' => Mage::helper('catalog')->__('-- Please Select --'),
            ],
            [
                'value' => '1',
                'label' => Mage::helper('catalog')->__('Only recurrence'),
            ],
            [
                'value' => '2',
                'label' => Mage::helper('catalog')->__('Sale and recurrence'),
            ],
            [
                'value' => '0',
                'label' => Mage::helper('catalog')->__('Only sale'),
            ]
        ];

        return $this->_options;
    }
}
