<?php
include_once (Mage::getBaseDir('lib') . DS . 'braspag-php-sdk' . DS . 'vendor' . DS . 'autoload.php');
class Signativa_Braspag_Model_Cron extends Varien_Object
{



    public function updateOrders()
    {
        /**
         * @var $processor Signativa_Braspag_Model_Cron_OrderProcessor
         */
        $processor = $this->getTaskHandler('orderProcessor');
        if (!$processor) {
            throw new Exception('Could not load handler');
        }
        $processor->execute();
    }

    /**
     * @param $task
     * @return false|Signativa_Braspag_Model_Cron_Task
     */
    protected function getTaskHandler($task)
    {
        return Mage::getModel('braspag/cron_'.$task);
    }
}