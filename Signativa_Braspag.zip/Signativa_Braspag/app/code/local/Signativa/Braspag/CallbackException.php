<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/22/2019
 * Time: 8:05 PM
 */

class Signativa_Braspag_CallbackException extends Mage_Core_Exception
{
    /**
     * @var
     */
    private $callbackBody;

    /**
     * @return mixed
     */
    public function getCallbackBody()
    {
        return $this->callbackBody;
    }

    /**
     * @param mixed $callbackBody
     */
    public function setCallbackBody($callbackBody)
    {
        $this->callbackBody = $callbackBody;
    }


}