<?php


use Braspag\API\Payment;
use Braspag\API\RecurrentPayment;

trait Signativa_Braspag_Trait_Recurrence
{
    use Signativa_Braspag_Trait_Api;

    /**
     * @param Payment $payment
     * @param Mage_Sales_Model_Quote_Item $item
     * @return Payment
     */
    public function addRecurrenceToPayment (Payment $payment, Mage_Sales_Model_Quote_Item $item)
    {
        $payment->setRecurrent(true);
        $obj = new stdClass();
        $obj->AuthorizeNow = (bool)$this->getRecurrenceHelper()->getConfig('authorize');
        $obj->EndDate = $this->getRecurrenceHelper()->calculateDuration($item->getProduct()->getBraspagRecurrenceDuration());
        $obj->Interval = $item->getProduct()->getBraspagRecurrencePeriod();

        $payment->setRecurrentPayment($obj);

        return $payment;
    }

    /**
     * @return Signativa_Braspag_Helper_Recurrence
     */
    public function getRecurrenceHelper() : Signativa_Braspag_Helper_Recurrence
    {
        return Mage::helper('braspag/recurrence');
    }

    /**
     * @param $transactionId
     * @return $this
     */
    public function deactivateOnline($transactionId)
    {
        $this->getApi()->deactivateRecurrence($transactionId);
        return $this;
    }

    /**
     * @param $transactionId
     * @return $this
     */
    public function activateOnline($transactionId)
    {
        $this->getApi()->activateRecurrence($transactionId);
        return $this;
    }

}