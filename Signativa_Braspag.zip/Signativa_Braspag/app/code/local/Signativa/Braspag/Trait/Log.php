<?php

use Braspag\API\Sale;

trait  Signativa_Braspag_Trait_Log
{
    private $filename = 'signativa_braspag.log';

    public function log($data, $type = Zend_Log::DEBUG)
    {
        Mage::log($data, $type, $this->filename, true);
        return $this;
    }

    /**
     * @param Sale $payment
     * @return $this
     */
    public function logPayment(Sale $payment)
    {
        $newPayment = json_decode(json_encode( $payment));

        $this->log('[Braspag Payment #'.$newPayment->merchantOrderId.']');

        if ($creditCard = $newPayment->payment->creditCard)
        {
            $creditCard->cardNumber = substr($this->cardNumber, 0, 6).'******'.substr($this->cardNumber, 0, -4);
            $creditCard->securityCode = preg_replace('/[0-9]/', '*', $this->securityCode);
        }

        if ($debitCard = $newPayment->payment->debitCard)
        {
            $debitCard->cardNumber = substr($this->cardNumber, 0, 6).'******'.substr($this->cardNumber, 0, -4);
            $debitCard->securityCode = preg_replace('/[0-9]/', '*', $this->securityCode);
        }

        $this->log($newPayment);

        return $this;
    }
}