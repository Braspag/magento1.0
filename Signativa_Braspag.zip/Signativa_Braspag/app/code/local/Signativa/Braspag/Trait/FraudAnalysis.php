<?php


use Braspag\API\AnalysisResponse;
use Braspag\API\FraudAnalysis;
use Braspag\API\Token;

trait Signativa_Braspag_Trait_FraudAnalysis
{

    /**
     * @return |null
     * @throws Exception
     */
    public function getFraudAnalysisToken() : Token
    {
        return $this->getApi()->getAccessTokenFraudAnalysis();
    }

    /**
     * @param $analysisSubject
     * @return AnalysisResponse
     * @throws Exception
     */
    public function sendToAnalysis($analysisSubject)
    {
        return $this->getApi()->analyseTransaction(
            $this->getFraudAnalysisToken()->getAccessToken(),
            $analysisSubject
        );
    }

    /**
     * @param $fraudAnalysisId
     * @return \Braspag\API\Analysis
     * @throws Exception
     */
    public function getAnalysis($fraudAnalysisId)
    {
        return $this->getApi()->getFraudAnalysis(
            $this->getFraudAnalysisToken()->getAccessToken(),
            $fraudAnalysisId
        );
    }

    /**
     * Handles analysis result
     * @param AnalysisResponse|FraudAnalysis $response
     * @param Mage_Sales_Model_Order_Payment $payment
     * @throws Mage_Core_Exception
     */
    public function handleAnalysis($response, $payment)
    {
        //done for all possible statuses
        if ($this->getCybersource()->isCompleteMode()) {
            switch($response->getStatus()) {
                case AnalysisResponse::ACCEPT_STATUS: // transaction accepted
                case AnalysisResponse::PENDENT_STATUS: //pending transaction
                case AnalysisResponse::REVIEW_STATUS:
                    $this->addAntiFraudIntoPayment($response,$payment);
                    break;
                case AnalysisResponse::REJECT_STATUS:
                    if ($this->getCybersource()->cancelOnReject() || $this->getCybersource()->getSequenceCriteria() == FraudAnalysis::CRITERIA_ON_SUCCESS) {
                        $this->handleException(new Signativa_Braspag_AnalysisErrorException($this->getCybersource()->getHelper()->__('Transaction rejected by antifraud')));
                    }
                    else {
                        $this->addAntiFraudIntoPayment($response,$payment);
                    }
                    break;
                case AnalysisResponse::UNFINISHED_STATUS:
                case AnalysisResponse::ERROR_STATUS:
                    if ($this->getCybersource()->cancelOnError()){
                        $this->handleException( new Signativa_Braspag_AnalysisErrorException($this->getCybersource()->getHelper()->__('Antifraud error please try again')) );
                    }
                    else {
                        $this->addAntiFraudIntoPayment($response,$payment);
                    }
                    break;
            }
        }
        else {
            if (in_array($response->getStatus(), Signativa_Braspag_Model_CallbackHandler_AntifraudStatus::REJECT_STATUS)) {
                if ($this->getCybersource()->getSequenceCriteria() == FraudAnalysis::CRITERIA_ON_SUCCESS) {
                    $this->handleException(new Signativa_Braspag_AnalysisErrorException($this->getCybersource()->getHelper()->__('Transaction rejected by antifraud')));
                }
            }
            else if  (in_array($response->getStatus(), Signativa_Braspag_Model_CallbackHandler_AntifraudStatus::REJECT_STATUS) ||
                      in_array($response->getStatus(), Signativa_Braspag_Model_CallbackHandler_AntifraudStatus::UNFINISHED_STATUS)
            ) {
                if ($this->getCybersource()->cancelOnError()){
                    $this->handleException( new Signativa_Braspag_AnalysisErrorException($this->getCybersource()->getHelper()->__('Antifraud error please try again')) );
                }
            }
        }
    }

    /**
     * gets cybersource model instance
     * @return Signativa_Braspag_Model_Cybersource
     */
    public function getCybersource() : Signativa_Braspag_Model_Cybersource
    {
        return Mage::getSingleton('braspag/cybersource');
    }

    /**
     * @param Signativa_Braspag_AnalysisErrorException $exception
     * @throws Signativa_Braspag_AnalysisErrorException
     * @throws Signativa_Braspag_VoidTransactionException
     */
    public function handleException(Signativa_Braspag_AnalysisErrorException $exception)
    {
        if ($this->getCybersource()->getSequence() == FraudAnalysis::AUTHORIZE_FIRST_SEQUENCE) {
            throw new Signativa_Braspag_VoidTransactionException($exception->getMessage());
        }
        throw $exception;
    }

    /**
     * @param AnalysisResponse $response
     * @param Mage_Sales_Model_Order_Payment $payment
     * @return $this
     * @throws Mage_Core_Exception
     */
    protected function addAntiFraudIntoPayment(AnalysisResponse $response, $payment)
    {
        $payment->setAdditionalInformation('cybersource_transaction_id', $response->getTransactionId());
        $payment->setAdditionalInformation('cybersource_status', $response->getStatus());
        return $this;
    }

}