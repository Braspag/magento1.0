<?php


trait Signativa_Braspag_Trait_Magento
{
    /**
     * @param $incrementId string
     * @return Mage_Sales_Model_Order|mixed
     */
    public function getOrder($incrementId)
    {
        return Mage::getModel('sales/order')->load($incrementId, 'increment_id');
    }

    /**
     * @param Mage_Sales_Model_Order $order
     * @param bool $notifyCustomer
     * @param bool $captureOnline
     * @return Mage_Sales_Model_Order_Invoice
     * @throws Mage_Core_Exception
     * @throws Exception
     */
    public function createInvoice(Mage_Sales_Model_Order $order, $notifyCustomer = false, $captureOnline = false)
    {
        if (!$order->canInvoice()) {
            throw new \Exception('Cannot create invoice for order: ' . $order->getIncrementId());
        }
        /**
         * @var $invoice Mage_Sales_Model_Order_Invoice
         */
        $invoice = Mage::getModel('sales/service_order', $order)->prepareInvoice();

        if (!$invoice->getTotalQty()) {
            Mage::throwException(Mage::helper('core')->__('Cannot create an invoice without products.'));
        }

        $invoice->setRequestedCaptureCase($captureOnline ? Mage_Sales_Model_Order_Invoice::CAPTURE_ONLINE : Mage_Sales_Model_Order_Invoice::CAPTURE_OFFLINE);

        $invoice->register()
            ->pay();

        $this->addTransaction($invoice);

        if ($notifyCustomer) {
            $invoice->sendEmail();
        }

        return $invoice;
    }

    /**
     * @param Mage_Sales_Model_Order $order
     * @return Mage_Sales_Model_Order
     * @throws Exception
     */
    public function cancelOrder(Mage_Sales_Model_Order $order)
    {
        if (!$order->canCancel()) {
            throw new \Exception('Cannot cancel order: ' . $order->getIncrementId());
        }

        return $order->cancel()->save();
    }

    /**
     * @param Mage_Sales_Model_Order_Invoice $invoice
     * @param Mage_Sales_Model_Order|null $order
     * @return mixed
     */
    public function addTransaction(Mage_Sales_Model_Order_Invoice $invoice, Mage_Sales_Model_Order $order = null)
    {
        if (!$order) {
            $order = $invoice->getOrder();
        }

        $transactionSave = Mage::getModel('core/resource_transaction')
            ->addObject($invoice)
            ->addObject($order);
        return $transactionSave->save();
    }

    /**
     * @param Mage_Sales_Model_Order $order
     * @param \Braspag\API\Sale $parentInfo
     * @return mixed
     * @throws Mage_Core_Exception
     * @throws Mage_Core_Model_Store_Exception
     */
    public function createRecurrenceFromOrder($order, $parentInfo)
    {
        Mage::register('parent_info', $parentInfo);
        Mage::register('is_recurrence_create', true, true);
        $recurrenceInstance = $this->getRecurrenceInstance($order->getId());
        $store = Mage::app()->getStore();
        $website = Mage::app()->getWebsite();
        $quote = Mage::getModel('sales/quote')->setStoreId($store->getId());
        $customer_email = $order->getCustomerEmail();
        $billingAddress = $order->getBillingAddress()->getData();
        $shippingAddress = $order->getShippingAddress()->getData();

        // check whether the customer already registered or not
        $customer = Mage::getModel('customer/customer')->setWebsiteId($website->getId())->loadByEmail($customer_email);

        // assign the customer to quote
        $quote->assignCustomer($customer);

        // set currency for the quote
        $quote->setCurrency(Mage::app()->getStore()->getBaseCurrencyCode());
        /**
         * @var $item Signativa_Braspag_Model_Recurrence_Item
         */
        foreach($recurrenceInstance->getItems() as $item) {
            if ($item->getState() == Signativa_Braspag_Model_Recurrence_Item::DISABLE) {
                continue;
            }
            $quote->addProduct($item->getProduct(), $item->getQty());
        }

        $billingAddressData = $quote->getBillingAddress()->addData($billingAddress);

        $shippingAddressData = $quote->getShippingAddress()->addData($shippingAddress);

        // collect shipping rates on quote
        $shippingAddressData->setCollectShippingRates(true)
            ->collectShippingRates();

        // set shipping method and payment method on the quote
        $shippingAddressData->setShippingMethod($order->getShippingMethod())
            ->setPaymentMethod('braspag_recurrence');

        // Set payment method for the quote
        /**
         * @var $payment Mage_Sales_Model_Quote_Payment
         */
        $payment = $quote->getPayment();
        $payment->importData(array('method' => 'braspag_recurrence'));

        try {

            // collect totals & save quote
            $quote->collectTotals()->save();

            // create order from quote
            /**
             * @var $service Mage_Sales_Model_Service_Quote
             */
            $service = Mage::getModel('sales/service_quote', $quote);
            $service->submitAll();

            $service->getOrder()->getId();
            /**
             * @var $method Signativa_Braspag_Model_Method_Recurrence
             */
            $method = $service->getOrder()->getPayment()->getMethodInstance();
            $method->setAdditionalInformation($service->getOrder()->getPayment(), $parentInfo);
            $service->getOrder()->getPayment()->save();
            //send new recurrence email
            $this->sendNewRecurrenceEmail($service->getOrder());

            if (!$recurrenceInstance->getId()) {
                throw new \Exception('Could not load recurrence instance to associate');
            }
            $this->createInvoice($service->getOrder());

            $recurrenceInstance->setLastOrderCreated($service->getOrder()->getIncrementId())->save();

            $recurrenceInstance->addTransaction($service->getOrder());


        } catch (Exception $e) {
            throw $e;
        }
        return $this;
    }

    /**
     * Retrieve session object
     *
     * @return Mage_Checkout_Model_Session
     */
    protected function _getSession()
    {
        return Mage::getSingleton('checkout/session');
    }

    /**
     * @param $orderId string
     * @return Signativa_Braspag_Model_Recurrence
     */
    protected function getRecurrenceInstance($orderId)
    {
        /**
         * @var $recurrence Signativa_Braspag_Model_Recurrence
         */
        $recurrence = Mage::getModel('braspag/recurrence');
        $recurrence->load($orderId, 'parent_id');

        return $recurrence;
    }

    /**
     * @param Mage_Sales_Model_Order $order
     * @param bool $isOffline
     * @return Signativa_Braspag_Trait_Magento
     */
    public function createCreditmemo(Mage_Sales_Model_Order $order, $isOffline = false)
    {
        foreach ($order->getInvoiceCollection() as $invoice) {
            $service = Mage::getModel('sales/service_order', $order);

            $creditmemo = $service->prepareInvoiceCreditmemo($invoice);
            $creditmemo->setRefundRequested(true)
                ->setOfflineRequested($isOffline) // request to refund online
                ->register();

            Mage::getModel('core/resource_transaction')
                ->addObject($creditmemo)
                ->addObject($creditmemo->getOrder())
                ->addObject($creditmemo->getInvoice())
                ->save();
        }

        return $this;
    }

    /**
     * @param Mage_Sales_Model_Order $order
     * @return $this
     * @throws Exception
     */
    public function sendNewRecurrenceEmail(Mage_Sales_Model_Order $order)
    {
        if (!Mage::getStoreConfig(Signativa_Braspag_Model_Recurrence::XML_PATH_EMAIL_ENABLED, $order->getStoreId())) {
            $this->log('Can not send new recurrence order email, reason: config is disabled');
            return $this;
        }
        $ccs = [];
        $data = Mage::getStoreConfig(Signativa_Braspag_Model_Recurrence::XML_PATH_EMAIL_COPY_TO, $order->getStoreId());
        if (!empty($data)) {
            $ccs = explode(',', $data);
        }
        // Start store emulation process
        /** @var $appEmulation Mage_Core_Model_App_Emulation */
        $appEmulation = Mage::getSingleton('core/app_emulation');
        $initialEnvironmentInfo = $appEmulation->startEnvironmentEmulation($order->getStoreId());

        try {
            // Retrieve specified view block from appropriate design package (depends on emulated store)
            $paymentBlock = Mage::helper('payment')->getInfoBlock($order->getPayment())
                ->setIsSecureMode(true);
            $paymentBlock->getMethod()->setStore($order->getStoreId());
            $paymentBlockHtml = $paymentBlock->toHtml();
        } catch (Exception $exception) {
            // Stop store emulation process
            $appEmulation->stopEnvironmentEmulation($initialEnvironmentInfo);
            throw $exception;
        }

        // Stop store emulation process
        $appEmulation->stopEnvironmentEmulation($initialEnvironmentInfo);
        $sender = Mage::getStoreConfig(Signativa_Braspag_Model_Recurrence::XML_PATH_EMAIL_IDENTITY, $order->getStoreId());
        $params = array(
            'order'        => $order,
            'billing'      => $order->getBillingAddress(),
            'payment_html' => $paymentBlockHtml
        );
        $this->sendEmail(
            $order,
            $order->getStoreId(),
            Mage::getStoreConfig(Signativa_Braspag_Model_Recurrence::XML_PATH_NEW_RECURRENCE_EMAIL, $order->getStoreId()),
            $sender,
            $params,
            $ccs,
            Mage::getStoreConfig(Signativa_Braspag_Model_Recurrence::XML_PATH_EMAIL_COPY_METHOD, $order->getStoreId())
        );
    }

    /**
     * @param Mage_Sales_Model_Order $order
     * @param $storeId
     * @param $templateId
     * @return Mage_Core_Model_Email_Template_Mailer
     * @throws Exception
     */
    public function sendEmail(Mage_Sales_Model_Order $order, $storeId, $templateId, $sender, $params, $copyTo , $copyMethod)
    {

        $customerName = $order->getCustomerName();


        /** @var $mailer Mage_Core_Model_Email_Template_Mailer */
        $mailer = Mage::getModel('core/email_template_mailer');
        /** @var $emailInfo Mage_Core_Model_Email_Info */
        $emailInfo = Mage::getModel('core/email_info');
        $emailInfo->addTo($order->getCustomerEmail(), $customerName);

        $mailer->addEmailInfo($emailInfo);
        if ($copyTo && $copyMethod == 'bcc') {
            // Add bcc to customer email
            foreach ($copyTo as $email) {
                $emailInfo->addBcc($email);
            }
        }
        $mailer->addEmailInfo($emailInfo);

        // Email copies are sent as separated emails if their copy method is 'copy'
        if ($copyTo && $copyMethod == 'copy') {
            foreach ($copyTo as $email) {
                $emailInfo = Mage::getModel('core/email_info');
                $emailInfo->addTo($email);
                $mailer->addEmailInfo($emailInfo);
            }
        }

        $mailer->setSender($sender);
        $mailer->setStoreId($storeId);
        $mailer->setTemplateId($templateId);
        $mailer->setTemplateParams($params);

        return $mailer->send();
    }

    public function createOrderFromQuote(Mage_Sales_Model_Quote $quote, $paymentData)
    {
        try {
            /**
             * @var $payment Mage_Sales_Model_Quote_Payment
             */
            $payment = $quote->getPayment();
            $payment->importData($paymentData);

            // collect totals & save quote
            $quote->collectTotals()->save();
            /**
             * @var $service Mage_Sales_Model_Service_Quote
             */
            $service = Mage::getModel('sales/service_quote', $quote);
            $service->submitAll();
            $service->getOrder()->getId();
            $method = $service->getOrder()->getPayment()->getMethodInstance();
            $service->getOrder()->getPayment()->save();
            return $service->getOrder();
        }
        catch (Exception $e) {
            throw $e;
        }
    }
}