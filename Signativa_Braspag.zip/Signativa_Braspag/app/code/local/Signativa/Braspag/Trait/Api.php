<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/23/2019
 * Time: 6:51 PM
 */

use Braspag\API\Braspag;
use Braspag\API\Client;
use Braspag\API\Environment;
use Braspag\API\Merchant;


trait Signativa_Braspag_Trait_Api
{
    /**
     * @var Braspag
     */
    private $api;

    /**
     * @return Merchant|null
     */
    public function getMerchant()
    {
        if (!$this->getMerchantId() || !$this->getMerchantKey()) {
            $this->log('No merchant key or id defined');
            return null;
        }
        return new Merchant($this->getMerchantId(), $this->getMerchantKey());
    }

    /**
     * Returns Braspag Environment
     * @return Environment
     */
    public function getEnvironment()
    {
        return Environment::{$this->_getEnvironment()}();
    }

    /**
     * @return mixed|string
     */
    protected function _getEnvironment()
    {
        if (!$environment = Mage::getStoreConfig('payment/braspag/environment')) {
            return 'sandbox';
        }
        return $environment;
    }

    /**
     * @return mixed
     */
    public function getMerchantId($isCielo = false)
    {
        $prefix = '';
        if ($isCielo) {
            $prefix = 'cielo_';
        }
        return Mage::getStoreConfig("payment/braspag/{$this->_getEnvironment()}_{$prefix}merchant_id");
    }

    /**
     * @return string
     */
    protected function getMerchantKey($isCielo =false)
    {
        $prefix = '';
        if ($isCielo) {
            $prefix = 'cielo_';
        }
        return Mage::getStoreConfig("payment/braspag/{$this->_getEnvironment()}_{$prefix}merchant_key");
    }

    /**
     * @return mixed
     */
    protected function getClientId()
    {
        return Mage::getStoreConfig("payment/braspag_cybersource/{$this->_getFraudAnalysisEnvironment()}_client_id");
    }

    /**
     * @return mixed
     */
    protected function getClientSecret()
    {
        return Mage::getStoreConfig("payment/braspag_cybersource/{$this->_getFraudAnalysisEnvironment()}_client_secret");
    }

    /**
     * @return mixed
     */
    public function _getFraudAnalysisEnvironment ()
    {
        return Mage::getStoreConfig('payment/braspag_cybersource/environment');
    }

    /**
     * @return bool
     */
    public function isFraudAnalysisActive ()
    {
        return (bool) Mage::getStoreConfig("payment/braspag_cybersource/active");
    }

    /**
     * @param bool $cieloClient
     * @return Braspag
     */
    protected function getApi($cieloClient = false): Braspag
    {
        if (!$this->api) {
            if ($cieloClient) {
                $this->api = new Braspag($this->getMerchant(), $this->getEnvironment(), $this->getClient(true));
            }
            else {
                $this->api = new Braspag($this->getMerchant(), $this->getEnvironment(), $this->isFraudAnalysisActive() ? $this->getClient() : null);
            }
        }
        return $this->api;
    }

    /**
     * @param $paymentId
     * @param null $amount
     * @param null $tax
     * @return \Braspag\API\Payment
     * @throws \Braspag\API\Request\BraspagRequestException
     */
    protected function captureOnline($paymentId, $amount = null, $tax = null)
    {
        if ($amount) {
            $amount = $this->prepareAmount($amount);
        }
        return $this->getApi()->captureSale($paymentId, $amount, $tax);
    }

    /**
     * @param $paymentId
     * @param null $amount
     * @return \Braspag\API\Sale
     * @throws \Braspag\API\Request\BraspagRequestException
     */
    protected function cancelOnline($paymentId, $amount = null)
    {
        if ($amount) {
            $amount = $this->prepareAmount($amount);
        }
        return $this->getApi()->cancelSale($paymentId, $amount);
    }

    /**
     * @param $paymentId
     * @return \Braspag\API\Sale
     * @throws \Braspag\API\Request\BraspagRequestException
     */
    protected function getSaleInfo($paymentId)
    {
        return $this->getApi()->getSale($paymentId);
    }

    /**
     * @param $paymentId
     * @return \Braspag\API\RecurrentPayment
     * @throws \Braspag\API\Request\BraspagRequestException
     */
    protected function getRecurrentSaleInfo($paymentId)
    {
        return $this->getApi()->getRecurrentPayment($paymentId);
    }

    /**
     * @param $amount
     * @return float|int
     */
    protected function prepareAmount($amount) {
        return $amount * 100;
    }

    public function getClient($isCielo = false) : Client
    {
        if ($isCielo) {
            return new Client($this->getMerchantId(true), $this->getMerchantKey(true));
        }
        return new Client((string)$this->getClientId(), (string)$this->getClientSecret());
    }

    /**
     * @param $paymentId
     * @return \Braspag\API\Sale
     * @throws Exception
     */
    public function getSplitInfo($paymentId)
    {
        return $this->getApi(true)->getSplitSale($this->getSplitToken()->getAccessToken(), $paymentId);
    }

    /**
     * @return \Braspag\API\Token
     * @throws Exception
     */
    public function getSplitToken() : \Braspag\API\Token
    {
        return $this->getApi(true)->getAccessToken();
    }
}