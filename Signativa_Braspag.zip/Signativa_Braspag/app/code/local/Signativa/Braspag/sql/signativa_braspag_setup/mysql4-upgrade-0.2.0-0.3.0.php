<?php

$installer = $this;
$installer->startSetup();

$installer = Mage::getResourceModel('sales/setup', 'default_setup');

$installer->addAttribute("order", "is_order_recurrence", array("type"=>"varchar"));
$installer->addAttribute("quote", "is_order_recurrence", array("type"=>"varchar"));
$installer->endSetup();