<?php
/**
 * @var $this Mage_Core_Model_Resource_Setup
 * @var $resource Mage_Core_Model_Resource
 */
$resource = Mage::getSingleton('core/resource');
$writeConnection = $resource->getConnection('core_write');
$this->startSetup();

$tableName = $this->getTable('braspag/hash');
/**
 * 1st step
 * Create table that stores credit card hashes
 */
if (!$writeConnection->isTableExists($tableName)) {
    $table = $writeConnection->newTable($tableName)
        ->addColumn('entity_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'identity' => true,
            'unsigned' => true,
            'nullable' => false,
            'primary' => true,
        ), 'Id')
        ->addColumn('customer_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned' => true,
            'nullable' => false
        ), 'Customer ID')
        ->addColumn('card_hash', Varien_Db_Ddl_Table::TYPE_TEXT, null, array(
            'unsigned' => true,
            'nullable' => false,
            'length' => 150
        ), 'Is Active')
        ->addColumn('card_brand', Varien_Db_Ddl_Table::TYPE_TEXT, null, array(
            'unsigned' => true,
            'nullable' => false,
            'length' => 50
        ), 'Card Brand')
        ->addColumn('last_four_digits', Varien_Db_Ddl_Table::TYPE_TEXT, null, array(
            'unsigned' => true,
            'nullable' => false,
            'length' => 25
        ), 'Card`s last four digits');
    $writeConnection->createTable($table);
}
/**
 * 2nd step
 * Create table that stores recurrent orders
 */
$tableName = $this->getTable('braspag/recurrence');
if (!$writeConnection->isTableExists($tableName)) {
    $table = $writeConnection->newTable($tableName)
        ->addColumn('recurrence_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'identity' => true,
            'unsigned' => true,
            'nullable' => false,
            'primary' => true,
        ), 'Id')
        ->addColumn('parent_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned' => true
        ), 'Parent order ID')
        ->addColumn('state', Varien_Db_Ddl_Table::TYPE_TEXT, 32, array(
            'nullable' =>true
        ), 'State')
        ->addColumn('recurrent_transaction_id', Varien_Db_Ddl_Table::TYPE_TEXT, 150, array(
        ), 'Recurrent Transaction Id')
        ->addColumn('grand_total', Varien_Db_Ddl_Table::TYPE_DECIMAL, '12,4', array(
        ), 'Grand Total')
        ->addColumn('discount_amount', Varien_Db_Ddl_Table::TYPE_DECIMAL, '12,4', array(
        ), 'Discount Amount')
        ->addColumn('shipping_amount', Varien_Db_Ddl_Table::TYPE_DECIMAL, '12,4', array(
        ), 'Shipping Amount')
        ->addColumn('shipping_method', Varien_Db_Ddl_Table::TYPE_TEXT, 255, array(
        ), 'Shipping Method')
        ->addColumn('store_id', Varien_Db_Ddl_Table::TYPE_SMALLINT, null, array(
            'unsigned'  => true,
        ), 'Store Id')
        ->addColumn('customer_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned'  => true,
        ), 'Customer Id')
        ->addColumn('last_order_created', Varien_Db_Ddl_Table::TYPE_TEXT, 50, array(
        ), 'Increment Id of last order')
        ->addColumn('next_recurrence', Varien_Db_Ddl_Table::TYPE_DATE, null, array(
        ), 'Next recurrence')
        ->addColumn('created_at', Varien_Db_Ddl_Table::TYPE_TIMESTAMP, null, array(
        ), 'Created At')
        ->addColumn('updated_at', Varien_Db_Ddl_Table::TYPE_TIMESTAMP, null, array(
        ), 'Updated At')
        ->addIndex($this->getIdxName('sales/order', array('store_id')),
            array('store_id'))
        ->addIndex($this->getIdxName('braspag/recurrence', array('created_at')),
            array('created_at'))
        ->addIndex($this->getIdxName('braspag/recurrence', array('customer_id')),
            array('customer_id'))
        ->addForeignKey($this->getFkName('braspag/recurrence', 'customer_id', 'customer/entity', 'entity_id'),
            'customer_id', $this->getTable('customer/entity'), 'entity_id',
            Varien_Db_Ddl_Table::ACTION_SET_NULL, Varien_Db_Ddl_Table::ACTION_CASCADE);
        $table->addForeignKey($this->getFkName('braspag/recurrence', 'parent_id', 'sales/order', 'entity_id'),
            'parent_id', $this->getTable('sales/order'), 'entity_id',
            Varien_Db_Ddl_Table::ACTION_SET_NULL, Varien_Db_Ddl_Table::ACTION_CASCADE);
        $table->addForeignKey($this->getFkName('braspag/recurrence', 'store_id', 'core/store', 'store_id'),
            'store_id', $this->getTable('core/store'), 'store_id',
            Varien_Db_Ddl_Table::ACTION_SET_NULL, Varien_Db_Ddl_Table::ACTION_CASCADE);
    $writeConnection->createTable($table);
}
/**
 * 3rd step
 * Create table that stores recurrent orders items
 */
$tableName = $this->getTable('braspag/recurrence_item');
if (!$writeConnection->isTableExists($tableName)) {
    $table = $writeConnection->newTable($tableName)
        ->addColumn('item_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'identity' => true,
            'unsigned' => true,
            'nullable' => false,
            'primary' => true,
        ), 'Id')
        ->addColumn('recurrence_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned' => true,
        ), 'Id')
        ->addColumn('parent_item_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned' => true
        ), 'Parent order ID')
        ->addColumn('sku', Varien_Db_Ddl_Table::TYPE_TEXT, 255, array(
        ), 'Sku')
        ->addColumn('state', Varien_Db_Ddl_Table::TYPE_TEXT, 32, array(
        ), 'State')
        ->addColumn('price', Varien_Db_Ddl_Table::TYPE_DECIMAL, '12,4', array(
        ), 'Item price')
        ->addColumn('qty', Varien_Db_Ddl_Table::TYPE_DECIMAL, '12,4', array(
            'default'   => '0.0000',
        ), 'Qty Ordered')
        ->addColumn('recurrence_period', Varien_Db_Ddl_Table::TYPE_TEXT, 50, array(
        ), 'Recurrence period')
        ->addColumn('recurrence_duration', Varien_Db_Ddl_Table::TYPE_TEXT, 50, array(
        ), 'Recurrence duration')
        ->addColumn('created_at', Varien_Db_Ddl_Table::TYPE_TIMESTAMP, null, array(
        ), 'Created At')
        ->addColumn('updated_at', Varien_Db_Ddl_Table::TYPE_TIMESTAMP, null, array(
        ), 'Updated At')
        ->addIndex($this->getIdxName('braspag/recurrence_item', array('created_at')),
            array('created_at'))
        ->addIndex($this->getIdxName('braspag/recurrence_item', array('state')),
            array('state'))
        ->addForeignKey($this->getFkName('braspag/recurrence_item', 'recurrence_id', 'braspag/recurrence', 'recurrence_id'),
            'recurrence_id', $this->getTable('braspag/recurrence'), 'recurrence_id',
            Varien_Db_Ddl_Table::ACTION_SET_NULL, Varien_Db_Ddl_Table::ACTION_CASCADE);
    $table->addForeignKey($this->getFkName('braspag/recurrence_item', 'parent_item_id', 'sales/order_item', 'item_id'),
        'parent_item_id', $this->getTable('sales/order_item'), 'item_id',
        Varien_Db_Ddl_Table::ACTION_SET_NULL, Varien_Db_Ddl_Table::ACTION_CASCADE);
    $writeConnection->createTable($table);
}
/**
 * 3rd step
 * Create table that stores recurrent orders transactions
 */
$tableName = $this->getTable('braspag/recurrence_transaction');
if (!$writeConnection->isTableExists($tableName)) {
    $table = $writeConnection->newTable($tableName)
        ->addColumn('recurrence_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned' => true,
        ), 'Id')
        ->addColumn('order_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned' => true
        ), 'Order ID')
        ->addColumn('created_at', Varien_Db_Ddl_Table::TYPE_TIMESTAMP, null, array(
        ), 'Created At')
        ->addIndex($this->getIdxName('braspag/recurrence_item', array('created_at')),
            array('created_at'))
        ->addForeignKey($this->getFkName('braspag/recurrence_transaction', 'recurrence_id', 'braspag/recurrence', 'recurrence_id'),
            'recurrence_id', $this->getTable('braspag/recurrence'), 'recurrence_id',
            Varien_Db_Ddl_Table::ACTION_SET_NULL, Varien_Db_Ddl_Table::ACTION_CASCADE);
    $table->addForeignKey($this->getFkName('braspag/recurrence_transaction', 'order_id', 'sales/order', 'entity_id'),
        'order_id', $this->getTable('sales/order'), 'entity_id',
        Varien_Db_Ddl_Table::ACTION_SET_NULL, Varien_Db_Ddl_Table::ACTION_CASCADE);
    $writeConnection->createTable($table);
}
/**
 * 4th step
 * Create table that stores callbacks
 */
$tableName = $this->getTable('braspag/ewallet_callback');
if (!$writeConnection->isTableExists($tableName)) {
    $table = $writeConnection->newTable($tableName)
        ->addColumn('entity_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned' => true,
            'identity' => true,
            'nullable' => false,
            'primary' => true,
        ), 'Id')
        ->addColumn('quote_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned' => true
        ), 'Order ID')
        ->addColumn('serialized_content', Varien_Db_Ddl_Table::TYPE_TEXT, 5000, array(), 'Callback contents')
        ->addColumn('created_at', Varien_Db_Ddl_Table::TYPE_TIMESTAMP, null, array(
        ), 'Created At')
        ->addIndex($this->getIdxName('braspag/recurrence_item', array('created_at')),
            array('created_at'));
    $table->addForeignKey($this->getFkName('braspag/recurrence_transaction', 'quote_id', 'sales/quote', 'entity_id'),
        'quote_id', $this->getTable('sales/quote'), 'entity_id',
        Varien_Db_Ddl_Table::ACTION_SET_NULL, Varien_Db_Ddl_Table::ACTION_CASCADE);
    $writeConnection->createTable($table);
}
/**
 * 5th step
 * Create table that stores recurrent orders transactions
 */
$tableName = $this->getTable('braspag/split_merchant');
if (!$writeConnection->isTableExists($tableName)) {
    $table = $writeConnection->newTable($tableName)
        ->addColumn('entity_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'identity' => true,
            'unsigned' => true,
            'nullable' => false,
            'primary' => true,
        ), 'Id')
        ->addColumn('merchant_id', Varien_Db_Ddl_Table::TYPE_TEXT, 150, array(
        ), 'Merchant ID')
        ->addColumn('merchant_name', Varien_Db_Ddl_Table::TYPE_TEXT, 150, array(
        ), 'Merchant Name')
        ->addColumn('split_amount_subtotal', Varien_Db_Ddl_Table::TYPE_DECIMAL,'10,4' , array(
        ), 'Split amount subtotal')
        ->addColumn('split_for_each_item', Varien_Db_Ddl_Table::TYPE_SMALLINT,'1' , array(
        ), 'Split for each items')
        ->addColumn('is_percent', Varien_Db_Ddl_Table::TYPE_SMALLINT,'1' , array(
        ), 'Split amount')
        ->addColumn('split_shipping', Varien_Db_Ddl_Table::TYPE_SMALLINT,'1' , array(
        ), 'Split amount is percentage')
        ->addColumn('split_amount_shipping', Varien_Db_Ddl_Table::TYPE_DECIMAL,'10,4' , array(
        ), 'Split amount shipping')
        ->addColumn('is_percent_shipping', Varien_Db_Ddl_Table::TYPE_SMALLINT,'1' , array(
        ), 'Is split shipping percentage')
        ->addColumn('mdr', Varien_Db_Ddl_Table::TYPE_DECIMAL,'10,4' , array(
        ), 'MDR Tax')
        ->addColumn('created_at', Varien_Db_Ddl_Table::TYPE_TIMESTAMP, null, array(
        ), 'Created At')
        ->addIndex($this->getIdxName('braspag/recurrence_item', array('created_at')),
            array('created_at'))
        ->addIndex($this->getIdxName('braspag/recurrence_item', array('merchant_id')),
            array('merchant_id'));
    $writeConnection->createTable($table);
}
/**
 * 6th step
 * Create table that stores mdr rates of merchants
 */
$tableName = $this->getTable('braspag/split_merchant_mdr_rate');
if (!$writeConnection->isTableExists($tableName)) {
    $table = $writeConnection->newTable($tableName)
        ->addColumn('entity_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'identity' => true,
            'unsigned' => true,
            'nullable' => false,
            'primary' => true,
        ), 'Id')
        ->addColumn('merchant_id', Varien_Db_Ddl_Table::TYPE_INTEGER, null, array(
            'unsigned' => true,
            'nullable' => false,
        ), 'Merchant Id')
        ->addColumn('installment', Varien_Db_Ddl_Table::TYPE_SMALLINT, 2, array(
            'unsigned' => true,
            'nullable' => false
        ))
        ->addColumn('brand', Varien_Db_Ddl_Table::TYPE_VARCHAR, 50, array(
            'unsigned' => true,
            'nullable' => false
        )
        )->addColumn('mdr', Varien_Db_Ddl_Table::TYPE_DECIMAL,'10,4' , array(
        ), 'MDR Tax')
        ->addColumn('debit', Varien_Db_Ddl_Table::TYPE_SMALLINT, 1, array(
            'unsigned' => true,
            'nullable' => false
        ));

    $table->addForeignKey($this->getFkName('braspag/split_merchant_mdr_rate', 'merchant_id', 'braspag/split_merchant', 'entity_id'),
        'merchant_id', $this->getTable('braspag/split_merchant'), 'entity_id',
        Varien_Db_Ddl_Table::ACTION_CASCADE, Varien_Db_Ddl_Table::ACTION_CASCADE);
    $writeConnection->createTable($table);
}
/**
 * @var $productInstaller Mage_Catalog_Model_Resource_Setup
 */
$productInstaller = Mage::getResourceModel('catalog/setup', 'default_setup');
if (!$productInstaller->getAttribute(Mage_Catalog_Model_Product::ENTITY, 'braspag_is_recurrent', 'attribute_id')) {
    $productInstaller->addAttribute(
        Mage_Catalog_Model_Product::ENTITY,
        'braspag_is_recurrent',
        [
            'type'                    => 'int',
            'input'                   => 'select',
            'backend'                 => '',
            'frontend'                => '',
            'label'                   => 'Is Recurrent',
            'class'                   => '',
            'source'                  => 'braspag/product_attribute_enable',
            'global'                  => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
            'visible'                 => true,
            'required'                => false,
            'user_defined'            => true,
            'default'                 => '',
            'searchable'              => false,
            'filterable'              => false,
            'comparable'              => false,
            'visible_on_front'        => false,
            'unique'                  => false,
            'is_configurable'         => false,
            'used_in_product_listing' => false,
            'option'                  => [
                'values' => [],
            ],
        ]
    );
}
if (!$productInstaller->getAttribute(Mage_Catalog_Model_Product::ENTITY, 'braspag_recurrence_period', 'attribute_id')) {
    $productInstaller->addAttribute(
        Mage_Catalog_Model_Product::ENTITY,
        'braspag_recurrence_period',
        [
            'type'                    => 'varchar',
            'input'                   => 'select',
            'backend'                 => '',
            'frontend'                => '',
            'label'                   => 'Recurrence Period',
            'class'                   => '',
            'source'                  => 'braspag/product_attribute_period',
            'global'                  => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
            'visible'                 => true,
            'required'                => false,
            'user_defined'            => true,
            'default'                 => '',
            'searchable'              => false,
            'filterable'              => false,
            'comparable'              => false,
            'visible_on_front'        => false,
            'unique'                  => false,
            'is_configurable'         => false,
            'used_in_product_listing' => false,
            'option'                  => [
                'values' => [],
            ],
        ]
    );
}

if (!$productInstaller->getAttribute(Mage_Catalog_Model_Product::ENTITY, 'braspag_recurrence_duration', 'attribute_id')) {
    $productInstaller->addAttribute(
        Mage_Catalog_Model_Product::ENTITY,
        'braspag_recurrence_duration',
        [
            'type'                    => 'varchar',
            'input'                   => 'select',
            'backend'                 => '',
            'frontend'                => '',
            'label'                   => 'Recurrence duration',
            'class'                   => '',
            'source'                  => 'braspag/product_attribute_duration',
            'global'                  => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
            'visible'                 => true,
            'required'                => false,
            'user_defined'            => true,
            'default'                 => '',
            'searchable'              => false,
            'filterable'              => false,
            'comparable'              => false,
            'visible_on_front'        => false,
            'unique'                  => false,
            'is_configurable'         => false,
            'used_in_product_listing' => false,
            'option'                  => [
                'values' => [],
            ],
        ]
    );
}
if (!$productInstaller->getAttribute(Mage_Catalog_Model_Product::ENTITY, 'braspag_merchant_id', 'attribute_id')) {
    $productInstaller->addAttribute(
        Mage_Catalog_Model_Product::ENTITY,
        'braspag_merchant_id',
        [
            'type'                    => 'varchar',
            'input'                   => 'select',
            'backend'                 => '',
            'frontend'                => '',
            'label'                   => 'Split Merchant',
            'class'                   => '',
            'source'                  => 'braspag/product_attribute_merchant',
            'global'                  => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
            'visible'                 => true,
            'required'                => false,
            'user_defined'            => true,
            'default'                 => '',
            'searchable'              => false,
            'filterable'              => false,
            'comparable'              => false,
            'visible_on_front'        => false,
            'unique'                  => false,
            'is_configurable'         => false,
            'used_in_product_listing' => false,
            'option'                  => [
                'values' => [],
            ],
        ]
    );
}
/**
$installer = Mage::getResourceModel('sales/setup', 'default_setup');

$installer->startSetup();

$installer->addAttribute('order', 'base_braspag_fee', array
(
    'label' => 'Base Juros',
    'type'  => 'decimal',
));

$installer->addAttribute('quote', 'braspag_fee', array
(
    'label' => 'Juros',
    'type'  => 'decimal',
));

$installer->addAttribute('quote', 'base_braspag_fee', array
(
    'label' => 'Base Juros',
    'type'  => 'decimal',
));

$installer->addAttribute('order', 'braspag_fee', array
(
    'label' => 'Juros',
    'type'  => 'decimal',
));

$installer->addAttribute('invoice', 'base_braspag_fee', array
(
    'label' => 'Base Juros',
    'type'  => 'decimal',
));

$installer->addAttribute('invoice', 'braspag_fee', array
(
    'label' => 'Juros',
    'type'  => 'decimal',
));

$installer->addAttribute('creditmemo', 'base_braspag_fee', array
(
    'label' => 'Base Juros',
    'type'  => 'decimal',
));

$installer->addAttribute('creditmemo', 'braspag_fee', array
(
    'label' => 'Juros',
    'type'  => 'decimal',
));
*/
$this->endSetup();

