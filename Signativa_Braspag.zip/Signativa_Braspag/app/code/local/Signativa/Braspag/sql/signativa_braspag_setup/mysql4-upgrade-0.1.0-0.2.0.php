<?php

$this->startSetup();
$productInstaller = Mage::getResourceModel('catalog/setup', 'default_setup');

if (!$productInstaller->getAttribute(Mage_Catalog_Model_Product::ENTITY, 'braspag_recurrence_price', 'attribute_id')) {
    $productInstaller->addAttribute(
        Mage_Catalog_Model_Product::ENTITY,
        'braspag_recurrence_price',
        [
            'type'                    => 'decimal',
            'input'                   => 'text',
            'backend'                 => '',
            'frontend'                => '',
            'label'                   => 'Recurrence Price',
            'class'                   => '',
            'source'                  => '',
            'global'                  => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_STORE,
            'visible'                 => true,
            'required'                => false,
            'user_defined'            => true,
            'default'                 => '',
            'searchable'              => false,
            'filterable'              => false,
            'comparable'              => false,
            'visible_on_front'        => false,
            'unique'                  => false,
            'is_configurable'         => false,
            'used_in_product_listing' => false,
            'option'                  => [
                'values' => [],
            ],
        ]
    );
}