<?php

require_once(Mage::getModuleDir('controllers','Mage_Customer').DS.'AccountController.php');

class Signativa_Braspag_RecurrenceController extends Mage_Customer_AccountController
{
    /**
     *  action braspag/recurrence/list
     */
    public function listAction() {
        $this->loadLayout();
        $this->_initLayoutMessages('customer/session');
        $this->_initLayoutMessages('catalog/session');
        $this->renderLayout();
    }

    /**
     * action braspag/recurrence/view/id/{id}
     * @throws Mage_Core_Exception
     */
    public function viewAction ()
    {
        $recurrenceId = $this->getRequest()->getParam('id');
        /**
         * @var $recurrence Signativa_Braspag_Model_Recurrence
         */
        $recurrence = Mage::getModel('braspag/recurrence')->load($recurrenceId);
        try {
            $recurrence->getRecurrenceInfo();
        }
        catch (Exception $err) {
            $this->_getSession()->addError($this->_getHelper('braspag')->__('Could not find recurrence'));
            $this->_redirectReferer();
            return;
        }

        if ($recurrence->getCustomerId() != $this->_getSession()->getCustomer()->getId()) {
            $this->_getSession()->addError($this->_getHelper('braspag')->__('Invalid recurrence Id'));
            $this->_redirectReferer();
            return;
        }

        Mage::register('current_recurrence', $recurrence);

        $this->loadLayout();
        $this->_initLayoutMessages('customer/session');
        $this->_initLayoutMessages('catalog/session');
        $this->renderLayout();
    }
    /**
     * action braspag/recurrence/deactivate/id/{id}
     * @throws Mage_Core_Exception
     */
    public function deactivateAction()
    {
        $recurrenceId = $this->getRequest()->getParam('id');
        try {
            if (!$this->canAlterStatus()) {
                throw new Exception('Action not allowed');
            }

            if ($recurrenceId) {
                $recurrence = $this->getRecurrence($recurrenceId);

                if ($recurrence->getCustomerId() != $this->_getSession()->getCustomer()->getId()) {
                    $this->_getSession()->addError($this->_getHelper('braspag')->__('Invalid recurrence Id'));
                    $this->_redirectReferer();
                    return;
                }

                if ($recurrence->getState() != Signativa_Braspag_Model_Recurrence::STATUS_ACTIVE) {
                    $this->_getSession()->addSuccess($this->_getHelper('braspag')->__('Recurrence is aleready deactivated'));
                    $this->_redirectReferer();
                    return $this;
                }

                if (!$recurrence->getId()) {
                    throw new Exception('Could not find recurrence');
                }
                $recurrence->deactivate(true);
                $this->_getSession()->addSuccess($this->_getHelper('braspag')->__('Recurrence deactivated successfully'));
                $this->_redirectReferer();
            }
        }
        catch (Exception $e) {
            $this->_getSession()->addError($this->_getHelper('braspag')->__($e->getMessage()));
            $this->_redirectReferer();
        }
    }

     /**
     * action braspag/recurrence/activate/id/{id}
     * @throws Mage_Core_Exception
     */
    public function activateAction()
    {
        $recurrenceId = $this->getRequest()->getParam('id');
        try {
            if (!$this->canAlterStatus()) {
                throw new Exception('Action not allowed');
            }
            if ($recurrenceId) {
                $recurrence = $this->getRecurrence($recurrenceId);
                
                if ($recurrence->getCustomerId() != $this->_getSession()->getCustomer()->getId()) {
                    $this->_getSession()->addError($this->_getHelper('braspag')->__('Invalid recurrence Id'));
                    $this->_redirectReferer();
                    return;
                }

                if ($recurrence->getState() == Signativa_Braspag_Model_Recurrence::STATUS_ACTIVE) {
                    $this->_getSession()->addSuccess($this->_getHelper('braspag')->__('Recurrence is aleready activated'));
                    $this->_redirectReferer();
                    return $this;
                }

                if (!$recurrence->getId()) {
                    throw new Exception('Could not find recurrence');
                }
                $recurrence->activate(true);
                $this->_getSession()->addSuccess($this->_getHelper('braspag')->__('Recurrence activated successfully'));
                $this->_redirectReferer();
            }
        }
        catch (Exception $e) {
            $this->_getSession()->addError($this->_getHelper('braspag')->__($e->getMessage()));
            $this->_redirectReferer();
        }
    }
    /**
     * Undocumented function
     *
     * @param int $id
     * @return Signativa_Braspag_Model_Recurrence
     */
    protected function getRecurrence($id) : Signativa_Braspag_Model_Recurrence
    {
        return Mage::getModel('braspag/recurrence')->load($id);
    }


    public function canAlterStatus() 
    {
        /**
         * @var Signativa_Braspag_Helper_Recurrence $helper
         */
        $helper = Mage::helper('braspag/recurrence');
        return (bool) $helper->getConfig('customer_can_alter_status');
    }
}