<?php

class Signativa_Braspag_CallbackController extends Mage_Core_Controller_Front_Action
{
    use Signativa_Braspag_Trait_Log;

    /**
     * @throws Zend_Controller_Response_Exception
     */
    public function indexAction()
    {
        if (!$this->getRequest()->isPost()) {
            $this->norouteAction();
            return;
        }
        try {
            $this->getHandler()->handle($this->getRequest());
        } catch (Signativa_Braspag_CallbackException $e) {
            $this->log('[BRASPAG EXCEPTION]' . $e->getMessage() . "\n" . $e->getTraceAsString());
            $this->getResponse()->setHttpResponseCode(500);
        } catch (Exception $e) {
            $this->log('[EXCEPTION]' . $e->getMessage() . "\n" . $e->getTraceAsString());
            $this->getResponse()->setHttpResponseCode(500);
        }
    }

    /**
     * @return Signativa_Braspag_Model_CallbackHandler
     */
    private function getHandler()
    {
        return Mage::getSingleton('braspag/callbackHandler');
    }
}