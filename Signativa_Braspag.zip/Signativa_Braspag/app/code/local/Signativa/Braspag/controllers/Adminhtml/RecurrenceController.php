<?php


class Signativa_Braspag_Adminhtml_RecurrenceController extends Mage_Adminhtml_Controller_Action
{
    public function indexAction()
    {
        $this->loadLayout()
            ->_setActiveMenu('sales')
            ->_title($this->__('Manager recurrences'));
        $this->_addContent($this->getLayout()->createBlock('braspag/adminhtml_recurrence'));
        $this->renderLayout();
    }

    public function editAction()
    {
        if (!$this->getRequest()->getParam('entity_id')) {
            Mage::getSingleton('adminhtml/session')->addError('No recurrence defined');
            $this->_redirectReferer();
            return;
        }

        $recurrence = $this->getRecurrence($this->getRequest()->getParam('entity_id'));

        if (!$recurrence->getId()) {
            Mage::getSingleton('adminhtml/session')->addError($this->_getHelper()->__('Could not find recurrence'));
            $this->_redirectReferer();
            return;
        }
        Mage::register('current_recurrence', $recurrence);

        $this->loadLayout()
            ->_setActiveMenu('sales')
            ->_title($this->__('Manager recurrences'));
        $this->_addContent($this->getLayout()->createBlock('braspag/adminhtml_recurrence_edit'))
             ->_addLeft($this->getLayout()->createBlock('braspag/adminhtml_recurrence_edit_tabs'));
        $this->renderLayout();
    }

    public function deactivateAction()
    {
        $recurrenceId = $this->getRequest()->getParam('id');
        try {

            if ($recurrenceId) {
                $recurrence = $this->getRecurrence($recurrenceId);

                if (!$recurrence->getId()) {
                    throw new Exception('Could not find recurrence');
                }
                $recurrence->deactivate(true);
                Mage::getSingleton('adminhtml/session')->addSuccess($this->_getHelper()->__('Recurrence deactivated successfully'));
                $this->_redirectReferer();
            }
        }
        catch (Exception $e) {
            Mage::getSingleton('adminhtml/session')->addError($this->_getHelper()->__($e->getMessage()));
            $this->_redirectReferer();
        }
    }

    public function activateAction()
    {
        $recurrenceId = $this->getRequest()->getParam('id');
        try {

            if ($recurrenceId) {
                $recurrence = $this->getRecurrence($recurrenceId);

                if (!$recurrence->getId()) {
                    throw new Exception('Could not find recurrence');
                }
                $recurrence->activate(true);
                Mage::getSingleton('adminhtml/session')->addSuccess($this->_getHelper()->__('Recurrence activated successfully'));
                $this->_redirectReferer();
            }
        }
        catch (Exception $e) {
            Mage::getSingleton('adminhtml/session')->addError($this->_getHelper()->__($e->getMessage()));
            $this->_redirectReferer();
        }
    }

    protected function getRecurrence($id) : Signativa_Braspag_Model_Recurrence
    {
        return Mage::getModel('braspag/recurrence')->load($id);
    }

    protected function _isAllowed()
    {
        return Mage::getSingleton('admin/session')->isAllowed('admin/sales/braspag_recurrence');
    }
}