<?php
class Signativa_Braspag_RedirectController extends Mage_Core_Controller_Front_Action
{
    use Signativa_Braspag_Trait_Log;

    public function indexAction()
    {
        if ($url = $this->getSessionUrl()) {
            $this->unsetUrl();
            $this->_redirectUrl($url);
        } else {
            $this->getSession()->addError(Mage::helper('braspag')->__('Could not redirect to checkout'));
            $this->log('No url found to redirect user');
            $this->_redirect(Mage::getUrl('checkout/cart'));
        }
        return;
    }

    /**
     * @return string
     */
    private function getSessionUrl()
    {
        return $this->getSession()->getData(Signativa_Braspag_Model_Method_Abstract::REDIRECT_CONTAINER);
    }

    /**
     * @return Mage_Checkout_Model_Session
     */
    private function getSession()
    {
        return Mage::getSingleton('checkout/session');
    }

    /**
     * @return Varien_Object
     */
    public function unsetUrl()
    {
        return $this->getSession()->unsetData(Signativa_Braspag_Model_Method_Abstract::REDIRECT_CONTAINER);
    }
}