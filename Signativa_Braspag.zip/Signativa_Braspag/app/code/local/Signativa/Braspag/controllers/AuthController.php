<?php


class Signativa_Braspag_AuthController extends Mage_Core_Controller_Front_Action
{
    public function fetch_blockAction()
    {
        if (!count(Mage::getSingleton('checkout/cart')->getQuote()->getAllItems())) {
            $this->norouteAction();
            return;
        }
        $this->getResponse()->setHeader('Content-Type', 'application/json');
        $response = [];
        $blocks = $this->getRequest()->getParam('blocks', []);
        foreach ($blocks as $block) {
            if ($blockName = $this->getBlockLoader()->getBlockNameByContainer($block)) {
                $response[] = [
                    'container' => $block,
                    'html' => $this->getBlockLoader()->getBlock($blockName)
                ];
            }
        }
        $this->getResponse()->setBody(Zend_Json::encode($response));
    }

    /**
     * @return Mage_Core_Model_Abstract|Signativa_Braspag_Model_ThreeDs_BlockLoader
     */
    public function getBlockLoader()
    {
        return Mage::getSingleton('braspag/threeDS_blockLoader')->setLayout($this->getLayout());
    }
}