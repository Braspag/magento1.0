<?php

require_once(Mage::getModuleDir('controllers','Mage_Checkout').DS.'OnepageController.php');

class Signativa_Braspag_EwalletController extends Mage_Checkout_OnepageController
{
    use Signativa_Braspag_Trait_Log;

    /**
     *
     */
    public function updateAction()
    {
        $response = new Varien_Object();
        try {
            $this->getResponse()->setHeader('Content-Type', 'application/json');
            $response->setTotal(number_format($this->getQuote()->getGrandTotal(), 2));
            $response->setCurrencyCode($this->getQuote()->getQuoteCurrencyCode());
            $response->setItems($this->getEwallet()->getHelper()->prepareItems($this->getQuote()->getAllVisibleItems()));
        }
        catch (Exception $err) {
            $this->log($err->getMessage());
            $response->setError(true);
        }
        $this->getResponse()->setBody($response->toJson());
    }

    public function getEwallet() : Signativa_Braspag_Model_Ewallet
    {
        return Mage::getSingleton('braspag/ewallet');
    }

    public function getQuote() : Mage_Sales_Model_Quote
    {
        return $this->getEwallet()->getQuote();
    }

    public function callbackAction ()
    {
        /**
         * @var $result Signativa_Braspag_Model_Ewallet_Callback
         */
        $result = $this->getHelper()->handleCallback($this->getRequest());
        try {
            if ($this->getEwallet()->getEwalletInstance() instanceof  Signativa_Braspag_Model_Method_Ewallet_Callbackable) {
                $result->setQuoteId($this->getEwallet()->getEwalletInstance()->fetchQuoteId($result));
                $result->save();
                $res = $this->getEwallet()->getEwalletInstance()->handleCallback($result);
                if ($res instanceof Mage_Sales_Model_Order) {
                    $this->getCheckoutSession()->setLastOrderId($res->getIncrementId());
                    $this->_redirectUrl(Mage::getUrl('checkout/onepage/success'));
                }
            }
            else {
                $this->getResponse()->setHttpResponseCode(200);
            }
        }
        catch (Signativa_Braspag_CallbackException $e) {
            $this->log('EWALLET CALLBACK ERROR]'. $e->getMessage(). "\n". $e->getTraceAsString());
            $this->getCheckoutSession()->setLastQuoteId($result->getQuoteId());
            $this->getCheckoutSession()->setLastOrderId($result->getQuoteId());
            $this->_redirectUrl(Mage::getUrl('checkout/onepage/failure'));
        }
        catch(Exception $e) {
            $this->log('EWALLET CALLBACK ERROR]'. $e->getMessage(). "\n". $e->getTraceAsString());
            $this->getResponse()->setHttpResponseCode(500);
        }
    }

    public function getHelper() : Signativa_Braspag_Helper_Ewallet
    {
        return Mage::helper('braspag/ewallet');
    }

    /**
     * @return Mage_Checkout_Model_Session
     */
    public function getCheckoutSession() : Mage_Checkout_Model_Session
    {
        return Mage::getSingleton('checkout/session');
    }
}