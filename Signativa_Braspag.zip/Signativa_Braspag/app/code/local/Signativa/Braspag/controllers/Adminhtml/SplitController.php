<?php


class Signativa_Braspag_Adminhtml_SplitController extends Mage_Adminhtml_Controller_Action
{
    public function indexAction()
    {
        $this->loadLayout()
            ->_setActiveMenu('sales')
            ->_title($this->__('Manager Split Merchants'));
        $this->_addContent($this->getLayout()->createBlock('braspag/adminhtml_split'));
        $this->renderLayout();
    }
    public function newAction()
    {
        Mage::register('current_split', Mage::getModel('braspag/split_merchant'));

        $this->loadLayout()
            ->_setActiveMenu('sales')
            ->_title($this->__('Manager split merchants'));
        $this->_addContent($this->getLayout()->createBlock('braspag/adminhtml_split_edit'));
        $this->renderLayout();
    }
    public function editAction()
    {
        if (!$this->getRequest()->getParam('entity_id')) {
            Mage::getSingleton('adminhtml/session')->addError($this->_getHelper()->__('No split merchant defined'));
            $this->_redirectReferer();
        }

        $split = $this->getSplit($this->getRequest()->getParam('entity_id'));

        if (!$split->getId()) {
            Mage::getSingleton('adminhtml/session')->addError('Could not find recurrence');
            $this->_redirectReferer();
        }
        Mage::register('current_split', $split);

        $this->loadLayout()
            ->_setActiveMenu('sales')
            ->_title($this->__('Manager split merchants'));
        $this->_addContent($this->getLayout()->createBlock('braspag/adminhtml_split_edit'));
        $this->renderLayout();
    }

    /**
     * @param $id
     * @return Signativa_Braspag_Model_Split_Merchant
     */
    public function getSplit($id) : Signativa_Braspag_Model_Split_Merchant
    {
        return Mage::getModel('braspag/split_merchant')->load($id);
    }

    public function saveAction ()
    {
        if (strpos($this->_getRefererUrl(), 'new') === false && !$this->getRequest()->getParam('id')) {
            Mage::getSingleton('adminhtml/session')->addError($this->_getHelper()->__('No split merchant defined'));
            $this->_redirectReferer();
            return;
        }

        $split = $this->getSplit($this->getRequest()->getParam('id'));

        $data = $this->getRequest()->getPost();
        try {
            $split->addData($data)
                ->save();
            if (isset($data['mdr_rates'])) {
                $rates = $data['mdr_rates'];
                $rates = array_filter($rates);
                $savedIds = array_keys($rates);
                $savedMdrs = $split->getMdrRates();
                /**
                 * @var $mdrRate Signativa_Braspag_Model_Split_Merchant_Mdr_Rate
                 */
                foreach ($savedMdrs as $mdrRate) {
                    if (!in_array($mdrRate->getId(), $savedIds)) {
                        $mdrRate->delete();
                    }
                }

                foreach ($rates as $id => $rate)
                {
                    $hasUpdates = false;
                    foreach ($savedMdrs as $mdrRate) {
                        if ($mdrRate->getId() == $id) {
                            $mdrRate->setBrand($mdrRate['brand'])
                                    ->setInstallment($rate['installment'])
                                    ->setMdr($rate['mdr'])
                                    ->setDebit($rate['debit'])
                                    ->save();
                            $hasUpdates = true;
                        }
                    }
                    if (!$hasUpdates)
                        $split->addMdrRate($rate['brand'], $rate['installment'], $rate['mdr'], $rate['debit']);
                }
            }
            Mage::getSingleton('adminhtml/session')->addSuccess($this->_getHelper()->__('Saved successfully'));
            $this->_redirect('adminhtml/split/index');
        }
        catch (Exception $e) {
            Mage::getSingleton('adminhtml/session')->addError($this->_getHelper()->__($e->getMessage()));
            $this->_redirectReferer();
        }
    }
}