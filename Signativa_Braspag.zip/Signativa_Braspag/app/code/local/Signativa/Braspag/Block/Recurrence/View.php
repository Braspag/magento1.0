<?php


class Signativa_Braspag_Block_Recurrence_View extends Mage_Customer_Block_Account_Dashboard
{
    public function getRecurrence() : Signativa_Braspag_Model_Recurrence
    {
        return Mage::registry('current_recurrence');
    }

    public function getTitle()
    {
        return "#{$this->getRecurrence()->getId()} ".$this->__('Recurrence')." - {$this->__($this->getRecurrence()->getStateLabel())}";
    }


    public function getRecurrenceDeactivateUrl() 
    {
        return $this->getUrl('braspag/recurrence/deactivate/', ['id' => $this->getRecurrence()->getId()]);
    }

    public function getRecurrenceActivateUrl() 
    {
        return $this->getUrl('braspag/recurrence/activate/', ['id' => $this->getRecurrence()->getId()]);
    }

    public function getStateChangeButton() 
    {
        if ($this->getRecurrence()->getState() == Signativa_Braspag_Model_Recurrence::STATUS_FINALIZED) {
            return '';
        }

        $html = '<button class="button recurrence-state-change" data-recurrence-id="'.$this->getRecurrence()->getId().'">';
        if ($this->getRecurrence()->getState() == Signativa_Braspag_Model_Recurrence::STATUS_ACTIVE) {
            $html .= $this->__('Deactivate').'</button>';
        }
        else {
            $html .= $this->__('Activate').'</button>';
        }

        return $html;
    }

    public function getActionUrl() 
    {
        if ($this->getRecurrence()->getState() == Signativa_Braspag_Model_Recurrence::STATUS_ACTIVE) {
            return $this->getRecurrenceDeactivateUrl();
        }
        else if (in_array($this->getRecurrence()->getState(), Signativa_Braspag_Model_Recurrence::STATUS_HOLD)) {
            return $this->getRecurrenceActivateUrl();
        }
    }

    public function canShowActionButton() : bool
    {
        return (bool) $this->getRecurrence()->getRecurrenceHelper()->getConfig('customer_can_alter_status');
    }
}