<?php
/**
 * Created by PhpStorm.
 * User: Matheus
 * Date: 5/16/2019
 * Time: 8:01 PM
 */

class Signativa_Braspag_Block_Method_Bankslip_Info extends Mage_Payment_Block_Info
{
    protected function _construct()
    {
        $this->setTemplate('braspag/method/bankslip/info.phtml');
    }

    protected function _prepareSpecificInformation($transport = null)
    {
        if (null !== $this->_paymentSpecificInformation) {
            return $this->_paymentSpecificInformation;
        }
        $info = $this->getInfo();
        $transport = new Varien_Object();
        $transport = parent::_prepareSpecificInformation($transport);

        $transport->addData($this->prepareData($info));

        return $transport;
    }

    public function prepareData($data)
    {
        return [
            $this->__('Payment ID') => $data->getAdditionalInformation('payment_id'),
            $this->__('Expire Date') => $data->getAdditionalInformation('bankslip_expire'),
            $this->__('View') => "<a target='_blank' href=\"" . $data->getAdditionalInformation('bankslip_url') . "\">" . $this->__('Bankslip') . "</a>"
        ];
    }
}