<?php


class Signativa_Braspag_Block_Checkout_Onepage_Success extends Mage_Checkout_Block_Onepage_Success
{
    public function getBankslipUrl() {
        $orderId = Mage::getSingleton('checkout/session')->getLastOrderId();
        if ($orderId) {
            /**
             * @var $order Mage_Sales_Model_Order
             */
            $order = Mage::getModel('sales/order')->load($orderId);
            $payment = $order->getPayment();

            return $payment->getAdditionalInformation('bankslip_url');
        }
    }
}