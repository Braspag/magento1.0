<?php


class Signativa_Braspag_Block_Adminhtml_Recurrence_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct() {
        parent::__construct();
        $this->setId('recurrence_id');
        $this->setDefaultSort('recurrence_id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
    }

    /**
     *   Prepares collection
     *   @return Mage_Adminhtml_Block_Widget_Grid
     */
    protected function _prepareCollection() {
        /**
         * @var $collection Signativa_Braspag_Model_Resource_Recurrence_Collection
         */
        $collection = Mage::getModel('braspag/recurrence')->getCollection();
        $collection->join(
            array('order' => 'sales/order'),
            'order.entity_id=main_table.parent_id',
            array('increment_id'=>'increment_id', 'base_currency_code' => 'base_currency_code'),
            null,
            'left'
        );
        $this->setCollection($collection)                                                      ;
        return parent::_prepareCollection();
    }

    /**
     *   Prepares grid columns
     * @return $this
     * @throws Exception
     */
    protected function _prepareColumns() {

        $this->addColumn('recurrence_id', array(
            'header'    => $this->__('Recurrence Id'),
            'width'     => '5px',
            'index'     => 'recurrence_id',
        ));

        $this->addColumn('order_increment_id', array(
            'header'    => $this->__('Parent Increment Id'),
            'index'     => 'increment_id',
            'filter_index' => 'increment_id'
        ));

        $this->addColumn('grand_total', array(
            'header'    => $this->__('Grand Total'),
            'index'     => 'grand_total',
            'type'  => 'currency',
            'currency' => 'base_currency_code',
        ));

        $this->addColumn('last_order_created', array(
            'header'    => $this->__('Last Order Created'),
            'index'     => 'last_order_created',
            'filter_index' => 'last_order_created'
        ));

        $this->addColumn('store_id', array(
            'header'    => $this->__('Store'),
            'index'     => 'store_id',
            // 'type'      => 'options',
            'filter'    => false,
            'sortable'  => false,
            'frame_callback' => array($this, 'getStoreName')
        ));
        $holds = [];
        foreach (Signativa_Braspag_Model_Recurrence::STATUS_HOLD as $status) {
            $holds[$status] = $this->__('On Hold');
        }
        $this->addColumn('state', array(
            'header'    => $this->__('State'),
            'width'     => '20px',
            'index'     => 'state',
            'type'      => 'options',
            'options'   => array_merge(array(
                Signativa_Braspag_Model_Recurrence::STATUS_FINALIZED => $this->__('Cancelled'),
                Signativa_Braspag_Model_Recurrence::STATUS_ACTIVE => $this->__('Active'),
            ), $holds),
            'frame_callback' => array($this, 'decorate')
        ));

        $this->addColumn('action',
            array(
                'header'    => $this->__('Action'),
                'width'     => '10px',
                'type'      => 'action',
                'getter'     => 'getId',
                'actions'   => array(
                    array(
                        'caption' => $this->__('View'),
                        'url'     => array(
                            'base'=>'*/*/edit',
                        ),
                        'field'   => 'entity_id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false,
                'index'     => 'stores',
            ));

        return $this;
    }

    public function decorate($value, $row, $column, $isExport) {
        $class = '';
        if ($row->getState() == Signativa_Braspag_Model_Recurrence::STATUS_FINALIZED) {
            return '<span class="grid-severity-critical"><span>'.$value.'</span></span>';
        } else if ($row->getState() == Signativa_Braspag_Model_Recurrence::STATUS_ACTIVE) {
            return '<span class="grid-severity-notice"><span>'.$value.'</span></span>';
        }
        else {
            return '<span class="grid-severity-warning"><span>'.$value.'</span></span>';
        }
    }

    public function getStoreName($value, $row,$column, $isExport) {
        $_store = Mage::getModel('core/store')->load($value);
        return "<strong>".$_store->getName()."</strong>";
    }

}