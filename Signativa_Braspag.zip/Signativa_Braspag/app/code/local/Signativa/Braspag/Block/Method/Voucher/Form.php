<?php


class Signativa_Braspag_Block_Method_Voucher_Form extends Signativa_Braspag_Block_Method_Form
{
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('braspag/method/voucher/form.phtml');
    }


    /**
     * @param $flag
     * @return string
     */
    protected function getFlagValidation($flag)
    {
        switch ($flag) {
            case "alelo":
            case 'elo':
                return "{
                          name: 'elo',
                          pattern: /^(5018|5020|5038|6304|6759|676[1-3])/,
                          valid_length: [12, 13, 14, 15, 16, 17, 18, 19]
                        }";
            default:
                return "";
        }
    }
}