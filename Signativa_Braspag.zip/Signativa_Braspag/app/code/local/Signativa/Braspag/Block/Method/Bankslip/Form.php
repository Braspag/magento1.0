<?php

class Signativa_Braspag_Block_Method_Bankslip_Form extends Mage_Payment_Block_Form
{
    /**
     * @var Signativa_Braspag_Helper_Data
     */
    protected $helper;

    protected function _construct()
    {
        parent::_construct();
        $this->helper = Mage::helper('braspag');
        $this->setTemplate('braspag/method/bankslip/form.phtml');
    }

    public function getInstructions()
    {
        return $this->helper->getConfig('bankslip', 'information');
    }
}