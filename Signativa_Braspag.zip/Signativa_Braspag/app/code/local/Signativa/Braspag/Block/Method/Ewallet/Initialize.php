<?php


class Signativa_Braspag_Block_Method_Ewallet_Initialize extends Mage_Checkout_Block_Onepage_Abstract
{
    public function getConfigurationJson() : string
    {
        $object = new Varien_Object();

        $object->setUpdateUrl( $this->getUrl('braspag/ewallet/update'));
        $object->setEwallet($this->getEwallet()->getEwalletName());

        return $object->toJson();
    }

    public function getEwallet() : Signativa_Braspag_Model_Ewallet
    {
        return Mage::getSingleton('braspag/ewallet');
    }
}