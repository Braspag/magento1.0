<?php


class Signativa_Braspag_Block_Method_OneClick_Form extends Signativa_Braspag_Block_Method_Cc_Form
{
    protected function _construct()
    {
        parent::_construct();
        $this->helper = Mage::helper('braspag');
        $this->setTemplate('braspag/method/oneclick/form.phtml');
    }

    /**
     * @return Iterator
     */
    public function getSavedCcs()
    {
        $hashes = $this->helper->getSavedCcByCustomer($this->getCustomer());
        /**
         * @var $hash Signativa_Braspag_Model_Hash
         */
        foreach ($hashes as $hash) {
            yield [
                'brand' => $hash->getCardBrand(),
                'id' => $hash->getId(),
                'last_four' => $hash->getLastFourDigits()
            ];
        }
    }

    /**
     * @return Mage_Customer_Model_Customer
     */
    private function getCustomer()
    {
        return Mage::getSingleton('customer/session')->getCustomer();
    }

    /**
     * @return Signativa_Braspag_Model_Resource_Hash_Collection
     */
    private function getHashesCollection()
    {
        return Mage::getModel('braspag/hash')->getCollection();
    }
}