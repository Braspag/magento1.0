<?php


class Signativa_Braspag_Block_Checkout_ThreeDs_Address extends Mage_Checkout_Block_Onepage_Abstract
{

}