<?php


class Signativa_Braspag_Block_Checkout_ThreeDs_Device extends Mage_Checkout_Block_Onepage_Abstract
{
    public function getUserIpAddress()
    {
        if (!empty($this->getRequest()->getServer('HTTP_CLIENT_IP')))   //check ip from share internet
        {
            return  $this->getRequest()->getServer('HTTP_CLIENT_IP');
        } elseif (!$this->getRequest()->getServer('HTTP_X_FORWARDED_FOR'))   //to check ip is pass from proxy
        {
            return $this->getRequest()->getServer('HTTP_X_FORWARDED_FOR');
        } else {
            return  $this->getRequest()->getServer('REMOTE_ADDR');
        }
    }
}