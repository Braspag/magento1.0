<?php
/**
 * Created by PhpStorm.
 * User: matheus
 * Date: 19/05/19
 * Time: 13:25
 */

class Signativa_Braspag_Block_Method_Cc_Info extends Mage_Payment_Block_Info
{
    /**
     * @param null $transport
     * @return Varien_Object|null
     * @throws Mage_Core_Model_Store_Exception
     */
    protected function _prepareSpecificInformation($transport = null)
    {
        if (null !== $this->_paymentSpecificInformation) {
            return $this->_paymentSpecificInformation;
        }
        $info = $this->getInfo();
        $transport = new Varien_Object();
        $transport = parent::_prepareSpecificInformation($transport);

        $transport->addData($this->prepareData($info));
        $transport->addData($this->preparePaymentData($info));
        if (Mage::app()->getStore()->isAdmin()) {
            $transport->addData($this->prepareFraudData($info));
        }

        return $transport;
    }

    /**
     * @param $data
     * @return array
     */
    public function prepareData($data)
    {
        return array_filter([
            $this->__('Payment ID') => $data->getAdditionalInformation('payment_id'),
            $this->__('Next Charge') => $data->getAdditionalInformation('recurrence_next'),
            $this->__('Recurrence End') => $data->getAdditionalInformation('recurrence_end'),
            $this->__('Recurrence Payment ID') => $data->getAdditionalInformation('recurrence_payment_id'),
            $this->__('Parent Order') => $data->getAdditionalInformation('parent_order_id')
        ]);
    }

    /**
     * @param $payment Mage_Payment_Model_Info
     * @return array
     */
    protected function preparePaymentData($payment)
    {
        return array_filter([
            $this->__('Card Number') => "********{$payment->getCcLast4()}",
            $this->__('CC Brand') => $this->prepareBrand($payment->getCcType()),
            $this->__('Installments') => $payment->getPoNumber()
        ]);
    }

    /**
     * @param $brand
     * @return string
     */
    private function prepareBrand($brand)
    {
        switch ($brand) {
            case 'master':
                return 'Mastercard';
            default :
                if (strlen($brand) < 4) {
                    return uc_words($brand);
                }
                return ucfirst($brand);
        }
    }

    /**
     * @param $info
     * @return array
     */
    protected function prepareFraudData($info)
    {
        return array_filter([
            $this->__('Anti-Fraud Status') => Mage::helper('braspag')->prepareStatus($info->getAdditionalInformation('cybersource_status')),
            $this->__('Anti-Fraud Transaction ID') => $info->getAdditionalInformation('cybersource_transaction_id')
        ]);
    }

}