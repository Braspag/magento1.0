<?php


class Signativa_Braspag_Block_Method_Debit_Info extends Mage_Payment_Block_Info
{
    protected function _prepareSpecificInformation($transport = null)
    {
        if (null !== $this->_paymentSpecificInformation) {
            return $this->_paymentSpecificInformation;
        }
        $info = $this->getInfo();
        $transport = new Varien_Object();
        $transport = parent::_prepareSpecificInformation($transport);

        $transport->addData($this->prepareData($info));
        $transport->addData($this->preparePaymentData($info));

        return $transport;
    }

    public function prepareData($data)
    {
        return [
            $this->__('Payment ID') => $data->getAdditionalInformation('payment_id'),
        ];
    }

    /**
     * @param $payment Mage_Payment_Model_Info
     * @return array
     */
    protected function preparePaymentData($payment)
    {
        return [
            $this->__('Card Number') => "********{$payment->getCcLast4()}",
            $this->__('CC Brand') => $this->prepareBrand($payment->getCcType())
        ];
    }

    private function prepareBrand($brand)
    {
        if (strlen($brand) < 4) {
            return uc_words($brand);
        }
        return ucfirst($brand);
    }
}