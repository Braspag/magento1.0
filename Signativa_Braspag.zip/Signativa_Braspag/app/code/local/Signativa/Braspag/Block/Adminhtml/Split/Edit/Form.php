<?php


class Signativa_Braspag_Block_Adminhtml_Split_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form(array(
            'id'        => 'edit_form',
            'action' => $this->getUrl('*/*/save',
                array('id' => $this->getRequest()->getParam('entity_id'),
                    'store_id' =>$this->getRequest()->getParam('store')
                )
            ),
            'method'    => 'post',
            'enctype'   => 'multipart/form-data',
        ));
        $form->setUseContainer(true);

        $this->setForm($form);
        $this->prepareGeneral();
        $this->prepareSplitSettings();
        $this->prepareFeesAndTaxes();

        if ($this->getSplit()) {
            $data = $this->getSplit()->getData();
            $form->setValues($data);
        }

    }

    public function getSplit() : Signativa_Braspag_Model_Split_Merchant
    {
        return Mage::registry('current_split');
    }

    /**
     * @return Varien_Data_Form_Element_Fieldset
     */
    protected function prepareGeneral()
    {
        $geral = $this->getForm()->addFieldset('split_general', array(
            'legend' => Mage::helper('braspag')->__('General')
        ));

        $geral->addField('merchant_id', 'text', array(
            'label'     => Mage::helper('braspag')->__('Merchant ID'),
            'name'      => 'merchant_id',
            'required'  => true,
        ));

        $geral->addField('merchant_name', 'text', array(
            'label'     => Mage::helper('braspag')->__('Merchant Name'),
            'name'      => 'merchant_name',
            'required'  => true,
        ));

        return $geral;
    }

    protected function prepareFeesAndTaxes()
    {
        $fee = $this->getForm()->addFieldset('fees_taxes', array(
            'legend' => Mage::helper('braspag')->__('Fee & Tax')
        ));

        $fee->addField('mdr', 'text', array(
            'label'     => Mage::helper('braspag')->__('Default MDR Tax'),
            'name'      => 'mdr',
            'required'  => false,
            'note' => Mage::helper('braspag')->__('Used if no MDR rate is defined for an specific brand and installment combination.')
        ));

        $mdrRates = $fee->addField('mdr_rates', 'text', [
            'name' => 'mdr_rates',
            'label' => $this->__('MDR Rates'),
            'required' => false
        ]);

        $mdrRates->setRenderer($this->getLayout()->createBlock('braspag/adminhtml_split_edit_mdr')->setValue($this->getSplit()->getMdrRates()->getData()));

        return $fee;
    }

    protected function  prepareSplitSettings()
    {
        $split = $this->getForm()->addFieldset('split_settings', array(
            'legend' => Mage::helper('braspag')->__('Split Settings')
        ));

        $split->addField('split_amount_subtotal', 'text', array(
            'label'     => Mage::helper('braspag')->__('Split Amount Subtotal'),
            'name'      => 'split_amount_subtotal',
            'required'  => true,
        ));

        $split->addField('is_percent', 'select', array(
            'label' => Mage::helper('braspag')->__('Is percent'),
            'name' => 'is_percent',
            'values' => array(
                array(
                    'value' => 1,
                    'label' => Mage::helper('braspag')->__('Yes'),
                ),
                array(
                    'value' => 0,
                    'label' => Mage::helper('braspag')->__('No'),
                ),
            )
        ));
        $split->addField('split_for_each_item', 'select', array(
            'label' => Mage::helper('braspag')->__('Apply Split amount for each merchant item'),
            'name' => 'split_for_each_item',
            'values' => array(
                array(
                    'value' => 1,
                    'label' => Mage::helper('braspag')->__('Yes'),
                ),
                array(
                    'value' => 0,
                    'label' => Mage::helper('braspag')->__('No'),
                ),
            )
        ));

        $split->addField('split_shipping', 'select', array(
            'label' => Mage::helper('braspag')->__('Split shipping value'),
            'name' => 'split_shipping',
            'values' => array(
                array(
                    'value' => 1,
                    'label' => Mage::helper('braspag')->__('Yes'),
                ),
                array(
                    'value' => 0,
                    'label' => Mage::helper('braspag')->__('No'),
                ),
            )
        ));

        $split->addField('split_amount_shipping', 'text', array(
            'label'     => Mage::helper('braspag')->__('Split Amount Shipping'),
            'name'      => 'split_amount_shipping',
            'required'  => false,
        ));

        $split->addField('is_percent_shipping', 'select', array(
            'label' => Mage::helper('braspag')->__('Split shipping is percent'),
            'name' => 'is_percent_shipping',
            'values' => array(
                array(
                    'value' => 1,
                    'label' => Mage::helper('braspag')->__('Yes'),
                ),
                array(
                    'value' => 0,
                    'label' => Mage::helper('braspag')->__('No'),
                ),
            )
        ));

        return $split;
    }
}