<?php


class Signativa_Braspag_Block_Checkout_ThreeDs extends Mage_Checkout_Block_Onepage
{
    /**
     * @return string
     */
    public function _toHtml()
    {
        if (!$this->getThreeDsInstance()->isActive()) {
            return '';
        }
        return parent::_toHtml();
    }

    /**
     * @return bool|mixed
     */
    public function getAuth()
    {
        return $this->getThreeDsInstance()->authenticate();
    }

    /**
     * @return string
     */
    public function getEnv()
    {
        return $this->getThreeDsInstance()->getEnvironment() == 'production' ? Signativa_Braspag_Model_ThreeDS::PRODUCTION_ENVIRONMENT : Signativa_Braspag_Model_ThreeDS::SANDBOX_ENVIRONMENT;
    }

    /**
     * @return Signativa_Braspag_Model_ThreeDS
     */
    public function getThreeDsInstance() : Signativa_Braspag_Model_ThreeDS
    {
        return Mage::getSingleton('braspag/threeDS');
    }

    /**
     * @return string
     */
    public function getJsonConfig()
    {
        return Zend_Json::encode(
            [
                'fetch_url' => Mage::getUrl('braspag/auth/fetch_block'),
                'containers' => array_keys($this->getThreeDsInstance()->getBlockLoader()->blockContainerRelation),
                'is_threeds_active' => $this->getThreeDsInstance()->isActive(),
                'allowed_methods' => $this->getThreeDsInstance()->allowedMethods(),
                'can_place_order' => [
                    'error' => (bool) $this->getThreeDsInstance()->canCreateOrderError(),
                    'failure' => (bool) $this->getThreeDsInstance()->canCreateOrderFailure(),
                    'unenrolled' => (bool) $this->getThreeDsInstance()->canCreateOrderUnenrolled()
                ]
            ]
        );
    }
}