<?php


class Signativa_Braspag_Block_Adminhtml_Split_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
        $this->_objectId = 'entity_id';
        $this->_blockGroup = 'braspag';
        $this->_controller = 'adminhtml_split';
        $this->_removeButton('reset');
    }

    public function getHeaderText()
    {
        if (!$this->getMerchant()->getId())
        {
            return $this->__('Creating new merchant');
        }
        return $this->__('Managing Merchant: %s', $this->getMerchant()->getMerchantName());
    }

    public function getMerchant() : Signativa_Braspag_Model_Split_Merchant
    {
        return Mage::registry('current_split');
    }
}