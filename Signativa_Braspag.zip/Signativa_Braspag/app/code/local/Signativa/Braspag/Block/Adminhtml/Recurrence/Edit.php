<?php


class Signativa_Braspag_Block_Adminhtml_Recurrence_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();
        $this->_objectId = 'entity_id';
        $this->_blockGroup = 'braspag';
        $this->_controller = 'adminhtml_recurrence';
        $this->_removeButton('save');
        $this->_removeButton('reset');
        if ($this->getRecurrence()->getState() == Signativa_Braspag_Model_Recurrence::STATUS_ACTIVE && $this->getRecurrence()->getStatus() != Signativa_Braspag_Model_Recurrence::STATUS_FINALIZED) {
            $confirmationMessage = Mage::helper('core')->jsQuoteEscape(
                $this->__('Are you sure you want to deactivate the recurrence?')
            );

            $this->addButton('deactivate', array(
                'label'     => $this->__('Deactivate'),
                'onclick'   => "confirmSetLocation('{$confirmationMessage}', '{$this->getDeactivateUrl()}')",
            ));
        }
        else if ($this->getRecurrence()->getState() != Signativa_Braspag_Model_Recurrence::STATUS_FINALIZED){
            $confirmationMessage = Mage::helper('core')->jsQuoteEscape(
                $this->__('Are you sure you want to activate the recurrence?')
            );

            $this->addButton('Activate', array(
                'label'     => $this->__('Activate'),
                'onclick'   => "confirmSetLocation('{$confirmationMessage}', '{$this->getActivateUrl()}')",
            ));
        }
    }

    public function getHeaderText()
    {
        return $this->__('Managing Recurrence #%d', $this->getRecurrence()->getId());
    }

    public function getRecurrence() : Signativa_Braspag_Model_Recurrence
    {
        return Mage::registry('current_recurrence');
    }

    public function getActivateUrl()
    {
        return $this->getUrl('adminhtml/recurrence/activate', array('id' => $this->getRecurrence()->getId()));
    }

    public function getDeactivateUrl()
    {
        return $this->getUrl('adminhtml/recurrence/deactivate', array('id' => $this->getRecurrence()->getId()));
    }
}