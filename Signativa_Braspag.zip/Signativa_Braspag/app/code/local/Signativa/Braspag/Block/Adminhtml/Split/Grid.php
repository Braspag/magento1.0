<?php


class Signativa_Braspag_Block_Adminhtml_Split_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct() {
        parent::__construct();
        $this->setId('id');
        $this->setDefaultSort('id');
        $this->setDefaultDir('ASC');
        $this->setSaveParametersInSession(true);
    }

    /**
     *   Prepares collection
     *   @return Mage_Adminhtml_Block_Widget_Grid
     */
    protected function _prepareCollection() {
        /**
         * @var $collection Signativa_Braspag_Model_Resource_Recurrence_Collection
         */
        $collection = Mage::getModel('braspag/split_merchant')->getCollection();
        $this->setCollection($collection)                                                      ;
        return parent::_prepareCollection();
    }

    /**
     *   Prepares grid columns
     * @return $this
     * @throws Exception
     */
    protected function _prepareColumns() {

        $this->addColumn('entity_id', array(
            'header'    => $this->__('Id'),
            'width'     => '5px',
            'index'     => 'entity_id',
        ));
        $this->addColumn('merchant_name', array(
            'header'    => $this->__('Merchant Name'),
            'index'     => 'merchant_name',
            'filter_index' => 'merchant_name'
        ));
        $this->addColumn('merchant_id', array(
            'header'    => $this->__('Merchant Id'),
            'index'     => 'merchant_id',
            'filter_index' => 'merchant_id'
        ));

        $this->addColumn('split_amount_subtotal', array(
            'header'    => $this->__('Split Amount'),
            'index'     => 'split_amount_subtotal',
            'filter_index' => 'split_amount_subtotal'
        ));

        $this->addColumn('mdr', array(
            'header'    => $this->__('MDR'),
            'index'     => 'mdr',
            'filter_index' => 'mdr'
        ));

        $this->addColumn('created_at', array(
            'header'    => $this->__('Created At'),
            'index'     => 'created_at',
            'filter_index' => 'created_at',
            'type' => 'datetime',
            'width' => '100px',
        ));

        $this->addColumn('action',
            array(
                'header'    => $this->__('Action'),
                'width'     => '10px',
                'type'      => 'action',
                'getter'     => 'getId',
                'actions'   => array(
                    array(
                        'caption' => $this->__('View'),
                        'url'     => array(
                            'base'=>'*/*/edit',
                        ),
                        'field'   => 'entity_id'
                    )
                ),
                'filter'    => false,
                'sortable'  => false
            ));

        return $this;
    }
}