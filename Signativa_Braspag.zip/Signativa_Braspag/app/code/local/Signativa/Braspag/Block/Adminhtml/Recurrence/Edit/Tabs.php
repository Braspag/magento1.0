<?php


class Signativa_Braspag_Block_Adminhtml_Recurrence_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('recurrence_tabs');
        $this->setDestElementId('edit_form');
        $this->_controller = 'adminhtml_recurrence';
    }

    /**
     * @return Mage_Core_Block_Abstract
     * @throws Exception
     */
    protected function _beforeToHtml()
    {
        $this->addTab('group_general', array(
            'label'     => Mage::helper('braspag')->__('General'),
            'content'   =>  $this->getLayout()->createBlock('braspag/adminhtml_recurrence_edit_tabs_general')->toHtml(),
        ));

        $this->addTab('group_items', array(
            'label'     => Mage::helper('braspag')->__('Items'),
            'content'   =>  $this->getLayout()->createBlock('braspag/adminhtml_recurrence_edit_tabs_item')->toHtml(),
        ));

        $this->addTab('group_transactions', array(
            'label'     => Mage::helper('braspag')->__('Transactions'),
            'content'   =>  $this->getLayout()->createBlock('braspag/adminhtml_recurrence_edit_tabs_transaction')->toHtml(),
        ));

        return parent::_beforeToHtml();
    }

}