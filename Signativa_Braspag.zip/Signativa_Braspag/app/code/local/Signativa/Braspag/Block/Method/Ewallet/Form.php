<?php


class Signativa_Braspag_Block_Method_Ewallet_Form extends Mage_Payment_Block_Form
{
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('braspag/method/ewallet/form.phtml');
    }

    /**
     * @return Signativa_Braspag_Model_Ewallet
     */
    public function getEwallet() : Signativa_Braspag_Model_Ewallet
    {
        return Mage::getSingleton('braspag/ewallet');
    }
}