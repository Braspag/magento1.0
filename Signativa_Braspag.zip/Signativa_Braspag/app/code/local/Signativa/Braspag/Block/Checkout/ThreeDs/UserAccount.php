<?php


class Signativa_Braspag_Block_Checkout_ThreeDs_UserAccount extends Mage_Checkout_Block_Onepage_Abstract
{
    public function isCustomerNew()
    {
        $customerEmail = $this->getQuote()->getCustomerEmail();

        return $this->getOrdersByEmail($customerEmail)->count() == 0;
    }

    /**
     * @param $email
     * @return Mage_Sales_Model_Resource_Order_Collection
     */
    private function getOrdersByEmail($email)
    {
        return Mage::getModel('sales/order')->getCollection()->addFieldToFilter('customer_email', $email);
    }

    public function prepareDate($date)
    {
        return date('Y-m-d', Varien_Date::toTimestamp($date));
    }

    public function getSessionTimestamp()
    {
        /**
         * @var $session Mage_Customer_Model_Session
         */
        $session = Mage::getSingleton('customer/session');

        $validationTimestamp = $session->getCookieLifetime();
        return date('Y-m-d H:i:s', strtotime('-'.$validationTimestamp.' second'));
    }
}