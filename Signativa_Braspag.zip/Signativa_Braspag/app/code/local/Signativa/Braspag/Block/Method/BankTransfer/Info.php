<?php


class Signativa_Braspag_Block_Method_BankTransfer_Info extends Mage_Payment_Block_Info
{
    protected function _prepareSpecificInformation($transport = null)
    {
        if (null !== $this->_paymentSpecificInformation) {
            return $this->_paymentSpecificInformation;
        }
        $info = $this->getInfo();
        $transport = new Varien_Object();
        $transport = parent::_prepareSpecificInformation($transport);

        $transport->addData($this->prepareData($info));

        return $transport;
    }

    public function prepareData($data)
    {
        return [
            $this->__('Payment ID') => $data->getAdditionalInformation('payment_id'),
            $this->__('Status') => $data->getAdditionalInformation('status'),
            $this->__('Provider') => $data->getAdditionalInformation('provider'),
        ];
    }
}