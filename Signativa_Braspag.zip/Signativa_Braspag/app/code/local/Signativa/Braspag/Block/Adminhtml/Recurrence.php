<?php


class Signativa_Braspag_Block_Adminhtml_Recurrence extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct() {
        $this->_blockGroup = 'braspag';
        $this->_controller = 'adminhtml_recurrence';
        $this->_headerText = Mage::helper('braspag')->__('Manage Recurrences');
        parent::__construct();
        $this->removeButton('add');
    }

}