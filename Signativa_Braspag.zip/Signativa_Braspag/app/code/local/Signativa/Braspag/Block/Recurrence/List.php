<?php


class Signativa_Braspag_Block_Recurrence_List extends Mage_Customer_Block_Account_Dashboard
{
    /**
     * @return Mage_Customer_Model_Customer
     */
    public function getCustomer() : Mage_Customer_Model_Customer
    {
        return Mage::getSingleton('customer/session')->getCustomer();
    }

    /**
     * @return Signativa_Braspag_Model_Resource_Recurrence_Collection
     */
    public function getRecurrences() : Signativa_Braspag_Model_Resource_Recurrence_Collection
    {
        return Mage::getModel('braspag/recurrence')->getCollection()->addFieldToFilter('customer_id', $this->getCustomer()->getId());
    }

}