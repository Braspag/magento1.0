<?php


class Signativa_Braspag_Block_Method_Cc_Form extends Signativa_Braspag_Block_Method_Form
{
    protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('braspag/method/cc/form.phtml');
    }

    /**
     * @param $flag
     * @return mixed|string
     */
    protected function getFlagValidation($flag)
    {
        switch ($flag) {
            case "amex":
                return "{
                          name: 'amex',
                          pattern: /^3[47][0-9]{13}$/,
                          valid_length: [15]
                        }";
            case "diners":
                return "{
                          name: 'diners',
                          pattern: /(^[35](?:0[0-5]|[68][0-9])[0-9]{11}$)|(^30[0-5]{11}$)|(^3095(\d{10})$)|(^36{12}$)|(^3[89](\d{12})$)/,
                          valid_length: [14]
                        }";
            case "jcb":
                return "{
                          name: 'jcb',
                          pattern: /^35(2[89]|[3-8][0-9])/,
                          valid_length: [16]
                        }";
            case "visa":
                return "{
                          name: 'visa',
                          pattern: /^(4)(\d{12}|\d{15})$|^(606374\d{10}$)/,
                          valid_length: [16]
                        }";
            case 'aura':
                return "{
                            name : 'aura',
                            pattern : /^50[0-9]{14}$/,
                            valid_length : [16]
                        }";
            case "master":
                return "{
                          name: 'master',
                          pattern: /^(5[1-5]\d{14}$)|^(2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d\d|7(?:[01]\d|20))\d{12}$)/,
                          valid_length: [16]
                        }";
            case "elo":
                return "{
                          name: 'elo',
                          pattern: /(^(636368|438935|504175|451416|636297|650901|650485|650541|650700|650720|650720|650720|655021|650405)\d{10})$|(^(5090|5067|4576|4011)\d{12})$|(^(50904|50905|50906)\d{11})$/,
                          valid_length: [16]
                        }";
            case "discovery":
                return "{
                          name: 'discover',
                          pattern: /^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)/,
                          valid_length: [16]
                        }";
            case "hipercard":
                return "{
                          name: 'hipercard',
                          pattern: /^(384100|384140|384160|606282)(\d{10}|\d{13})$/,
                          valid_length: [19]
                        }";
            case "hiper":
                return "{
                          name: 'hiper',
                          pattern: /^(((637095)|(637612)|(637599)|(637609)|(637568))\d{0,10})$/,
                          valid_length: [16]
                        }";
            default:
                return "";
        }
    }

    /**
     * @param bool $isAdmin
     * @return string
     */
    public function getInstallmentSelect($isAdmin = false)
    {
        /**
         * @var $quote Mage_Adminhtml_Model_Session_Quote|Mage_Checkout_Model_Session
         */
        $isAdmin ? $quote = Mage::getSingleton('adminhtml/session_quote')->getQuote() : $quote = Mage::getModel('checkout/session')->getQuote();
        //no installments if quote is recurrent
        $grandTotal = $quote->getGrandTotal();
        $maxInstallmentsQty = $this->helper->getConfig('cc', 'max_installments');
        $html = "<select id='" . $this->getMethodCode() . "_installments'name='payment[" . $this->getMethodCode() . "_installments]' class='bpmpi_installments'>";
        for ($i = 1; $i <= $maxInstallmentsQty; $i++) { //parcela a vista
            if ($i == 1) {
                $html .= "<option value='$i'>" . $this->__("À Vista") . "</option>";
            } else {
                if (($grandTotal / $i) > $this->helper->getConfig('cc',
                        'min_installment_value')) // Parcelas que sao maiores que o valor minimo de uma parcela
                {
                    $html .= "<option value='$i'>" . "$i" . $this->__("x of ") . Mage::helper('core')->currency($grandTotal / $i,
                            true, false) . "</option>";
                }
            }
        }
        return $html . "</select>";
    }

    public function isOneClickEnabled() : bool
    {
        return $this->helper->getConfig('oneclick', 'active');
    }
}