<?php


class Signativa_Braspag_Block_Adminhtml_Split_Edit_Mdr extends Mage_Adminhtml_Block_System_Config_Form_Field_Array_Abstract
{

    public function __construct()
    {
        $this->setTemplate('braspag/system/config/form/field/array.phtml');
        parent::__construct();
    }
    /**
     * Add a column to array-grid
     *
     * @param string $name
     * @param array $params
     */
    public function addColumn($name, $params)
    {
        $this->_columns[$name] = array(
            'label'     => empty($params['label']) ? 'Column' : $params['label'],
            'size'      => empty($params['size'])  ? false    : $params['size'],
            'style'     => empty($params['style'])  ? null    : $params['style'],
            'class'     => empty($params['class'])  ? null    : $params['class'],
            'options'   => $params['options'] ?? null,
            'renderer'  => false,
        );
        if ((!empty($params['renderer'])) && ($params['renderer'] instanceof Mage_Core_Block_Abstract)) {
            $this->_columns[$name]['renderer'] = $params['renderer'];
        }
    }
    protected function _prepareToRender()
    {
        $this->addColumn('installment', array(
            'label' => Mage::helper('braspag')->__('Parcela'),
            'class' => 'input-text required-entry',
            'options' => $this->getInstallments()
        ));
        $this->addColumn('brand', array(
            'label' => Mage::helper('braspag')->__('Card Brand'),
            'options' => $this->getBrands()
        ));
        $this->addColumn('mdr', array(
            'label' => Mage::helper('braspag')->__('MDR'),
            'class' => 'input-text required-entry',
        ));
        $this->addColumn('debit', array(
            'label' => Mage::helper('braspag')->__('Debit'),
            'class' => 'input-text required-entry',
            'options' => Mage::getModel('adminhtml/system_config_source_yesno')
        ));

        // Disables "Add after" button
        $this->_addAfter = false;
        $this->_addButtonLabel = Mage::helper('braspag')->__('Add Rate');
    }
    /**
     * @return Signativa_Braspag_Model_Source_Installments
     */
    public function getInstallments ()
    {
        return Mage::getModel('braspag/source_installments');
    }

    /**
     * @return Signativa_Braspag_Model_Source_Brand_Cc
     */
    public function getBrands ()
    {
        return Mage::getModel('braspag/source_brand_cc');
    }

    protected function _renderCellTemplate($columnName) {
        $column     = $this->_columns[$columnName];

        if (empty($this->_columns[$columnName])) {
            throw new Exception('Wrong column name specified.');
        }

        if (isset($column['options']))
        {
            $inputName  = $this->getElement()->getName() . '[#{_id}][' . $columnName . ']';
            $renderer = $column['options'];
            $rendered = '<select name="'.$inputName.'" style="width:120px">';
            foreach ($renderer->toOptionArray() as  $option) {
                $rendered .= '<option value="'.$option['value'].'">'.$option['label'].'</option>';
            }
            $rendered .= '</select>';
            return $rendered;
        }
        else {
            return parent::_renderCellTemplate($columnName);
        }
    }

    /**
     * Obtain existing data from form element
     *
     * Each row will be instance of Varien_Object
     *
     * @return array
     */
    public function getArrayRows()
    {
        if (null !== $this->_arrayRowsCache) {
            return $this->_arrayRowsCache;
        }
        $result = array();
        /** @var Varien_Data_Form_Element_Abstract */
        if ($this->getValue() && is_array($this->getValue())) {
            foreach ($this->getValue() as $row) {
                foreach ($row as $key => $value) {
                    $row[$key] = $this->escapeHtml($value);
                }
                $row['_id'] =$row['entity_id'];
                $result[$row['entity_id']] = new Varien_Object($row);
                $this->_prepareArrayRow($result[$row['entity_id']]);
            }
        }
        $this->_arrayRowsCache = $result;
        return $this->_arrayRowsCache;
    }

    /**
     * Prepare existing row data object
     *
     * @param Varien_Object
     */
    protected function _prepareArrayRow(Varien_Object $row)
    {
        $row->unsetData('merchant_id');
    }
}