<?php


class Signativa_Braspag_Block_Checkout_ThreeDs_Order extends Mage_Checkout_Block_Onepage_Abstract
{
    const TRANSACTION_MODE_ECOMMERCE = 'S';
    /**
     * @return string
     */
    public function getStoreUrl()
    {
        return Mage::getBaseUrl();
    }

    /**
     * By default our transaction mode is going to be e-commerce
     * @return string
     */
    public function getTransactionMode()
    {
        return self::TRANSACTION_MODE_ECOMMERCE;
    }

    /**
     * @TODO implement actual recurrence checking
     * @return string
     */
    public function isQuoteRecurrent()
    {
        return "false";
    }

    /**
     * @return mixed
     */
    public function getProductCode()
    {
        /**
         * @var $helper Signativa_Braspag_Helper_Data
         */
        $helper = Mage::helper('braspag');

        return $helper->getAnyConfig('payment/threeds_auth/product_code');
    }

    /**
     * @param string $period
     * @return int
     * @throws Mage_Core_Exception
     */
    public function getOrdersByPeriod($period = '24hours')
    {
        $orders = $this->getOrders()->addFieldToFilter('customer_email', $this->getQuote()->getCustomerEmail());
        switch ($period) {
            case '24hours':
                $fromDate = date('Y-m-d H:i:s', strtotime('-24 hour'));
                break;
            case '6months':
                $fromDate = date('Y-m-d H:i:s', strtotime('-6 month'));
                break;
            case '1year':
                $fromDate = date('Y-m-d H:i:s', strtotime('-1 year'));
                break;
            default:
                $fromDate = null;
                break;
        }
        if (!$fromDate) {
            Mage::throwException('No valid period has been given to be analyzed');
        }
        $toDate = date('Y-m-d H:i:s', strtotime(now()));
        $orders->addFieldToFilter(
            'created_at', array(
                'from' => $fromDate,
                'to' => $toDate,
                'date' => true,
            )
        );
        return $orders->count();
    }

    /**
     * @return Mage_Sales_Model_Resource_Order_Collection
     */
    private function getOrders() {
        return Mage::getModel( 'sales/order')->getCollection();
    }

    /**
     * @return string
     * @todo verify if user is subscribed to newsletter
     */
    public function isUserSubscribed()
    {
        return 'false';
    }

    /**
     * @return string
     * @todo think about logic for this
     */
    public function getDefaultMarketingSource() {
        return '';
    }
}