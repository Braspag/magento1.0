<?php

class Signativa_Braspag_Block_Cart_Item_Renderer extends Mage_Checkout_Block_Cart_Item_Renderer
{
    /**
     * Checks if item is recurrent, if it is returns its recurrence info
     * @return array
     */
    public function getOptionList ()
    {
        $parent = parent::getOptionList();
        $arrToMerge = [];
        if ($this->isItemRecurrent() && $this->getRecurrenceHelper()->getConfig('active')) {
            $arrToMerge [] = [
                'label' => $this->_getHelper()->__('Recurrence Period'),
                'value' => $this->_getHelper()->__($this->getRecurrencePeriod()),
                'print_value' => $this->_getHelper()->__($this->getRecurrencePeriod()),
                'option_id' => 'recurrent',
                'option_type' => 'recurrence',
                'custom_view' => false
            ];
        }

        return array_merge($parent, $arrToMerge);
    }

    /**
     * @return bool
     */
    public function isItemRecurrent()
    {
        /**
         * @var Mage_Sales_Model_Resource_Quote_Item_Option_Collection $optionCollection
         */
        $optionCollection = Mage::getModel('sales/quote_item_option')->getCollection();
        $optionCollection->addFieldToFilter('item_id', $this->getItem()->getId())
        ->addFieldToFilter('code', 'info_buyRequest');
        $option = unserialize($optionCollection->getFirstItem()->getValue());
        $recurrenceFlag = filter_var($option['recurrence'], FILTER_VALIDATE_BOOLEAN);
        return (bool) ($this->getItem()->getProduct()->getBraspagIsRecurrent()) && ($recurrenceFlag  === true);

    }

    /**
     * @return string
     */
    public function getRecurrencePeriod()
    {
        return (string) $this->getItem()->getProduct()->getBraspagRecurrencePeriod();
    }

    /**
     * @return Signativa_Braspag_Helper_Data
     */
    protected function _getHelper() : Signativa_Braspag_Helper_Data
    {
        return Mage::helper('braspag');
    }

    /***
     * @return Signativa_Braspag_Helper_Recurrence
     */
    protected function getRecurrenceHelper() : Signativa_Braspag_Helper_Recurrence
    {
        return Mage::helper('braspag/recurrence');
    }
}
