<?php


class Signativa_Braspag_Block_Adminhtml_Recurrence_Edit_Tabs_General extends Mage_Adminhtml_Block_Widget_Form
{
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        $this->setForm($form);

        $this->prepareGeneral();
        $this->prepareValues();

        if ($this->getRecurrence()) {
            $data = $this->getRecurrence()->getData();
            $form->setValues($data);
        }
    }

    public function getRecurrence() : Signativa_Braspag_Model_Recurrence
    {
        return Mage::registry('current_recurrence');
    }

    public function prepareGeneral()
    {
        $geral = $this->getForm()->addFieldset('recurrence_general', array(
            'legend' => Mage::helper('braspag')->__('General')
        ));

        $geral->addField('parent_id', 'text', array(
            'label'     => Mage::helper('braspag')->__('Order ID'),
            'name'      => 'parent_id',
            'required'  => true,
            'class' => 'disabled'
        ));

        $geral->addField('recurrent_transaction_id', 'text', array(
            'label'     => Mage::helper('braspag')->__('Transaction ID'),
            'name'      => 'recurrent_transaction_id',
            'required'  => true,
            'class' => 'disabled'
        ));
        $geral->addField('next_recurrence', 'text', array(
            'label'     => Mage::helper('braspag')->__('Next Recurrence'),
            'name'      => 'next_recurrence',
            'required'  => true,
            'class' => 'disabled'
        ));

        $geral->addField('last_order_created', 'text', array(
            'label'     => Mage::helper('braspag')->__('Last order created'),
            'name'      => 'last_order_created',
            'required'  => true,
            'class' => 'disabled'
        ));

        return $this;
    }

    public function prepareValues()
    {
        $values = $this->getForm()->addFieldset('recurrence_value', array(
            'legend' => Mage::helper('braspag')->__('Values')
        ));

        $values->addField('grand_total', 'text', array(
            'label'     => Mage::helper('braspag')->__('Grand Total'),
            'name'      => 'grand_total',
            'required'  => true,
            'class' => 'disabled'
        ));
        $values->addField('discount_amount', 'text', array(
            'label'     => Mage::helper('braspag')->__('Discount Amount'),
            'name'      => 'discount_amount',
            'required'  => true,
            'class' => 'disabled'
        ));

        $values->addField('shipping_amount', 'text', array(
            'label'     => Mage::helper('braspag')->__('Shipping Amount'),
            'name'      => 'shipping_amount',
            'required'  => true,
            'class' => 'disabled'
        ));

        $values->addField('shipping_method', 'text', array(
            'label'     => Mage::helper('braspag')->__('Shipping Method'),
            'name'      => 'shipping_method',
            'required'  => true,
            'class' => 'disabled'
        ));
    }
}