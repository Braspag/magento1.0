<?php


class Signativa_Braspag_Block_Checkout_ThreeDs_Payment extends Mage_Checkout_Block_Onepage_Abstract
{
    const CREDIT_CARD = 'Credit';

    const DEBIT_CARD = 'Debit';
    /**
     * @param $price
     * @return int
     */
    public function priceToCents($price) {
        return (int)round($price * 100);
    }

    public function getPaymentMethod() {
        $method = $this->getQuote()->getPayment()->getMethod();
        if ($method == 'braspag_cc') {
            return self::CREDIT_CARD;
        }
        else {
            return self::DEBIT_CARD;
        }
    }
}