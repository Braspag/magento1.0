<?php


abstract class Signativa_Braspag_Block_Method_Form extends Mage_Payment_Block_Form
{
    /**
     * @var Signativa_Braspag_Helper_Data
     */
    protected $helper;

    protected function _construct()
    {
        parent::_construct();
        $this->helper = Mage::helper('braspag');
    }

    /**
     * @return array
     */
    protected function _getMethods()
    {
        return explode(",", $this->helper->getConfig($this->getMethod()->getBraspagCode(), 'brand'));
    }

    /**
     * Returns html representation of methods
     * @return string
     */
    public function getMethods()
    {
        $methods = $this->_getMethods();
        $html = "";
        foreach ($methods as $method) {
            $html .= "<span class='" . strtolower(str_replace('_', ' ', $method)) . "'></span>";
        }
        return $html;
    }

    /**
     * @return string
     */
    public function getValidationJson()
    {
        $json = [];

        foreach ($this->_getMethods() as $method) {
            $json[] = $this->getFlagValidation(strtolower(str_replace('_', ' ', $method)));
        }
        return implode(",", array_filter($json));
    }

    /**
     * @param $flag
     * @return mixed
     */
    abstract protected function getFlagValidation($flag);
}