<?php


class Signativa_Braspag_Block_Method_Ewallet_Special extends Mage_Checkout_Block_Onepage_Abstract
{
    /**
     * @return string
     */
    public function _toHtml()
    {
        if (!$this->getEwallet()->isActive()) {
            return '';
        }
        return parent::_toHtml();
    }
    public function _construct()
    {
        if ($this->getEwallet()->isActive()) {
            $instance = $this->getEwallet()->getEwalletInstance();
            if ($instance) {
                $this->setTemplate($instance->getSpecialTemplate());
            }
        }
        parent::_construct();
    }

    public function getEwallet() : Signativa_Braspag_Model_Ewallet
    {
        return Mage::getSingleton('braspag/ewallet');
    }
}