<?php


class Signativa_Braspag_Block_Adminhtml_Recurrence_Edit_Tabs_Item extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct() {
        $this->_blockGroup = 'braspag';
        $this->_controller = 'adminhtml_recurrence_edit_tabs_item';
        $this->_headerText = Mage::helper('braspag')->__('Manage Recurrences Items');
        parent::__construct();
        $this->_removeButton('add');
    }

}