<?php


class Signativa_Braspag_Block_Checkout_ThreeDs_Cart extends Mage_Checkout_Block_Onepage_Abstract
{
    /**
     * @param $itemPrice
     * @return int
     */
    public function itemPriceToCents($itemPrice) {
        return (int)round($itemPrice * 100);
    }
}