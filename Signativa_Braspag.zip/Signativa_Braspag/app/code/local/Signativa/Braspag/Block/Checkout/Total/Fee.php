<?php


class Signativa_Braspag_Block_Checkout_Total_Fee extends Mage_Checkout_Block_Total_Default
{
    protected $_template = 'braspag/checkout/total/fee.phtml';
}