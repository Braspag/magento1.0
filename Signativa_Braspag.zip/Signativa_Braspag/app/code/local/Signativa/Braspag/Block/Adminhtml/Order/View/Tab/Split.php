<?php


class Signativa_Braspag_Block_Adminhtml_Order_View_Tab_Split extends Mage_Adminhtml_Block_Template
    implements Mage_Adminhtml_Block_Widget_Tab_Interface
{
    use Signativa_Braspag_Trait_Api;

    private $splitCollection;

    private $splitInfo;

    public function _construct()
    {
        parent::_construct();
        $this->setTemplate('braspag/order/view/tab/split.phtml');

    }

    public function getTabLabel()
    {
        return $this->__('Braspag Split');
    }

    public function getTabTitle()
    {
        return $this->__('Braspag Split');
    }

    public function canShowTab()
    {
        if ($this->getMerchants())
            return true;
        return false;
    }

    /**
     * @return bool
     */
    public function isHidden()
    {
        return false;
    }

    /**
     * @return Mage_Sales_Model_Order
     */
    public function getOrder() : Mage_Sales_Model_Order
    {
        return Mage::registry('current_order');
    }

    /**
     * @return \Braspag\API\Sale
     * @throws Exception
     */
    public function getPaymentInfo() : \Braspag\API\Sale
    {
        if ($this->splitInfo) {
            return $this->splitInfo;
        }
        return $this->splitInfo = $this->getSplitInfo($this->getOrder()->getPayment()->getAdditionalInformation('payment_id'));
    }

    /**
     * @return array|mixed|null
     */
    public function getMerchants()
    {
        return $this->getOrder()->getPayment()->getAdditionalInformation('split_merchant');
    }

    /**
     * @param $merchantId
     * @return mixed|Signativa_Braspag_Model_Resource_Split_Merchant
     */
    public function getMerchantByMerchantId($merchantId)
    {
        /**
         * @var $merchant Signativa_Braspag_Model_Resource_Split_Merchant
         */
        foreach ($this->getMerchantCollection() as $merchant) {
            if ($merchantId == $merchant->getMerchantId()) {
                return $merchant;
            }
        }
        return Mage::getModel('braspag/split_merchant')->load($merchantId, 'merchant_id');
    }

    /**
     * @return array
     */
    public function getOrderMerchantIds ()
    {
        $ids = [];
        /**
         * @var $item Mage_Sales_Model_Order_Item
         */
        foreach ($this->getOrder()->getAllVisibleItems() as $item) {
            if ($id = $item->getProduct()->getBraspagMerchantId())
                $ids[] = $id;
        }
        return $ids;
    }

    /**
     * @return Signativa_Braspag_Model_Resource_Split_Merchant_Collection
     */
    public function getMerchantCollection() : Signativa_Braspag_Model_Resource_Split_Merchant_Collection
    {
        if ($this->splitCollection) {
            return $this->splitCollection;
        }
        $this->splitCollection = Mage::getModel('braspag/split_merchant')->getCollection()->addFieldToFilter('entity_id', array('in' => $this->getOrderMerchantIds()));
        return $this->splitCollection;
    }

    /**
     * @param $amount
     * @return mixed
     */
    public function prepareAmount($amount)
    {
        return Mage::helper('core')->currency($amount / 100);
    }

    public function getMerchantAmount($merchant)
    {
        if ($this->getPaymentInfo()->getPayment()->getDebitCard()) {
            $merchantId = $merchant['SubordinateMerchantId'];
            foreach ( $merchant['Splits'] as $splits) {
                if ($splits['MerchantId'] == $merchantId) {
                    return $splits['Amount'];
                }
            }
        }
        else {
            $amountFee = $merchant['Amount'] - $merchant['Fares']['Fee'];
            if ($merchant['Fares']['Mdr']) {
                $amountFee = $amountFee - $this->calculateMdr($merchant['Amount'], $merchant['Fares']['Mdr']);
            }
            return $amountFee;
        }
    }

    public function getStoreAmount($merchant)
    {
        if ($this->getPaymentInfo()->getPayment()->getDebitCard()) {
            $merchantId = $merchant['SubordinateMerchantId'];
            foreach ($merchant['Splits'] as $splits) {
                if ($splits['MerchantId'] != $merchantId) {
                    return $splits['Amount'];
                }
            }
        }
        else {
            $amount = $merchant['Fares']['Fee'];
            if ($merchant['Fares']['Mdr']) {
                $amount = $amount + $this->calculateMdr($merchant['Amount'], $merchant['Fares']['Mdr']);
            }
            return $amount;
        }
    }

    /**
     * @param $amount
     * @param $mdrPercentage
     * @return float|int
     */
    public function calculateMdr($amount, $mdrPercentage)
    {
        $mdr = ($mdrPercentage * $amount) / 100;

        return $mdr;
    }
}