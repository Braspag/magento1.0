<?php


class Signativa_Braspag_Block_Cybersource extends Mage_Core_Block_Text
{
    public function _toHtml()
    {
        if (!$this->getCybersource()->isActive()) {
            return '';
        }
        $params = http_build_query($this->getParameters());
        if ($this->getData('is_iframe')) {
            return "<iframe style='width: 100px; height: 100px; border 0; position: absolute; top: -50000px;' src='https://h.online-metrix.net/fp/tags?{$params}'></iframe>";
        }
        else {
            return "<script type=\"text/javascript\" src=\"https://h.online-metrix.net/fp/tags.js?{$params}\"></script>";
        }
    }

    public function getOrgId()
    {
        return $this->getCybersource()->getOrgId();
    }

    public function getBraspagHelper() : Signativa_Braspag_Helper_Data
    {
        return Mage::helper('braspag');
    }

    public function getCybersource() : Signativa_Braspag_Model_Cybersource
    {
        return Mage::getSingleton('braspag/cybersource');
    }

    /**
     * @return array
     */
    public function getParameters() : array
    {
        return [
            'org_id' => $this->getOrgId(),
            'session_id' => $this->getCybersource()->getMerchantId().$this->getCybersource()->getSessionId()
        ];
    }
}