# Signativa Braspag
Esse módulo integra a sua loja Magento com o gateway de pagamento Braspag

### Principais Funcionalidades 
* Cartão de crédito 
    * Autorização online na criação do pedido
    * Autorização e captura na criação do pedido
    * Captura online durante a criação da fatura
    * Cancelamento online
    * Estorno Online
    * Split da transação (por produto)
    * Recorrência
* Cartão de débito
* Boleto Bancário
* Voucher
* Transferência Bancária
* Autenticação 3DS
* Validação AntiFraude Cybersource
* Suporte a eWallets
    * Masterpass
    * VisaCheckout
    * ApplePay
    * SamsungPay
    * GooglePay

### Instalação 
Durante sua instalação o módulo cria algumas tabelas e adiciona alguns atributos a produtos

##### Tabelas:
- signativa_braspag_ewallet_callback
    - Armazena callbacks de ewallets (caso o ewallet faça uso de callbacks)
- signativa_braspag_card_hash
    - Armazena hashes de cartões salvos de clientes 
- signativa_braspag_recurrence
    - Armazena pedidos recorrentes e seus estados
- sigantiva_braspag_recurrence_item
    - Armazena items de recorrencias
- signativa_braspag_recurrence_transaction
    - Armazena historico de transações recorrentes 
- signativa_braspag_split_merchant
    - Contém Merchants que serão utilizados para calculo de split 
- signativa_braspag_split_merchant_mdr_rate
    - Contém configurações de taxas para os merchants
#####Atributos de Produtos:
- braspag_is_recurrent
    - Indica se o produto é recorrente
- braspag_recurrence_period
    - Indica o periodo de recorrência
- braspag_recurrence_duration
    - Indica a duração da recorrência
- braspag_merchant_id
    - Associa um produto a um merchant
    
##### Primeiros passos
###### Split
É necessario associar o [atributo de split com o seu conjunto de atributos](https://www.comunidademagento.com.br/como-exibir-atributo-na-pagina-de-produto/)
###### Recorrência
É necessario associar os [atributos de recorrencia com o seu conjunto de atributos](https://www.comunidademagento.com.br/como-exibir-atributo-na-pagina-de-produto/)

###Requisitos
* Versão PHP > 7.1
* Versão Magento > 1.9.0