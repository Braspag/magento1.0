<?php


class Signativa_Braspag_AnalysisErrorException extends Mage_Core_Exception
{

}